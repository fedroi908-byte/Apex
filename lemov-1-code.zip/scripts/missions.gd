class_name Missions
extends RefCounted
## Mission catalogue. Races reuse the real route polylines exported by the world generator (races.json).

const TYPE_NAMES := {"race": "ROAD RACE", "speed": "SPEED TRAP", "drift": "DRIFT KING", "courier": "CITY COURIER"}
const TYPE_COLORS := {"race": Color(0.10, 0.82, 1.0), "speed": Color(1.0, 0.48, 0.10), "drift": Color(0.85, 0.35, 1.0), "courier": Color(0.30, 0.95, 0.45)}


static func list() -> Array:
	W.ensure_races()
	var out: Array = []
	var diff_names := ["EASY", "MEDIUM", "HARD"]
	for r in W.races:
		var pts: Array = r["pts"]
		if pts.size() < 4:
			continue
		var len := 0.0
		for i in range(1, pts.size()):
			len += Vector2(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]).length()
		var d := int(r.get("difficulty", 1))
		var avg: float = [34.0, 31.0, 27.0][clampi(d, 0, 2)]
		var gold: float = len / avg
		out.append({
			"id": "race_" + String(r["id"]), "type": "race", "name": String(r["name"]), "desc": String(r["desc"]),
			"difficulty": d, "diff_name": diff_names[clampi(d, 0, 2)], "length": len, "pts": pts,
			"gold": gold, "silver": gold * 1.15, "limit": gold * 1.45,
			"reward": [600, 1000, 1600][clampi(d, 0, 2)] + int(len * 0.15),
		})
	out.append({
		"id": "speed_200", "type": "speed", "name": "200 CLUB", "desc": "Hit 200 km/h on the coast highway before time runs out.",
		"difficulty": 0, "diff_name": "EASY", "target": 200.0, "limit": 30.0, "gold": 14.0, "silver": 19.0,
		"start": "coast", "reward": 500,
	})
	out.append({
		"id": "speed_280", "type": "speed", "name": "280 CLUB", "desc": "Flat out. 280 km/h on the highway in under a minute.",
		"difficulty": 2, "diff_name": "HARD", "target": 280.0, "limit": 60.0, "gold": 32.0, "silver": 45.0,
		"start": "coast", "reward": 1400,
	})
	out.append({
		"id": "drift_3k", "type": "drift", "name": "SLIDE SCHOOL", "desc": "Collect 3000 drift points in 90 seconds.",
		"difficulty": 0, "diff_name": "EASY", "target": 3000.0, "limit": 90.0, "gold": 3000.0, "silver": 2000.0,
		"start": "downtown", "reward": 600,
	})
	out.append({
		"id": "drift_10k", "type": "drift", "name": "DRIFT KING", "desc": "10,000 drift points in 2 minutes. Link long slides for combos.",
		"difficulty": 2, "diff_name": "HARD", "target": 10000.0, "limit": 120.0, "gold": 10000.0, "silver": 6500.0,
		"start": "downtown", "reward": 1800,
	})
	out.append({
		"id": "courier_a", "type": "courier", "name": "DOWNTOWN COURIER", "desc": "Hit 8 delivery points across the city in 4 minutes.",
		"difficulty": 1, "diff_name": "MEDIUM", "count": 8, "limit": 240.0, "gold": 150.0, "silver": 195.0,
		"start": "downtown", "reward": 1100,
	})
	return out


static func by_id(id: String) -> Dictionary:
	for m in list():
		if m["id"] == id:
			return m
	return {}


static func stars_for(m: Dictionary, value: float, success: bool) -> int:
	if not success:
		return 0
	if m["type"] == "drift":
		return 3 if value >= m["gold"] else (2 if value >= m["silver"] else 1)
	return 3 if value <= m["gold"] else (2 if value <= m["silver"] else 1)


static func reward_for(m: Dictionary, stars: int) -> int:
	return int(float(m["reward"]) * [0.0, 0.5, 0.8, 1.0][clampi(stars, 0, 3)])
