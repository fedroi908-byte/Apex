extends Node3D
## Developer tool: renders one frame from a given camera pose and saves a PNG.
## godot --path . res://scenes/dev_shot.tscn -- x y z yaw_deg pitch_deg out.png [time_of_day]

var cam: Camera3D
var terrain: Node3D
var water: Node3D
var atmo: Atmosphere
var roads: RoadBuilder
var blds: BuildingBuilder
var out_path := "/tmp/shot.png"
var frames := 0


func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	var pos := Vector3(float(a[0]), float(a[1]), float(a[2])) if a.size() >= 3 else Vector3(0, 300, 0)
	var yaw := deg_to_rad(float(a[3])) if a.size() >= 4 else 0.0
	var pitch := deg_to_rad(float(a[4])) if a.size() >= 5 else -0.3
	out_path = a[5] if a.size() >= 6 else out_path
	var tod := float(a[6]) if a.size() >= 7 else 11.0
	W.load_all()
	atmo = Atmosphere.new()
	add_child(atmo)
	atmo.paused = true
	atmo.set_time(tod)
	if a.size() >= 8:
		atmo.set_weather(float(a[7]))
		atmo.weather = float(a[7])
		atmo.set_time(tod)
	terrain = TerrainClipmap.new()
	add_child(terrain)
	water = WaterBuilder.new()
	add_child(water)
	roads = RoadBuilder.new()
	add_child(roads)
	blds = BuildingBuilder.new()
	add_child(blds)
	cam = Camera3D.new()
	cam.far = 14000.0
	cam.near = 0.3
	cam.fov = 70
	add_child(cam)
	cam.position = pos
	cam.rotation = Vector3(pitch, yaw, 0)
	atmo.cam_ref = cam
	G.apply_quality(get_viewport())
	terrain.follow(pos)
	water.follow(pos)
	roads.build_all_near(pos, 2)
	blds.build_all_near(pos, 1000.0)


func _process(_dt: float) -> void:
	frames += 1
	if frames == 6:
		var img := get_viewport().get_texture().get_image()
		img.save_png(out_path)
		print("saved ", out_path, " ", img.get_size())
		get_tree().quit()
