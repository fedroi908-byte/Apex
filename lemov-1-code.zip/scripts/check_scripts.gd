extends SceneTree
## headless syntax check: loads every script/scene and reports failures.  usage: --headless --script res://scripts/check_scripts.gd
func _initialize() -> void:
	var bad := 0
	var d := DirAccess.open("res://scripts")
	for f in d.get_files():
		if f.ends_with(".gd") and f != "check_scripts.gd":
			var s = load("res://scripts/" + f)
			if s == null or (s is GDScript and not (s as GDScript).can_instantiate() and not (s as GDScript).is_abstract()):
				bad += 1
				print("BAD SCRIPT: ", f)
	for f in DirAccess.open("res://scenes").get_files():
		if f.ends_with(".tscn") and load("res://scenes/" + f) == null:
			bad += 1
			print("BAD SCENE: ", f)
	print("CHECK_DONE bad=", bad)
	quit()
