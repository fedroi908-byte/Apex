class_name MeshUtil
extends RefCounted
## Small helpers to accumulate geometry into packed arrays.

var v := PackedVector3Array()
var n := PackedVector3Array()
var uv := PackedVector2Array()
var uv2 := PackedVector2Array()
var col := PackedColorArray()
var idx := PackedInt32Array()
var tan := PackedFloat32Array()
var with_tangents := false
var with_uv2 := false


func vertex_count() -> int:
	return v.size()


func add_vertex(p: Vector3, nrm: Vector3, u: Vector2, c: Color, u2: Vector2 = Vector2.ZERO) -> int:
	v.append(p)
	n.append(nrm)
	uv.append(u)
	col.append(c)
	if with_uv2:
		uv2.append(u2)
	if with_tangents:
		tan.append_array([1.0, 0.0, 0.0, -1.0])
	return v.size() - 1


## Triangle wound so that it faces `nrm` (Godot front faces are clockwise).
func tri_auto(a: int, b: int, c: int, nrm: Vector3) -> void:
	var g := (v[b] - v[a]).cross(v[c] - v[a])
	if g.dot(nrm) > 0.0:
		idx.append_array([a, c, b])
	else:
		idx.append_array([a, b, c])


## Quad given by its four corners in perimeter order.
func quad_auto(a: int, b: int, c: int, d: int, nrm: Vector3) -> void:
	tri_auto(a, b, c, nrm)
	tri_auto(a, c, d, nrm)


func box(center: Vector3, size: Vector3, rot_y: float, c: Color, uv_scale: float = 1.0, top: bool = true, bottom: bool = false) -> void:
	var b := Basis(Vector3.UP, rot_y)
	var hx := size.x * 0.5
	var hy := size.y * 0.5
	var hz := size.z * 0.5
	var corners := [
		Vector3(-hx, -hy, -hz), Vector3(hx, -hy, -hz), Vector3(hx, -hy, hz), Vector3(-hx, -hy, hz),
		Vector3(-hx, hy, -hz), Vector3(hx, hy, -hz), Vector3(hx, hy, hz), Vector3(-hx, hy, hz),
	]
	for i in 8:
		corners[i] = center + b * corners[i]
	# sides: (a, b, top_b, top_a) around the box
	var sides := [[0, 1, 5, 4, size.x, Vector3(0, 0, -1)], [1, 2, 6, 5, size.z, Vector3(1, 0, 0)],
		[2, 3, 7, 6, size.x, Vector3(0, 0, 1)], [3, 0, 4, 7, size.z, Vector3(-1, 0, 0)]]
	for s in sides:
		var nrm: Vector3 = b * (s[5] as Vector3)
		var w: float = s[4]
		var a0 := add_vertex(corners[s[0]], nrm, Vector2(0, 0), c)
		var a1 := add_vertex(corners[s[1]], nrm, Vector2(w * uv_scale, 0), c)
		var a2 := add_vertex(corners[s[2]], nrm, Vector2(w * uv_scale, size.y * uv_scale), c)
		var a3 := add_vertex(corners[s[3]], nrm, Vector2(0, size.y * uv_scale), c)
		quad_auto(a0, a1, a2, a3, nrm)
	if top:
		var up := Vector3.UP
		var t0 := add_vertex(corners[4], up, Vector2(0, 0), c)
		var t1 := add_vertex(corners[5], up, Vector2(size.x * uv_scale, 0), c)
		var t2 := add_vertex(corners[6], up, Vector2(size.x * uv_scale, size.z * uv_scale), c)
		var t3 := add_vertex(corners[7], up, Vector2(0, size.z * uv_scale), c)
		quad_auto(t0, t1, t2, t3, up)
	if bottom:
		var dn := Vector3.DOWN
		var b0 := add_vertex(corners[0], dn, Vector2(0, 0), c)
		var b1 := add_vertex(corners[1], dn, Vector2(1, 0), c)
		var b2 := add_vertex(corners[2], dn, Vector2(1, 1), c)
		var b3 := add_vertex(corners[3], dn, Vector2(0, 1), c)
		quad_auto(b0, b1, b2, b3, dn)


func build(mat: Material = null) -> ArrayMesh:
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = v
	arrays[Mesh.ARRAY_NORMAL] = n
	arrays[Mesh.ARRAY_TEX_UV] = uv
	arrays[Mesh.ARRAY_COLOR] = col
	if with_uv2:
		arrays[Mesh.ARRAY_TEX_UV2] = uv2
	if with_tangents:
		arrays[Mesh.ARRAY_TANGENT] = tan
	arrays[Mesh.ARRAY_INDEX] = idx
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	if mat:
		m.surface_set_material(0, mat)
	return m
