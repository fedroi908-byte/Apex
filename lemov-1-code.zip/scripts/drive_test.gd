extends Node
var gw: GameWorld
var t := 0.0
var nxt := 1.0
func _ready() -> void:
	var a := OS.get_cmdline_user_args()
	G.start_hour = 11.0
	if a.size() > 0:
		G.selected_car = int(a[0])
	gw = GameWorld.new()
	add_child(gw)
func _physics_process(dt: float) -> void:
	t += dt
	if t > 0.5:
		gw.touch["gas"] = true
	if t > 14.0 and t < 15.0:
		gw.touch["gas"] = false
		gw.touch["brake"] = true
	if t > nxt:
		nxt += 1.0
		var p := gw.player
		print("T ", int(t), " kmh ", int(p.kmh()), " gear ", p.gear, " rpm ", snapped(p.rpm, 0.01), " y ", snapped(p.global_position.y, 0.01), " yaw ", snapped(p.yaw, 0.01))
	if t > 17.0:
		get_tree().quit()
