class_name GameWorld
extends Node3D
## The open world session: streaming, player car, chase camera, HUD, input.

signal exit_to_menu
signal restart_world

var atmo: Atmosphere
var terrain: TerrainClipmap
var water: WaterBuilder
var roads: RoadBuilder
var blds: BuildingBuilder
var player: Vehicle
var cam: Camera3D
var hud: Hud
var audio: GameAudio

var cam_mode := 0                   # 0 chase, 1 far chase, 2 cockpit
var cam_yaw := 0.0
var cam_pos := Vector3.ZERO
var shake := 0.0
var zoom: Array[float] = [1.0, 1.0, 1.0]         # per-view manual zoom (wheel / pinch); views switch only with the camera button
var _touches := {}
var _pinch_d := 0.0
var fov_cur := 70.0
var _t := 0.0
var touch := {"left": false, "right": false, "gas": false, "brake": false, "nitro": false, "drift": false}
var start_pos := Vector3.ZERO
var start_yaw := 0.0
var _stream_t := 0.0
var input_locked := false
var runner: MissionRunner
var pause_menu: PauseMenu
var result_ui: ResultScreen
var _last_pos := Vector3.ZERO
var _ft_acc := 0.0
var _ft_n := 0
var _stream_skip := 0


func _ready() -> void:
	W.load_all()
	atmo = Atmosphere.new()
	add_child(atmo)
	atmo.set_time(G.start_hour)
	terrain = TerrainClipmap.new()
	add_child(terrain)
	water = WaterBuilder.new()
	add_child(water)
	roads = RoadBuilder.new()
	add_child(roads)
	blds = BuildingBuilder.new()
	add_child(blds)
	blds.radius = Q.get_v("bld_dist") + 200.0

	_find_spawn()
	player = Vehicle.new()
	player.is_player = true
	var c := G.car()
	player.setup(String(c["model"]), c["color"], c)
	add_child(player)
	player.reset_to(start_pos, start_yaw)
	player.crashed.connect(_on_crash)

	cam = Camera3D.new()
	cam.far = 9000.0
	cam.near = 0.25
	cam.fov = 70.0
	add_child(cam)
	atmo.cam_ref = cam
	audio = GameAudio.new()
	add_child(audio)
	audio.setup(player, atmo)
	hud = Hud.new()
	hud.touch = touch
	add_child(hud)
	hud.menu_pressed.connect(func(): exit_to_menu.emit())
	hud.camera_pressed.connect(_next_cam)
	hud.reset_pressed.connect(_reset_car)
	G.apply_quality(get_viewport())
	cam_yaw = start_yaw
	atmo.set_weather([0.0, 0.45, 0.95][clampi(G.weather_pref, 0, 2)])
	_stream(true)
	_update_cam(1.0)
	_last_pos = player.global_position
	hud.menu_pressed.disconnect(hud.menu_pressed.get_connections()[0]["callable"])
	hud.menu_pressed.connect(_toggle_pause)
	if G.mode == "mission":
		var mm := Missions.by_id(G.mission_id)
		if not mm.is_empty():
			runner = MissionRunner.new()
			add_child(runner)
			runner.setup(self, mm)
			runner.finished.connect(_on_mission_done)
			_stream(true)


func _find_spawn() -> void:
	var best := 1e18
	var target := Vector3(380.0, 0.0, 1520.0)
	for r in W.roads:
		if r["cls"] != "avenue" and r["cls"] != "main":
			continue
		var pts: PackedVector3Array = r["pts"]
		for i in range(0, pts.size() - 2, 2):
			var d := Vector2(pts[i].x - target.x, pts[i].z - target.z).length_squared()
			if d < best:
				best = d
				start_pos = pts[i] + Vector3(0, 0.3, 0)
				var dir := pts[i + 2] - pts[i]
				start_yaw = atan2(dir.x, dir.z)
	start_pos.y = W.ground_height(start_pos.x, start_pos.z, start_pos.y + 2.0) + 0.1


func _reset_car() -> void:
	var p := W.nearest_road_point(player.global_position)
	if p >= 0:
		var q := W.astar.get_point_position(p)
		player.reset_to(q + Vector3(0, 0.3, 0), player.yaw)
	else:
		player.reset_to(start_pos, start_yaw)


func _on_crash(s: float) -> void:
	audio.crash(s)
	shake = clampf(s * 0.04, 0.0, 0.8)
	G.vibrate(int(clampf(s * 10.0, 20.0, 200.0)))


func _input_state() -> void:
	if input_locked:
		player.in_steer = 0.0
		player.in_gas = 0.0
		player.in_brake = 0.6
		player.in_nitro = false
		player.in_handbrake = true
		if runner and runner.state == "countdown":
			player.linear_velocity = Vector3.ZERO
			player.angular_velocity = Vector3.ZERO
		return
	var st := Input.get_axis("steer_right", "steer_left")
	var tl := 0.0
	if touch["left"]:
		tl += 1.0
	if touch["right"]:
		tl -= 1.0
	# our convention: +1 steers right
	var steer_in := -st if absf(st) > 0.01 else -tl
	if G.tilt_steering and absf(steer_in) < 0.01:
		var acc := Input.get_accelerometer()
		steer_in = clampf(-acc.x * 0.2 * G.steer_sensitivity, -1.0, 1.0)
	player.in_steer = steer_in
	player.in_gas = 1.0 if (Input.is_action_pressed("accelerate") or touch["gas"]) else 0.0
	player.in_brake = 1.0 if (Input.is_action_pressed("brake") or touch["brake"]) else 0.0
	player.in_nitro = Input.is_action_pressed("nitro") or touch["nitro"]
	player.in_handbrake = Input.is_action_pressed("drift") or touch["drift"]


func _toggle_pause() -> void:
	if result_ui:
		return
	if pause_menu:
		_resume()
		return
	pause_menu = PauseMenu.new()
	pause_menu.has_mission = runner != null
	add_child(pause_menu)
	pause_menu.resume.connect(_resume)
	pause_menu.restart.connect(func():
		get_tree().paused = false
		restart_world.emit())
	pause_menu.exit_menu.connect(func():
		get_tree().paused = false
		exit_to_menu.emit())
	get_tree().paused = true


func _resume() -> void:
	get_tree().paused = false
	if pause_menu:
		pause_menu.queue_free()
		pause_menu = null


func _on_mission_done(res: Dictionary) -> void:
	await get_tree().create_timer(1.2).timeout
	result_ui = ResultScreen.new()
	add_child(result_ui)
	result_ui.show_result(res)
	result_ui.retry.connect(func(): restart_world.emit())
	result_ui.free_roam.connect(func():
		G.mode = "free"
		restart_world.emit())
	result_ui.exit_menu.connect(func(): exit_to_menu.emit())


func _zoom_by(f: float) -> void:
	zoom[cam_mode] = clampf(zoom[cam_mode] * f, 0.45 if cam_mode != 2 else 0.6, 2.6 if cam_mode != 2 else 2.4)


func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed:
		if e.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_by(0.9)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_by(1.1)
	elif e is InputEventMagnifyGesture:
		_zoom_by(1.0 / maxf(e.factor, 0.2))
	elif e is InputEventScreenTouch:
		if e.pressed:
			_touches[e.index] = e.position
		else:
			_touches.erase(e.index)
		_pinch_d = 0.0
	elif e is InputEventScreenDrag:
		_touches[e.index] = e.position
		if _touches.size() == 2:
			var k := _touches.keys()
			var d: float = (_touches[k[0]] - _touches[k[1]]).length()
			if _pinch_d > 0.0 and d > 1.0:
				_zoom_by(_pinch_d / d)
			_pinch_d = d
	if e.is_action_pressed("camera"):
		_next_cam()
	elif e.is_action_pressed("reset_car"):
		_reset_car()
	elif e.is_action_pressed("horn"):
		audio.horn(true)
	elif e.is_action_pressed("pause"):
		_toggle_pause()


func _adapt_resolution(dt: float) -> void:
	# Dynamic resolution: keep the frame rate smooth by trading render scale, never below 55 %.
	if not G.dyn_res:
		return
	_ft_acc += dt
	_ft_n += 1
	if _ft_acc < 1.5:
		return
	var avg := _ft_acc / float(_ft_n)
	_ft_acc = 0.0
	_ft_n = 0
	var target := 1.0 / float(Q.cfg()["fps_cap"] if G.fps_limit_enabled else 60)
	var base := Q.base_scale()
	var cur := G.res_scale
	if avg > target * 1.3:
		cur = maxf(cur - 0.1, 0.55)
	elif avg < target * 0.85 and cur < base:
		cur = minf(cur + 0.05, base)
	if absf(cur - G.res_scale) > 0.001:
		G.res_scale = cur
		get_viewport().scaling_3d_scale = cur


func _process(dt: float) -> void:
	_t += dt
	_adapt_resolution(dt)
	G.total_distance_km += player.global_position.distance_to(_last_pos) / 1000.0 if player.global_position.distance_to(_last_pos) < 50.0 else 0.0
	_last_pos = player.global_position
	_input_state()
	if W.is_water(player.global_position.x, player.global_position.z) and player.global_position.y < 0.5:
		_reset_car()
	_update_cam(dt)
	_stream(false)
	var is_night: bool = atmo.elevation < -0.04
	player.set_headlights(is_night)
	hud.update_state(player, atmo, _t)
	if G.show_fps:
		hud.set_fps(Engine.get_frames_per_second())


func _stream(force: bool) -> void:
	var p := player.global_position
	terrain.follow(p)
	water.follow(p)
	if force:
		roads.build_all_near(p, 1)
		blds.build_all_near(p, 380.0)
		blds.radius = Q.get_v("bld_dist") + 200.0
	else:
		# never start a new cell build while frames are already slow (avoids hitch spirals on phones)
		if Engine.get_frames_per_second() > 24.0 or _t < 3.0:
			_stream_skip += 1
			if _stream_skip % 2 == 0:
				roads.update_focus(p)
			else:
				blds.update_focus(p)


func _has_cockpit() -> bool:
	return bool(G.car().get("cockpit", true)) and player.model.has_meta("eye")


func _next_cam() -> void:
	cam_mode = (cam_mode + 1) % 3
	if cam_mode == 2 and not _has_cockpit():        # cars without a usable interior skip the cockpit view
		cam_mode = 0


func _update_cam(dt: float) -> void:
	if cam_mode == 2 and not _has_cockpit():
		cam_mode = 0
	if cam_mode == 2:
		var eye: Vector3 = player.model.get_meta("eye")
		var sway := Vector3(player.lateral * -0.004, 0.0, 0.0)
		cam.near = 0.04
		cam.fov = lerpf(cam.fov, (78.0 + clampf(absf(player.speed) * 0.1, 0.0, 8.0)) * zoom[2], clampf(dt * 4.0, 0.0, 1.0))
		cam.global_transform = player.global_transform * Transform3D(Basis(Vector3.UP, PI), eye + sway)
		player.model.visible = true
		player.smoke.visible = false
		player.flame.visible = false
		return
	cam.near = 0.25
	player.smoke.visible = true
	player.flame.visible = true
	var spd := absf(player.speed)
	var f := player.flat_forward()
	# camera yaw lags behind the car heading (and follows velocity direction in drifts)
	var tgt := player.yaw - clampf(player.lateral * 0.03, -0.5, 0.5)
	cam_yaw = lerp_angle(cam_yaw, tgt, clampf(dt * (3.5 if cam_mode != 2 else 12.0), 0.0, 1.0))
	var dist := (6.2 + spd * 0.025) * zoom[0]
	var height := (2.1 + spd * 0.004) * (0.6 + 0.4 * zoom[0])
	if cam_mode == 1:
		dist = (10.5 + spd * 0.04) * zoom[1]
		height = 3.6 * (0.6 + 0.4 * zoom[1])
	var cf := Vector3(sin(cam_yaw), 0, cos(cam_yaw))
	var target_pos := player.global_position - cf * dist + Vector3(0, height, 0)
	var look := player.global_position + f * 4.0 + Vector3(0, 1.1, 0)
	if cam_mode == 2:
		target_pos = player.global_position + f * 0.4 + Vector3(0, 1.25, 0)
		look = player.global_position + f * 20.0 + Vector3(0, 1.1, 0)
	cam_pos = cam_pos.lerp(target_pos, clampf(dt * (10.0 if cam_mode != 2 else 40.0), 0.0, 1.0)) if _t > 0.05 else target_pos
	# keep the camera above ground
	var gy := W.terrain_height(cam_pos.x, cam_pos.z)
	cam_pos.y = maxf(cam_pos.y, gy + 0.8)
	var sh := Vector3.ZERO
	if shake > 0.001:
		sh = Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * shake * 0.25
		shake = move_toward(shake, 0.0, dt * 1.5)
	var boost := player.in_nitro and player.nitro > 0.02 and player.in_gas > 0.1
	var tfov := 68.0 + clampf(spd * 0.28, 0.0, 22.0) + (10.0 if boost else 0.0)
	fov_cur = lerpf(fov_cur, tfov, clampf(dt * 4.0, 0.0, 1.0))
	cam.fov = fov_cur
	cam.global_position = cam_pos + sh + (cam.global_transform.basis.x * sin(_t * 40.0) * 0.01 * (spd / 60.0) if spd > 30.0 else Vector3.ZERO)
	cam.look_at(look + sh * 0.5, Vector3.UP)
	player.model.visible = true
