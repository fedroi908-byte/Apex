class_name Vehicle
extends RigidBody3D
## Rigid-body car with per-wheel spring/damper suspension on a virtual ground (terrain + bridge decks),
## slip-angle tyre model with a friction ellipse, engine torque curve with gearbox, aero drag/downforce,
## hull contact for roll-overs, and crash deformation (dents are applied in the paint shader).

signal crashed(speed: float)

const GRAV := 9.81
const N_DENTS := 8

var body_kind := "sedan"
var color := Color(0.9, 0.2, 0.1)
var is_player := false
var stats: Dictionary = {}

# input
var in_steer := 0.0
var in_gas := 0.0
var in_brake := 0.0
var in_nitro := false
var in_handbrake := false

# car parameters (set in setup)
var car_mass := 1400.0
var wheel_r := 0.35
var wheelbase := 2.8
var track := 1.6
var t_max := 520.0                  # engine peak torque Nm
var rpm_idle := 900.0
var rpm_max := 7600.0
var gear_ratios := [3.55, 2.25, 1.62, 1.22, 0.98, 0.80]
var final_drive := 3.0
var drive_front := 0.0              # share of drive to the front axle
var cdA := 0.62
var clA := 0.25
var mu_tyre := 1.18
var max_steer := 0.55
var brake_bias := 0.62
var k_spring := 40000.0
var c_damp := 3200.0
var susp_len := 0.34
var arb := 16000.0

# state exposed to HUD / audio / camera
var speed := 0.0                    # signed km-independent forward speed in m/s
var lateral := 0.0
var yaw := 0.0
var steer := 0.0
var nitro := 1.0
var rpm := 0.0                      # 0..1
var gear := 1
var drifting := false
var slip := 0.0
var airborne := false
var damage := 0.0                   # 0..1
var model: Node3D
var wheels: Array = []
var spec: Dictionary = {}
var tail_mat: StandardMaterial3D
var tail_mats: Array = []
var head_mats: Array = []
var skid: GPUParticles3D
var smoke: GPUParticles3D
var flame: GPUParticles3D
var headlights: Array = []

var _anchors: Array = []            # local suspension anchor per wheel
var _comp_prev := [0.0, 0.0, 0.0, 0.0]
var _comp := [0.0, 0.0, 0.0, 0.0]
var _grounded := [false, false, false, false]
var _wheel_spin := [0.0, 0.0, 0.0, 0.0]
var _wheel_w := [0.0, 0.0, 0.0, 0.0]
var _gear_i := 0
var _eng_rpm := 900.0
var _shift_t := 0.0
var _hull_pts: Array = []
var _paint: ShaderMaterial
var _paints: Array = []
var _dents: PackedVector4Array = PackedVector4Array()
var _dent_dirs: PackedVector4Array = PackedVector4Array()
var _dent_n := 0
var _hit_cool := 0.0
var _last_vel := Vector3.ZERO
var _rest_wheel_y := [0.0, 0.0, 0.0, 0.0]
var _reverse := false
var _surface_mu := 1.0
var _ground_y_cache := 0.0


func setup(kind: String, col: Color, st: Dictionary = {}) -> void:
	body_kind = kind
	color = col
	stats = st
	var c := CarBuilder.build(kind, col)
	model = c["node"]
	wheels = c["wheels"]
	spec = c["spec"]
	tail_mat = c["tail"]
	tail_mats = c.get("tails", [])
	head_mats = c.get("heads", [])
	if model.has_meta("paint"):
		_paint = model.get_meta("paint") as ShaderMaterial
		_paints = model.get_meta("paints") if model.has_meta("paints") else [_paint]
	add_child(model)
	if not bool(Q.get_v("car_shadow")):
		# LOW quality: no real-time shadow from the (heavy) car meshes, use a cheap blob shadow instead
		for mi in model.find_children("*", "MeshInstance3D", true, false):
			(mi as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var blob := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(float(spec["wid"]) * 1.25, float(spec["len"]) * 1.15)
		qm.orientation = PlaneMesh.FACE_Y
		blob.mesh = qm
		var bm := StandardMaterial3D.new()
		bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		bm.albedo_color = Color(0, 0, 0, 0.45)
		bm.albedo_texture = _soft_tex()
		bm.render_priority = -1
		blob.material_override = bm
		blob.position = Vector3(0, 0.04, 0)
		blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(blob)
	wheel_r = float(spec["wr"])
	wheelbase = float(spec["wb"])
	track = float(spec["wid_track"]) if spec.has("wid_track") else float(spec["wid"]) * 0.5 - 0.07
	var tp := float(st.get("top_speed", 0.6))
	var ac := float(st.get("accel", 0.6))
	var hd := float(st.get("handling", 0.6))
	var phys := CarBuilder.phys_of(kind)
	match phys:
		"hyper":
			car_mass = 1380.0
			t_max = 380.0 + 360.0 * ac
			mu_tyre = 1.35
			clA = 0.9
			cdA = 0.62
			drive_front = 0.0
		"super":
			car_mass = 1500.0
			t_max = 360.0 + 330.0 * ac
			mu_tyre = 1.3
			clA = 0.6
			cdA = 0.66
			drive_front = 0.0
		"muscle":
			car_mass = 1850.0
			t_max = 560.0 + 200.0 * ac
			mu_tyre = 1.05
			clA = 0.1
			cdA = 0.72
			drive_front = 0.0
		"coupe":
			car_mass = 1450.0
			t_max = 340.0 + 300.0 * ac
			mu_tyre = 1.25
			clA = 0.35
			cdA = 0.64
		"sedan":
			car_mass = 1550.0
			t_max = 300.0 + 220.0 * ac
			mu_tyre = 1.12
			drive_front = 0.0
		"hatch":
			car_mass = 1150.0
			t_max = 240.0 + 150.0 * ac
			mu_tyre = 1.1
			drive_front = 1.0
			cdA = 0.66
		"suv":
			car_mass = 2100.0
			t_max = 420.0 + 150.0 * ac
			mu_tyre = 1.0
			drive_front = 0.4
			cdA = 0.95
		"pickup":
			car_mass = 2300.0
			t_max = 450.0 + 120.0 * ac
			mu_tyre = 0.98
			drive_front = 0.4
			cdA = 1.0
		"van":
			car_mass = 2400.0
			t_max = 380.0
			mu_tyre = 0.95
			drive_front = 1.0
			cdA = 1.2
		"bus":
			car_mass = 11500.0
			t_max = 1500.0
			mu_tyre = 0.9
			cdA = 4.5
	max_steer = 0.48 + 0.14 * hd
	var load := car_mass * GRAV / 4.0
	k_spring = load / 0.095
	c_damp = 2.0 * 0.42 * sqrt(k_spring * car_mass / 4.0)
	arb = k_spring * 0.5
	mass = car_mass
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0, 0.42 if phys != "bus" else 0.9, 0.0)
	var ext := Vector3(float(spec["wid"]), 1.3, float(spec["len"]))
	inertia = Vector3(car_mass * (ext.y * ext.y + ext.z * ext.z) / 11.0, car_mass * (ext.x * ext.x + ext.z * ext.z) / 11.0, car_mass * (ext.x * ext.x + ext.y * ext.y) / 11.0)
	linear_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	angular_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	linear_damp = 0.0
	angular_damp = 0.5
	collision_layer = 2
	collision_mask = 1 | 4
	continuous_cd = true
	contact_monitor = true
	max_contacts_reported = 6
	can_sleep = false
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(ext.x * 0.94, 0.86, ext.z * 0.96)
	cs.shape = sh
	cs.position = Vector3(0, 0.78, 0)
	add_child(cs)
	var ay := wheel_r + susp_len * 0.55
	_anchors = [Vector3(-track, ay, wheelbase * 0.5), Vector3(track, ay, wheelbase * 0.5), Vector3(-track, ay, -wheelbase * 0.5), Vector3(track, ay, -wheelbase * 0.5)]
	var hx := ext.x * 0.46
	var hz := ext.z * 0.46
	_hull_pts = [Vector3(-hx, 0.28, hz), Vector3(hx, 0.28, hz), Vector3(-hx, 0.28, -hz), Vector3(hx, 0.28, -hz),
		Vector3(-hx * 0.9, 1.25, hz * 0.55), Vector3(hx * 0.9, 1.25, hz * 0.55), Vector3(-hx * 0.9, 1.25, -hz * 0.55), Vector3(hx * 0.9, 1.25, -hz * 0.55)]
	if phys == "bus" or phys == "van":
		for p in _hull_pts.size():
			if (_hull_pts[p] as Vector3).y > 1.0:
				_hull_pts[p] = Vector3(_hull_pts[p].x, 2.4 if phys == "van" else 3.0, _hull_pts[p].z)
	for i in N_DENTS:
		_dents.append(Vector4(0, 0, 0, 0))
		_dent_dirs.append(Vector4(0, 0, 0, 0))
	_make_fx()
	_make_lights()
	_push_dents()


static func _soft_tex() -> GradientTexture2D:
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 1))
	g.set_color(1, Color(1, 1, 1, 0))
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 64
	t.height = 64
	return t


func _make_fx() -> void:
	smoke = GPUParticles3D.new()
	smoke.amount = 70
	smoke.lifetime = 1.6
	smoke.emitting = false
	smoke.local_coords = false
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 25.0
	pm.initial_velocity_min = 0.6
	pm.initial_velocity_max = 2.0
	pm.gravity = Vector3(0, 0.6, 0)
	pm.scale_min = 0.8
	pm.scale_max = 2.4
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.3))
	sc.add_point(Vector2(1, 1.4))
	var sct := CurveTexture.new()
	sct.curve = sc
	pm.scale_curve = sct
	var gr := Gradient.new()
	gr.set_color(0, Color(0.85, 0.85, 0.85, 0.5))
	gr.set_color(1, Color(0.85, 0.85, 0.85, 0.0))
	var gt := GradientTexture1D.new()
	gt.gradient = gr
	pm.color_ramp = gt
	smoke.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(1, 1)
	var mt := StandardMaterial3D.new()
	mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.vertex_color_use_as_albedo = true
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mt.albedo_texture = _soft_tex()
	qm.material = mt
	smoke.draw_pass_1 = qm
	smoke.position = Vector3(0, 0.3, -float(spec["len"]) * 0.35)
	add_child(smoke)
	flame = GPUParticles3D.new()
	flame.amount = 40
	flame.lifetime = 0.25
	flame.emitting = false
	flame.local_coords = false
	var fm := ParticleProcessMaterial.new()
	fm.direction = Vector3(0, 0, -1)
	fm.spread = 6.0
	fm.initial_velocity_min = 8.0
	fm.initial_velocity_max = 12.0
	fm.gravity = Vector3.ZERO
	fm.scale_min = 0.2
	fm.scale_max = 0.5
	var fg := Gradient.new()
	fg.set_color(0, Color(0.5, 0.8, 1.0, 1.0))
	fg.set_color(1, Color(0.2, 0.3, 1.0, 0.0))
	var fgt := GradientTexture1D.new()
	fgt.gradient = fg
	fm.color_ramp = fgt
	flame.process_material = fm
	var fq := QuadMesh.new()
	fq.size = Vector2(0.4, 0.4)
	var fmt := StandardMaterial3D.new()
	fmt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fmt.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fmt.vertex_color_use_as_albedo = true
	fmt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	fmt.albedo_texture = _soft_tex()
	fq.material = fmt
	flame.draw_pass_1 = fq
	flame.position = Vector3(0, 0.4, -float(spec["len"]) * 0.5)
	add_child(flame)


func _make_lights() -> void:
	if not is_player:
		return
	for sx in [-1.0, 1.0]:
		var sl := SpotLight3D.new()
		sl.position = Vector3(sx * float(spec["wid"]) * 0.3, 0.75, float(spec["len"]) * 0.5)
		sl.rotation = Vector3(deg_to_rad(-3), PI, 0)
		sl.spot_range = 70.0
		sl.spot_angle = 32.0
		sl.light_energy = 0.0
		sl.shadow_enabled = false
		add_child(sl)
		headlights.append(sl)


func set_headlights(on: bool) -> void:
	for h in headlights:
		(h as SpotLight3D).light_energy = 3.0 if on else 0.0
	for hm in head_mats:
		(hm as StandardMaterial3D).emission_energy_multiplier = 2.5 if on else 0.25


func reset_to(pos: Vector3, yaw_rad: float) -> void:
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	global_transform = Transform3D(Basis(Vector3.UP, yaw_rad), pos)
	yaw = yaw_rad
	speed = 0.0
	lateral = 0.0
	_gear_i = 0
	_eng_rpm = rpm_idle
	for i in 4:
		_comp[i] = 0.0
		_comp_prev[i] = 0.0
	repair()


func repair() -> void:
	damage = 0.0
	for i in N_DENTS:
		_dents[i] = Vector4(0, 0, 0, 0)
		_dent_dirs[i] = Vector4(0, 0, 0, 0)
	_dent_n = 0
	_push_dents()


func forward() -> Vector3:
	var f := -global_transform.basis.z
	return Vector3(f.x, 0, f.z).normalized() if false else global_transform.basis.z


func flat_forward() -> Vector3:
	var f := global_transform.basis.z
	f.y = 0.0
	return f.normalized() if f.length() > 0.01 else Vector3.FORWARD


func right() -> Vector3:
	var r := global_transform.basis.x
	r.y = 0.0
	return r.normalized() if r.length() > 0.01 else Vector3.RIGHT


func kmh() -> float:
	return absf(speed) * 3.6


func _push_dents() -> void:
	for pm in _paints:
		(pm as ShaderMaterial).set_shader_parameter("dents", _dents)
		(pm as ShaderMaterial).set_shader_parameter("dent_dirs", _dent_dirs)
		(pm as ShaderMaterial).set_shader_parameter("damage", damage)


func add_dent(local_pos: Vector3, local_dir: Vector3, amount: float) -> void:
	# merge into a nearby dent if there is one
	for i in _dent_n:
		var d := _dents[i]
		if Vector3(d.x, d.y, d.z).distance_to(local_pos) < 0.5:
			_dents[i].w = minf(d.w + amount, 0.55)
			var dd := Vector3(_dent_dirs[i].x, _dent_dirs[i].y, _dent_dirs[i].z) + local_dir * amount
			dd = dd.normalized()
			_dent_dirs[i] = Vector4(dd.x, dd.y, dd.z, 0)
			_push_dents()
			return
	var idx := _dent_n % N_DENTS
	_dents[idx] = Vector4(local_pos.x, local_pos.y, local_pos.z, minf(amount, 0.5))
	var ld := local_dir.normalized()
	_dent_dirs[idx] = Vector4(ld.x, ld.y, ld.z, 0)
	_dent_n += 1
	_push_dents()


func _engine_torque(r: float) -> float:
	# smooth torque curve peaking mid-range and falling towards the limiter
	var x := clampf((r - rpm_idle) / (rpm_max - rpm_idle), 0.0, 1.0)
	var curve := 0.55 + 1.6 * x - 1.55 * x * x * x
	curve = clampf(curve, 0.2, 1.0)
	if r > rpm_max * 0.985:
		curve *= 0.2
	return t_max * curve


func _surface_mu_at(p: Vector3) -> float:
	var rm := W.road_blend(p.x, p.z)
	var wet := 1.0 - 0.28 * float(RenderingServer.global_shader_parameter_get("wetness") if false else 0.0)
	return lerpf(0.78, 1.0, rm) * wet


func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	var dt := state.step
	var xf := state.transform
	var up := xf.basis.y
	var vel := state.linear_velocity
	var fwd_flat := xf.basis.z
	fwd_flat.y = 0.0
	fwd_flat = fwd_flat.normalized() if fwd_flat.length() > 0.01 else Vector3.FORWARD
	speed = vel.dot(xf.basis.z)
	lateral = vel.dot(xf.basis.x)
	yaw = atan2(xf.basis.z.x, xf.basis.z.z)
	# ----- steering
	var spd := absf(speed)
	var steer_lim := max_steer / (1.0 + spd * spd * 0.0016)
	var target := in_steer * steer_lim
	steer = lerpf(steer, target, clampf(dt * (10.0 if absf(target) > absf(steer) else 14.0), 0.0, 1.0))
	# ----- gearbox / engine
	var wheel_w_drive := 0.0
	wheel_w_drive = spd / wheel_r
	var ratio := 0.0
	var boosting := in_nitro and nitro > 0.02 and in_gas > 0.1
	_reverse = false
	if in_brake > 0.05 and speed < 0.8 and in_gas < 0.05:
		_reverse = true
	if _reverse:
		gear = -1
		ratio = -3.2 * final_drive
	else:
		var gr: float = gear_ratios[_gear_i]
		ratio = gr * final_drive
		var r_try := wheel_w_drive * ratio * 60.0 / TAU
		_shift_t = maxf(_shift_t - dt, 0.0)
		if _shift_t <= 0.0:
			if r_try > rpm_max * 0.86 and _gear_i < gear_ratios.size() - 1:
				_gear_i += 1
				_shift_t = 0.22
			elif r_try < rpm_max * 0.42 and _gear_i > 0:
				_gear_i -= 1
				_shift_t = 0.15
		gear = _gear_i + 1
		ratio = gear_ratios[_gear_i] * final_drive
	var wheel_rpm := wheel_w_drive * absf(ratio) * 60.0 / TAU
	var target_rpm := maxf(rpm_idle, wheel_rpm)
	if in_gas > 0.05 and spd < 6.0:
		target_rpm = maxf(target_rpm, rpm_idle + in_gas * 0.55 * (rpm_max - rpm_idle) * clampf(1.0 - spd / 8.0, 0.2, 1.0))
	_eng_rpm = lerpf(_eng_rpm, target_rpm, clampf(dt * 9.0, 0.0, 1.0))
	rpm = clampf((_eng_rpm - rpm_idle) / (rpm_max - rpm_idle), 0.0, 1.0)
	var torque := _engine_torque(_eng_rpm) * in_gas * (1.0 if _shift_t <= 0.0 else 0.2)
	if boosting:
		torque *= 1.6
		nitro = maxf(nitro - dt * 0.17, 0.0)
	else:
		nitro = minf(nitro + dt * 0.035 * (1.0 if in_gas > 0.1 else 0.4), 1.0)
	var drive_total := torque * ratio * 0.9 / wheel_r             # N at the contact patches
	if wheel_rpm > rpm_max * 1.02 and not _reverse:
		drive_total = 0.0
	# ----- aero
	var v2 := vel.length_squared()
	var vdir := vel.normalized() if vel.length() > 0.1 else Vector3.ZERO
	state.apply_central_force(-vdir * (0.5 * 1.2 * cdA * v2 + 0.012 * car_mass * GRAV * minf(vel.length(), 1.0)))
	state.apply_central_force(-up * 0.5 * 1.2 * clA * v2)
	# ----- suspension and tyres
	var grounded := 0
	var total_slip := 0.0
	var hs_brake := in_handbrake
	for i in 4:
		var local_anchor: Vector3 = _anchors[i]
		var anchor := xf * local_anchor
		var ground_y := W.ground_height(anchor.x, anchor.z, anchor.y + 0.5)
		var nrm := W.terrain_normal(anchor.x, anchor.z)
		var ray_len := susp_len + wheel_r
		var d := anchor.y - ground_y            # vertical distance anchor -> ground (assumes near vertical)
		d *= maxf(up.y, 0.2)
		var comp := ray_len - d
		var contact := comp > 0.0 and d > -0.5
		_grounded[i] = contact
		var load := 0.0
		if contact:
			grounded += 1
			var comp_c := minf(comp, susp_len + 0.12)
			var cvel: float = (comp_c - _comp_prev[i]) / dt
			_comp_prev[i] = comp_c
			_comp[i] = comp_c
			# anti roll bar couples left/right
			var other: int = i ^ 1
			var arb_f: float = arb * (comp_c - _comp[other]) * 0.5 if _grounded[other] else 0.0
			load = maxf(k_spring * comp_c + c_damp * cvel + arb_f, 0.0)
			load = minf(load, car_mass * GRAV * 2.4)
		else:
			_comp_prev[i] = 0.0
			_comp[i] = lerpf(_comp[i], -0.02, clampf(dt * 6.0, 0.0, 1.0))
		var contact_pt := Vector3(anchor.x, ground_y if contact else anchor.y - ray_len, anchor.z)
		var rel := contact_pt - xf.origin
		# visual wheel position
		var ext := clampf(d - wheel_r, 0.04, susp_len + 0.16) if contact else susp_len + 0.1
		var wp: Node3D = wheels[i]
		wp.position = Vector3(local_anchor.x, local_anchor.y - ext, local_anchor.z)
		if not contact:
			_wheel_w[i] = lerpf(_wheel_w[i], speed / wheel_r * 0.3, dt * 0.5)
			continue
		# normal force along ground normal (mostly up)
		var nforce := nrm * load
		state.apply_force(nforce, rel)
		# tyre frame
		var steer_a := steer if i < 2 else 0.0
		var wf := (Basis(up, -steer_a) * fwd_flat) if absf(steer_a) > 0.0001 else fwd_flat
		wf = (wf - nrm * wf.dot(nrm)).normalized()
		var wl := nrm.cross(wf).normalized()
		var cv := state.get_velocity_at_local_position(rel)
		var vlong := cv.dot(wf)
		var vlat := cv.dot(wl)
		var mu := mu_tyre * _surface_mu_at(contact_pt)
		var rear := i >= 2
		var drive_share := drive_front if not rear else (1.0 - drive_front)
		var fx := drive_total * drive_share * 0.5
		# brakes
		var brake_f := 0.0
		if in_brake > 0.05 and not _reverse:
			var share := brake_bias if not rear else (1.0 - brake_bias)
			brake_f = in_brake * load * mu * 1.0 * share * 2.0
		var lock := 0.0
		if hs_brake and rear:
			lock = 1.0
		var fx_req := fx
		if absf(vlong) > 0.05:
			fx_req -= signf(vlong) * (brake_f + lock * load * mu * 0.95)
		else:
			fx_req -= vlong * 4000.0 * (1.0 if (in_brake > 0.05 or in_gas < 0.05) else 0.0)
		# reverse: brake pedal drives backwards
		if _reverse:
			fx_req = drive_total * drive_share * 0.5 * in_brake * 0.0
			fx_req = (-3200.0 * in_brake) * drive_share * 0.5 * 1.0
		# lateral slip-angle force
		var sa := atan2(vlat, absf(vlong) + 0.8)
		var lat_gain := clampf(absf(vlat) / 0.35, 0.0, 1.0) if absf(vlong) < 2.0 else 1.0
		var mu_l := mu * (0.55 if lock > 0.5 else 1.0)
		var fy_req := -load * mu_l * sin(1.55 * atan(7.5 * sa)) * lat_gain
		# friction ellipse
		var fmax := load * mu
		var mag := sqrt(fx_req * fx_req + fy_req * fy_req)
		if mag > fmax and mag > 0.001:
			var k := fmax / mag
			fx_req *= k
			fy_req *= k
			total_slip += 1.0
		# low-speed lateral stiction: tyres hold the car still
		if spd < 1.5 and absf(vlat) < 1.5:
			fy_req += -vlat * load * 0.8
		var force := wf * fx_req + wl * fy_req
		state.apply_force(force, rel)
		_wheel_w[i] = vlong / wheel_r
		if (absf(fx) > fmax * 0.9 and in_gas > 0.5 and spd < 40.0 and rear):
			_wheel_w[i] = vlong / wheel_r + 25.0 * in_gas
		if lock > 0.5 and spd > 3.0:
			_wheel_w[i] = 0.0
	airborne = grounded == 0
	slip = clampf(absf(lateral) / maxf(spd, 5.0), 0.0, 1.0)
	drifting = (absf(lateral) > 3.2 and spd > 8.0) or (hs_brake and spd > 8.0) or (total_slip > 1.5 and spd > 12.0)
	# ----- hull contact with the virtual ground (roll-overs, hard landings)
	for hp in _hull_pts:
		var wp2 := xf * (hp as Vector3)
		var gy := W.ground_height(wp2.x, wp2.z, wp2.y + 0.5)
		var pen := gy - wp2.y
		if pen > 0.0:
			var rel2 := wp2 - xf.origin
			var hv := state.get_velocity_at_local_position(rel2)
			var fn := clampf(90000.0 * pen - 2500.0 * hv.y, 0.0, car_mass * GRAV * 4.0)
			state.apply_force(Vector3.UP * fn, rel2)
			var tang := Vector3(hv.x, 0, hv.z)
			state.apply_force(-tang * minf(fn * 0.6 / maxf(tang.length(), 0.5), 6000.0) , rel2)
			if fn > car_mass * GRAV * 2.0 and _hit_cool <= 0.0:
				_hit_cool = 0.4
				crashed.emit(absf(hv.y) + 4.0)
	# weak stabilising torque so tiny perturbations on the road do not build up
	# ----- crash detection from contacts
	_hit_cool = maxf(_hit_cool - dt, 0.0)
	var cc := state.get_contact_count()
	if cc > 0 and _hit_cool <= 0.0:
		var best := 0.0
		var bp := Vector3.ZERO
		var bn := Vector3.ZERO
		for ci in cc:
			var imp := state.get_contact_impulse(ci).length() / car_mass
			if imp > best:
				best = imp
				bp = state.get_contact_local_position(ci)
				bn = state.get_contact_local_normal(ci)
		if best > 2.2:
			_hit_cool = 0.35
			var inv := xf.affine_inverse()
			var lp := inv * bp
			var ln := (inv.basis * -bn).normalized()
			add_dent(lp, ln, clampf(best * 0.035, 0.03, 0.4))
			damage = clampf(damage + best * 0.012, 0.0, 1.0)
			crashed.emit(best)
	_last_vel = vel
	# anti-tumble when upside down on the ground: leave physics alone
	# lights / fx
	var wheel_avg := 0.0
	for i in 4:
		_wheel_spin[i] += _wheel_w[i] * dt
	_after_physics(dt, boosting)


func _after_physics(dt: float, boosting: bool) -> void:
	for pm in _paints:
		(pm as ShaderMaterial).set_shader_parameter("car_to_world", global_transform)
	for i in wheels.size():
		var w: Node3D = wheels[i]
		w.rotation = Vector3(0, -steer if i < 2 else 0.0, 0)
		(w.get_child(0) as Node3D).rotation.x = _wheel_spin[i]
	if model.has_meta("steer_pivot"):
		var sax: Vector3 = model.get_meta("steer_axis") if model.has_meta("steer_axis") else Vector3(0, 0.35, -0.94).normalized()
		(model.get_meta("steer_pivot") as Node3D).basis = Basis(sax, -steer * (11.0 if model.has_meta("steer_axis") else 7.5))
	smoke.emitting = (drifting and absf(speed) > 8.0 and not airborne) or (damage > 0.7 and absf(speed) > 2.0)
	flame.emitting = boosting
	if tail_mats.is_empty():
		tail_mats = [tail_mat] if tail_mat else []
	for tm in tail_mats:
		(tm as StandardMaterial3D).emission_energy_multiplier = 0.5 + 2.5 * in_brake
