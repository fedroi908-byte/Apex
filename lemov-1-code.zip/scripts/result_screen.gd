class_name ResultScreen
extends CanvasLayer
## Mission result card with animated stars.

signal retry
signal free_roam
signal exit_menu


func show_result(res: Dictionary) -> void:
	layer = 30
	process_mode = Node.PROCESS_MODE_ALWAYS
	var m: Dictionary = res["mission"]
	var ok: bool = res["success"]
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.6)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var p := Ui.panel(Color(0.03, 0.05, 0.09, 0.95), 24)
	p.custom_minimum_size = Vector2(760, 520)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(cc)
	cc.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	p.add_child(v)
	var h := Ui.label("MISSION COMPLETE" if ok else "MISSION FAILED", 54, Ui.GOOD if ok else Color(1, 0.3, 0.25), true)
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(h)
	var n := Ui.label(String(m["name"]), 30, Ui.DIM)
	n.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(n)
	var sr := HBoxContainer.new()
	sr.alignment = BoxContainer.ALIGNMENT_CENTER
	sr.add_theme_constant_override("separation", 18)
	v.add_child(sr)
	for i in 3:
		var s := Ui.label("★", 96, Ui.GOLD if i < int(res["stars"]) else Color(1, 1, 1, 0.15))
		s.pivot_offset = Vector2(48, 48)
		s.scale = Vector2.ZERO
		sr.add_child(s)
		var tw := create_tween()
		tw.tween_interval(0.35 + 0.3 * i)
		tw.tween_property(s, "scale", Vector2.ONE * (1.0 if i < int(res["stars"]) else 0.8), 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		if i < int(res["stars"]):
			tw.tween_callback(func(): G.ui("checkpoint", -6.0))
	var val: float = res["value"]
	var line := ""
	match String(m["type"]):
		"drift":
			line = "Score %d" % int(val)
		_:
			line = "Time %d:%04.1f" % [int(val / 60.0), fmod(val, 60.0)]
	line += "    Top speed %d km/h" % int(res["top"])
	var l := Ui.label(line, 26, Color.WHITE)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(l)
	var rw := Ui.label("+ $ %d" % int(res["reward"]), 40, Ui.GOLD, true)
	rw.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(rw)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	v.add_child(row)
	for it in [["RETRY", func(): retry.emit(), Ui.HOT], ["FREE ROAM", func(): free_roam.emit(), Ui.ACCENT], ["MENU", func(): exit_menu.emit(), Ui.DIM]]:
		var b := Ui.button(it[0], it[1], it[2], 22, Vector2(220, 60))
		b.alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.process_mode = Node.PROCESS_MODE_ALWAYS
		row.add_child(b)
	p.modulate.a = 0.0
	p.create_tween().tween_property(p, "modulate:a", 1.0, 0.3)
