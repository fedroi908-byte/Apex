class_name Q
extends RefCounted
## Central graphics-quality table. Everything that scales with settings reads from here.
## Levels: 0 Low, 1 Medium, 2 High, 3 Ultra

const NAMES := ["LOW", "MEDIUM", "HIGH", "ULTRA"]

const TABLE := [
	{ # LOW
		"msaa": Viewport.MSAA_DISABLED, "shadow_size": 1024, "shadow_splits": 1, "shadow_dist": 70.0,
		"shadow_blur": 0.0, "tree_dist": 150.0, "bld_dist": 650.0, "prop_dist": 110.0, "traffic": 6,
		"ped": 0, "glow": false, "terrain_levels": 5, "clouds": false, "rain_particles": 400,
		"car_detail": 0, "reflections": false, "grass": 0, "fps_cap": 30, "aa_fxaa": true, "scale": 0.75, "phys_hz": 60, "car_shadow": false,
	},
	{ # MEDIUM
		"msaa": Viewport.MSAA_2X, "shadow_size": 2048, "shadow_splits": 2, "shadow_dist": 140.0,
		"shadow_blur": 0.6, "tree_dist": 260.0, "bld_dist": 1100.0, "prop_dist": 200.0, "traffic": 12,
		"ped": 10, "glow": false, "terrain_levels": 6, "clouds": true, "rain_particles": 1200,
		"car_detail": 1, "reflections": true, "grass": 0, "fps_cap": 60, "aa_fxaa": false, "scale": 0.9, "phys_hz": 90, "car_shadow": true,
	},
	{ # HIGH
		"msaa": Viewport.MSAA_2X, "shadow_size": 2048, "shadow_splits": 4, "shadow_dist": 260.0,
		"shadow_blur": 1.0, "tree_dist": 420.0, "bld_dist": 1700.0, "prop_dist": 300.0, "traffic": 20,
		"ped": 24, "glow": true, "terrain_levels": 7, "clouds": true, "rain_particles": 2500,
		"car_detail": 2, "reflections": true, "grass": 1, "fps_cap": 60, "aa_fxaa": false, "scale": 1.0, "phys_hz": 120, "car_shadow": true,
	},
	{ # ULTRA
		"msaa": Viewport.MSAA_4X, "shadow_size": 4096, "shadow_splits": 4, "shadow_dist": 420.0,
		"shadow_blur": 1.6, "tree_dist": 650.0, "bld_dist": 2500.0, "prop_dist": 420.0, "traffic": 32,
		"ped": 40, "glow": true, "terrain_levels": 7, "clouds": true, "rain_particles": 5000,
		"car_detail": 3, "reflections": true, "grass": 2, "fps_cap": 60, "aa_fxaa": false, "scale": 1.0, "phys_hz": 120, "car_shadow": true,
	},
]


static func cfg() -> Dictionary:
	return TABLE[clampi(G.quality, 0, TABLE.size() - 1)]


## Render scale for the current level, additionally capped so the 3D resolution never exceeds the level's pixel-height budget.
static func base_scale() -> float:
	var sh := float(maxi(DisplayServer.window_get_size().y, 1))
	var budget: float = [840.0, 1000.0, 1300.0, 2000.0][clampi(G.quality, 0, 3)]
	return clampf(minf(float(cfg()["scale"]), budget / sh), 0.4, 1.0)


static func get_v(key: String) -> Variant:
	return cfg()[key]


## Push the current level into every global setting (viewport, shadow atlas, shader globals).
static func apply(vp: Viewport) -> void:
	var c := cfg()
	if vp:
		vp.msaa_3d = c["msaa"]
		vp.scaling_3d_scale = G.res_scale if G.dyn_res else base_scale()
		vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
		vp.use_taa = false
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if c["aa_fxaa"] else Viewport.SCREEN_SPACE_AA_DISABLED
	RenderingServer.directional_shadow_atlas_set_size(c["shadow_size"], true)
	RenderingServer.directional_soft_shadow_filter_set_quality(
		RenderingServer.SHADOW_QUALITY_SOFT_LOW if G.quality <= 1 else (RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM if G.quality == 2 else RenderingServer.SHADOW_QUALITY_SOFT_HIGH))
	RenderingServer.global_shader_parameter_set("quality", float(G.quality))
	Engine.physics_ticks_per_second = int(c["phys_hz"])
	Engine.max_physics_steps_per_frame = 4 if G.quality <= 1 else 6
	Engine.max_fps = int(c["fps_cap"]) if G.fps_limit_enabled else 0
