class_name GameAudio
extends Node
## Layered car audio, ambience, rain and music. All sounds are procedurally synthesised WAVs (tools/gen_audio.py).

var car: Vehicle
var atmo: Atmosphere
var p := {}
var music: AudioStreamPlayer
var _was_boost := false
var _last_gear := 1
var _horn: AudioStreamPlayer


func _load(name: String, loop: bool) -> AudioStreamWAV:
	var s: AudioStreamWAV = load("res://assets/audio/%s.wav" % name)
	if s and loop:
		s = s.duplicate()
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = int(s.get_length() * s.mix_rate)
	return s


func _mk(name: String, loop: bool, vol_db: float = 0.0, autoplay: bool = true) -> AudioStreamPlayer:
	var pl := AudioStreamPlayer.new()
	pl.stream = _load(name, loop)
	pl.volume_db = vol_db
	pl.bus = "Master"
	add_child(pl)
	if autoplay and pl.stream:
		pl.play()
	return pl


func setup(c: Vehicle, a: Atmosphere) -> void:
	car = c
	atmo = a
	for n in ["engine_low", "engine_mid", "engine_high", "turbo", "skid", "wind", "road", "rain", "ambience_city"]:
		p[n] = _mk(n, true, -40.0)
	p["engine_low"].volume_db = -6.0
	music = _mk("music_drive", true, linear_to_db(maxf(G.music_volume, 0.001)) - 8.0)
	_horn = _mk("horn", false, -4.0, false)


func one_shot(name: String, vol_db: float = 0.0, pitch: float = 1.0) -> void:
	var pl := _mk(name, false, vol_db + linear_to_db(maxf(G.sfx_volume, 0.001)), false)
	pl.pitch_scale = pitch
	pl.finished.connect(pl.queue_free)
	pl.play()


func horn(on: bool) -> void:
	if on and not _horn.playing:
		_horn.play()


func _process(dt: float) -> void:
	if car == null:
		return
	var sfx := linear_to_db(maxf(G.sfx_volume, 0.001))
	var rpm := car.rpm
	var thr := car.in_gas
	var load_f := lerpf(0.55, 1.0, thr)
	# three engine layers cross-faded over rpm, pitch follows rpm
	var lo := clampf(1.0 - rpm * 2.0, 0.0, 1.0)
	var mi := 1.0 - absf(rpm - 0.5) * 2.5
	mi = clampf(mi, 0.0, 1.0)
	var hi := clampf((rpm - 0.45) * 2.2, 0.0, 1.0)
	var pit := lerpf(0.75, 1.9, rpm)
	_lay("engine_low", lo + 0.15, pit * 1.0, sfx - 3.0, load_f)
	_lay("engine_mid", mi + 0.1, pit * 0.95, sfx - 4.0, load_f)
	_lay("engine_high", hi, pit * 0.9, sfx - 5.0, load_f)
	_lay("turbo", clampf((rpm - 0.4) * thr * 1.2, 0.0, 1.0) * 0.5, lerpf(0.8, 1.6, rpm), sfx - 14.0, 1.0)
	var skid := 0.0
	if car.drifting and not car.airborne:
		skid = clampf(car.slip * 2.0 + 0.2, 0.0, 1.0)
	if car.in_brake > 0.5 and car.speed > 20.0:
		skid = maxf(skid, 0.4)
	_lay("skid", skid, lerpf(0.9, 1.25, car.slip), sfx - 8.0, 1.0)
	var spd := clampf(car.kmh() / 200.0, 0.0, 1.0)
	_lay("wind", spd * spd, 0.8 + spd * 0.6, sfx - 10.0, 1.0)
	_lay("road", spd * (0.0 if car.airborne else 1.0), 0.8 + spd * 0.7, sfx - 14.0, 1.0)
	var rain_v: float = atmo.rain if atmo else 0.0
	_lay("rain", rain_v, 1.0, sfx - 9.0, 1.0)
	var day: float = clampf(atmo.elevation * 4.0, 0.0, 1.0) if atmo else 1.0
	_lay("ambience_city", 0.5 * (1.0 - spd * 0.7), 1.0, sfx - 14.0, 1.0)
	music.volume_db = linear_to_db(maxf(G.music_volume, 0.001)) - 9.0
	var boost := car.in_nitro and car.nitro > 0.02 and car.in_gas > 0.1
	if boost and not _was_boost:
		one_shot("nitro", -4.0)
	_was_boost = boost
	if car.gear != _last_gear and car.gear > _last_gear and thr > 0.5:
		one_shot("shift", -12.0, randf_range(0.9, 1.1))
	_last_gear = car.gear
	if Input.is_action_just_pressed("ui_accept") or false:
		pass


func _lay(n: String, v: float, pitch: float, base_db: float, mul: float) -> void:
	var pl: AudioStreamPlayer = p.get(n)
	if pl == null:
		return
	var vv := clampf(v * mul, 0.0, 1.0)
	pl.volume_db = -60.0 if vv < 0.01 else base_db + linear_to_db(vv)
	pl.pitch_scale = maxf(pitch, 0.1)


func crash(speed: float) -> void:
	one_shot("crash" if speed > 12.0 else "bump", clampf(speed * 0.3 - 6.0, -10.0, 0.0))
