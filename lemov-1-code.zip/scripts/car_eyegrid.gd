extends Node3D
## QA harness: cockpit shots from several candidate eye points.  usage: EYES="x,y,z;x,y,z" godot ... car_eyegrid.tscn -- <car_id>   -> /tmp/eye/<id>_<i>.png
var kind := ""
var eyes: Array = []
var i := 0
var f := 0
var cam: Camera3D
func _ready() -> void:
	kind = String(OS.get_cmdline_user_args()[0])
	for s in OS.get_environment("EYES").split(";"):
		var p := s.split(",")
		if p.size() == 3:
			eyes.append(Vector3(float(p[0]), float(p[1]), float(p[2])))
	DirAccess.make_dir_recursive_absolute("/tmp/eye")
	var at := Atmosphere.new()
	add_child(at)
	at.paused = true
	at.set_time(14.0)
	var floor_m := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(60, 60)
	floor_m.mesh = pm
	add_child(floor_m)
	var col := Color(0.8, 0.1, 0.1)
	for c in G.cars:
		if c["id"] == kind:
			col = c["color"]
	var r := CarBuilder.build(kind, col, Color(0.05, 0.05, 0.06))
	add_child(r["node"])
	for pmat in r["node"].get_meta("paints"):
		(pmat as ShaderMaterial).set_shader_parameter("car_to_world", Transform3D.IDENTITY)
	cam = Camera3D.new()
	cam.fov = 78
	cam.near = 0.03
	add_child(cam)
func _process(_d: float) -> void:
	f += 1
	if i >= eyes.size():
		print("EYE_DONE")
		get_tree().quit()
		return
	if f == 1:
		cam.global_transform = Transform3D(Basis(Vector3.UP, PI), eyes[i])
	elif f == 5:
		get_viewport().get_texture().get_image().save_png("/tmp/eye/%s_%d.png" % [kind, i])
		i += 1
		f = 0
