class_name WaterBuilder
extends Node3D
## Sea plane (follows the camera), lake polygon and river ribbon.

var sea: MeshInstance3D
var sea_mat: ShaderMaterial
var base_mat: ShaderMaterial


func _make_mat(level: float, flow: float) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/water.gdshader")
	m.set_shader_parameter("heightmap", base_mat.get_shader_parameter("heightmap") if base_mat else ImageTexture.create_from_image(W.hm_image))
	m.set_shader_parameter("world_size", W.size)
	m.set_shader_parameter("hn", float(W.n))
	m.set_shader_parameter("hmin", W.hmin)
	m.set_shader_parameter("hrange", W.hmax - W.hmin)
	m.set_shader_parameter("level", level)
	m.set_shader_parameter("flow", flow)
	return m


func _ready() -> void:
	base_mat = _make_mat(0.0, 0.0)
	# --- sea
	sea = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(26000, 26000)
	pm.subdivide_width = 1
	pm.subdivide_depth = 1
	sea.mesh = pm
	sea.material_override = base_mat
	sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	sea.extra_cull_margin = 20000.0
	add_child(sea)
	# --- lake
	var lake: Dictionary = W.water["lake"]
	var lvl: float = lake["level"]
	var poly := PackedVector2Array()
	for p in lake["poly"]:
		poly.append(Vector2(p[0], p[1]))
	var tri := Geometry2D.triangulate_polygon(poly)
	if tri.size() > 0:
		var verts := PackedVector3Array()
		for p in poly:
			verts.append(Vector3(p.x, lvl, p.y))
		var arr := []
		arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = verts
		arr[Mesh.ARRAY_INDEX] = tri
		var am := ArrayMesh.new()
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		var mi := MeshInstance3D.new()
		mi.mesh = am
		var lm := _make_mat(lvl - 0.1, 0.0)
		lm.set_shader_parameter("shallow_col", Color(0.12, 0.48, 0.50))
		lm.set_shader_parameter("deep_col", Color(0.02, 0.17, 0.24))
		lm.set_shader_parameter("wave_amp", 0.5)
		mi.material_override = lm
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
	# --- river ribbon
	var rv: Dictionary = W.water["river"]
	var xs: Array = rv["x"]
	var zs: Array = rv["z"]
	var ys: Array = rv["y"]
	var hw: float = float(rv["width"]) * 0.5
	var rverts := PackedVector3Array()
	var ridx := PackedInt32Array()
	var cnt := xs.size()
	for i in cnt:
		var a := Vector3(xs[maxi(i - 1, 0)], 0, zs[maxi(i - 1, 0)])
		var b := Vector3(xs[mini(i + 1, cnt - 1)], 0, zs[mini(i + 1, cnt - 1)])
		var t := (b - a).normalized()
		var nrm := Vector3(-t.z, 0, t.x)
		var c := Vector3(xs[i], ys[i] - 0.15, zs[i])
		rverts.append(c - nrm * hw)
		rverts.append(c + nrm * hw)
		if i > 0:
			var k := (i - 1) * 2
			ridx.append_array([k, k + 2, k + 1, k + 1, k + 2, k + 3])
	var arr2 := []
	arr2.resize(Mesh.ARRAY_MAX)
	arr2[Mesh.ARRAY_VERTEX] = rverts
	arr2[Mesh.ARRAY_INDEX] = ridx
	var rm := ArrayMesh.new()
	rm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr2)
	var rmi := MeshInstance3D.new()
	rmi.mesh = rm
	var rmat := _make_mat(0.0, 1.0)
	rmat.set_shader_parameter("level", -9999.0 + 10000.0)   # depth computed vs surface below
	rmat.set_shader_parameter("level", 9999.0)
	rmat.set_shader_parameter("wave_amp", 0.6)
	rmi.material_override = rmat
	rmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(rmi)


func follow(p: Vector3) -> void:
	sea.position = Vector3(floorf(p.x / 64.0) * 64.0, 0.0, floorf(p.z / 64.0) * 64.0)
