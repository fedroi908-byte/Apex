extends Node
## Global game state (autoload "G"): settings, car/track catalogue, save data.

signal settings_changed

const SAVE_PATH := "user://lemov_save.json"

# ---------------------------------------------------------------- catalogue
# Stats are on a 0..1 scale and are mapped to physics values in vehicle.gd
## Car catalogue: built at start from res://data/cars.json (+ server overlay via add_remote_cars()).
var cars: Array[Dictionary] = []

func _load_cars() -> void:
	cars.clear()
	var d: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/cars.json"))
	if d is Dictionary:
		for c in (d as Dictionary).get("cars", []):
			cars.append(_car_from_json(c))
	if cars.is_empty():      # the game must never break because of a bad catalogue
		cars.append(_car_from_json({"id": "rosso", "model": "ferrari", "name": "ROSSO 458", "tagline": "Mid-engine Italian V8 spider", "color": "#c70a0d",
			"accent": "#14141a", "top_speed": 0.8, "accel": 0.82, "handling": 0.8, "nitro": 0.6, "price": 0}))


func _car_from_json(c: Dictionary) -> Dictionary:
	var o: Dictionary = c.duplicate(true)
	o["color"] = Color.html(String(c.get("color", "#c70a0d")))
	o["accent"] = Color.html(String(c.get("accent", "#14141a")))
	return o


## Server-delivered cars (already verified by the updater). Existing ids are replaced, new ones appended.
func add_remote_cars(list: Array) -> void:
	for c in list:
		if not (c is Dictionary) or not (c as Dictionary).has("id"):
			continue
		var o := _car_from_json(c)
		var found := -1
		for i in cars.size():
			if cars[i]["id"] == o["id"]:
				found = i
		if found >= 0:
			cars[found] = o
		else:
			cars.append(o)
		if o.has("path"):
			CarBuilder.register_cfg(o)

const PAINTS: Array[Color] = [
	Color(0.78, 0.04, 0.05), Color(0.95, 0.42, 0.05), Color(0.96, 0.78, 0.08), Color(0.08, 0.55, 0.22),
	Color(0.05, 0.35, 0.9), Color(0.55, 0.20, 0.95), Color(0.93, 0.93, 0.95), Color(0.05, 0.05, 0.07),
]
const PAINT_NAMES := ["Rosso", "Arancio", "Giallo", "Verde", "Blu", "Viola", "Bianco", "Nero"]

const TRACKS: Array[Dictionary] = [
	{"id": "harbor", "name": "HARBOR SPRINT", "desc": "Sunset coastal circuit", "laps": 3, "theme": 0},
	{"id": "neon", "name": "NEON CITY", "desc": "Night street circuit", "laps": 3, "theme": 1},
	{"id": "alpine", "name": "ALPINE PASS", "desc": "Mountain hill climb loop", "laps": 3, "theme": 2},
]

# ---------------------------------------------------------------- settings
var res_scale: float = 1.0       # live render scale (dynamic resolution)
var dyn_res: bool = true
var quality: int = 1            # 0 low, 1 medium, 2 high, 3 ultra
var start_hour: float = 17.0
var fps_limit_enabled: bool = false     # no frame-rate cap by default (the display's vsync is the only limit)
var tilt_steering: bool = false
var steer_sensitivity: float = 1.0
var touch_scale: float = 1.0        # on-screen pad size (0.6 .. 1.6)
var touch_opacity: float = 0.6
var left_handed: bool = false      # mirror the on-screen pads
var master_volume: float = 0.9
var music_volume: float = 0.55
var sfx_volume: float = 1.0
var haptics: bool = true
var show_fps: bool = false

# ---------------------------------------------------------------- progress
var credits: int = 0
var owned_cars: Array = ["rosso"]
var car_paint: Dictionary = {}      # car id -> index into PAINTS
var mission_stars: Dictionary = {}  # mission id -> 0..3
var mission_best: Dictionary = {}   # mission id -> best time / score
var mode := "free"                  # hand-off menu -> world: "free" or "mission"
var mission_id := ""
var weather_pref := 0               # 0 clear 1 cloudy 2 storm
var total_distance_km := 0.0
var selected_car: int = 0
var selected_track: int = 0
var best_laps: Dictionary = {}      # track id -> seconds
var best_races: Dictionary = {}     # track id -> seconds
var races_won: int = 0
var ai_difficulty: int = 1          # 0 easy, 1 normal, 2 hard

# per-race hand-off (menu -> race)
var race_laps: int = 3
var race_ai_count: int = 5


func _ready() -> void:
	_load_cars()
	_register_inputs()
	if not FileAccess.file_exists(SAVE_PATH):
		quality = auto_quality()
	load_game()
	res_scale = Q.base_scale()
	apply_audio()


## First-launch quality pick from GPU family and RAM so weak phones start smooth and strong phones start pretty (ULTRA stays opt-in).
func auto_quality() -> int:
	if not OS.has_feature("mobile"):
		return 2
	var q := 1
	var gpu := RenderingServer.get_video_adapter_name().to_lower()
	var n := _first_int(gpu)
	if gpu.contains("adreno"):
		q = 0 if (n > 0 and n < 610) else (1 if n < 640 else 2)
	elif gpu.contains("immortalis") or gpu.contains("xclipse"):
		q = 2
	elif gpu.contains("mali"):
		var gi := gpu.find("-g")
		var g := _first_int(gpu.substr(gi + 2)) if gi >= 0 else 0
		q = 0 if g < 52 else (1 if g < 76 and g != 710 else 2)       # G31/G51 low, G52/G57/G68 mid, G76+/G710+ high (old T-series = 0)
	elif gpu.contains("powervr") or gpu.contains("sgx") or gpu.contains("llvmpipe") or gpu.contains("swrast"):
		q = 0
	if OS.has_method("get_memory_info"):
		var mi: Dictionary = OS.get_memory_info()
		var mb := int(mi.get("physical", 0)) / 1048576
		if mb > 0 and mb < 3000:
			q = 0
		elif mb > 0 and mb < 4500:
			q = mini(q, 1)
	return q


func _first_int(s: String) -> int:
	var cur := ""
	for ch in s:
		if ch >= "0" and ch <= "9":
			cur += ch
		elif cur != "":
			break
	return int(cur) if cur != "" else 0


func _register_inputs() -> void:
	var map := {
		"steer_left": [KEY_A, KEY_LEFT],
		"steer_right": [KEY_D, KEY_RIGHT],
		"accelerate": [KEY_W, KEY_UP],
		"brake": [KEY_S, KEY_DOWN],
		"nitro": [KEY_SHIFT, KEY_N],
		"drift": [KEY_SPACE],
		"camera": [KEY_C],
		"pause": [KEY_ESCAPE, KEY_P],
		"reset_car": [KEY_R],
		"horn": [KEY_H],
	}
	for action in map:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for k in map[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)


# ---------------------------------------------------------------- helpers
func car() -> Dictionary:
	var c: Dictionary = cars[clampi(selected_car, 0, cars.size() - 1)].duplicate()
	c["color"] = car_color(clampi(selected_car, 0, cars.size() - 1))
	return c


func car_color(idx: int) -> Color:
	var id: String = cars[idx]["id"]
	if car_paint.has(id):
		return PAINTS[clampi(int(car_paint[id]), 0, PAINTS.size() - 1)]
	return cars[idx]["color"]


func set_car_paint(idx: int, pi: int) -> void:
	car_paint[cars[idx]["id"]] = pi


func ui(sound: String, vol_db: float = -6.0) -> void:
	var st := load("res://assets/audio/%s.wav" % sound) as AudioStream
	if st == null:
		return
	var pl := AudioStreamPlayer.new()
	pl.stream = st
	pl.volume_db = vol_db + linear_to_db(maxf(sfx_volume, 0.001))
	pl.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(pl)
	pl.play()
	pl.finished.connect(pl.queue_free)


func track() -> Dictionary:
	return TRACKS[clampi(selected_track, 0, TRACKS.size() - 1)]


func owns(idx: int) -> bool:
	return owned_cars.has(cars[idx]["id"])


func buy_car(idx: int) -> bool:
	if owns(idx):
		return true
	var price: int = cars[idx]["price"]
	if credits >= price:
		credits -= price
		owned_cars.append(cars[idx]["id"])
		save_game()
		return true
	return false


func record_lap(track_id: String, t: float) -> bool:
	var prev: float = best_laps.get(track_id, 1e9)
	if t < prev:
		best_laps[track_id] = t
		return true
	return false


func record_race(track_id: String, t: float) -> void:
	var prev: float = best_races.get(track_id, 1e9)
	if t < prev:
		best_races[track_id] = t


func format_time(t: float) -> String:
	if t >= 1e8 or t < 0.0:
		return "--:--.---"
	var m := int(t / 60.0)
	var s := int(t) % 60
	var ms := int(round((t - floor(t)) * 1000.0))
	if ms >= 1000:
		ms = 999
	return "%d:%02d.%03d" % [m, s, ms]


# ---------------------------------------------------------------- settings
func apply_audio() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(clampf(master_volume, 0.0001, 1.0)))


func apply_quality(vp: Viewport) -> void:
	Q.apply(vp)


func vibrate(ms: int) -> void:
	if haptics and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)


# ---------------------------------------------------------------- save/load
func save_game() -> void:
	var d := {
		"quality": quality, "tilt": tilt_steering, "sens": steer_sensitivity, "tscale": touch_scale, "topac": touch_opacity, "lefty": left_handed,
		"vol": master_volume, "music": music_volume, "sfx": sfx_volume,
		"haptics": haptics, "fps": show_fps, "fpscap2": fps_limit_enabled,
		"credits": credits, "owned": owned_cars, "car": selected_car, "car_id": String(cars[clampi(selected_car, 0, cars.size() - 1)]["id"]),
		"track": selected_track, "best_laps": best_laps, "best_races": best_races,
		"won": races_won, "diff": ai_difficulty, "paint": car_paint, "mstars": mission_stars, "mbest": mission_best, "weather": weather_pref, "start_hour": start_hour, "dist": total_distance_km, "dynres": dyn_res,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))
		f.close()


func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var d: Dictionary = parsed
	quality = int(d.get("quality", quality))
	tilt_steering = bool(d.get("tilt", tilt_steering))
	steer_sensitivity = float(d.get("sens", steer_sensitivity))
	touch_scale = clampf(float(d.get("tscale", touch_scale)), 0.5, 1.8)
	touch_opacity = clampf(float(d.get("topac", touch_opacity)), 0.2, 1.0)
	left_handed = bool(d.get("lefty", left_handed))
	master_volume = float(d.get("vol", master_volume))
	music_volume = float(d.get("music", music_volume))
	sfx_volume = float(d.get("sfx", sfx_volume))
	haptics = bool(d.get("haptics", haptics))
	show_fps = bool(d.get("fps", show_fps))
	fps_limit_enabled = bool(d.get("fpscap2", fps_limit_enabled))
	credits = int(d.get("credits", credits))
	owned_cars = d.get("owned", owned_cars)
	selected_car = clampi(int(d.get("car", selected_car)), 0, cars.size() - 1)
	if d.has("car_id"):       # the catalogue order can change with updates, so the id wins over the index
		for i in cars.size():
			if cars[i]["id"] == String(d["car_id"]):
				selected_car = i
	selected_track = clampi(int(d.get("track", selected_track)), 0, TRACKS.size() - 1)
	best_laps = d.get("best_laps", best_laps)
	best_races = d.get("best_races", best_races)
	races_won = int(d.get("won", races_won))
	ai_difficulty = int(d.get("diff", ai_difficulty))
	car_paint = d.get("paint", car_paint)
	mission_stars = d.get("mstars", mission_stars)
	mission_best = d.get("mbest", mission_best)
	weather_pref = int(d.get("weather", weather_pref))
	start_hour = float(d.get("start_hour", start_hour))
	total_distance_km = float(d.get("dist", total_distance_km))
	dyn_res = bool(d.get("dynres", dyn_res))
	if not owned_cars.has("rosso"):
		owned_cars.append("rosso")
