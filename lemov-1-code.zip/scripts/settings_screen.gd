class_name SettingsScreen
extends Control
## Settings with Graphics / Audio / Controls / Gameplay tabs. Used from the main menu and the pause menu.

signal closed

var _tabs: Dictionary = {}
var _body: VBoxContainer
var _tab_btns: Array = []
var _desc: Label


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var pn := Ui.panel(Color(0.04, 0.06, 0.1, 0.94), 22)
	pn.custom_minimum_size = Vector2(980, 640)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(cc)
	cc.add_child(pn)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	pn.add_child(root)
	root.add_child(Ui.label("SETTINGS", 40, Color.WHITE, true))
	var tb := HBoxContainer.new()
	tb.add_theme_constant_override("separation", 10)
	root.add_child(tb)
	var names := ["GRAPHICS", "AUDIO", "CONTROLS", "GAMEPLAY"]
	for i in names.size():
		var b := Ui.button(names[i], func(): _show(i), Ui.ACCENT, 20, Vector2(210, 48))
		b.alignment = HORIZONTAL_ALIGNMENT_CENTER
		tb.add_child(b)
		_tab_btns.append(b)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(920, 390)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	_body = VBoxContainer.new()
	_body.add_theme_constant_override("separation", 18)
	_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_body)
	_desc = Ui.label("", 18, Ui.DIM)
	_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_desc.custom_minimum_size = Vector2(900, 0)
	root.add_child(_desc)
	var back := Ui.button("BACK", _close, Ui.HOT, 26, Vector2(220, 60))
	back.alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(back)
	_show(0)
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.25)


func _close() -> void:
	G.save_game()
	G.apply_audio()
	closed.emit()
	queue_free()


func _clear() -> void:
	for c in _body.get_children():
		c.queue_free()


func _show(i: int) -> void:
	_clear()
	for j in _tab_btns.size():
		(_tab_btns[j] as Button).modulate = Color.WHITE if j == i else Color(0.7, 0.75, 0.85)
	match i:
		0:
			_graphics()
		1:
			_audio()
		2:
			_controls()
		3:
			_gameplay()


func _graphics() -> void:
	_body.add_child(Ui.choice_row("QUALITY", Q.NAMES, G.quality, func(v: int):
		G.quality = v
		G.res_scale = Q.base_scale()
		G.apply_quality(get_viewport())
		_update_desc()))
	_body.add_child(Ui.toggle_row("FPS LIMIT (SAVES BATTERY)", G.fps_limit_enabled, func(x: bool):
		G.fps_limit_enabled = x
		G.apply_quality(get_viewport())))
	_body.add_child(Ui.toggle_row("DYNAMIC RESOLUTION (AUTO SMOOTH)", G.dyn_res, func(x: bool):
		G.dyn_res = x
		G.res_scale = Q.base_scale()
		G.apply_quality(get_viewport())))
	_body.add_child(Ui.toggle_row("SHOW FPS", G.show_fps, func(x: bool): G.show_fps = x))
	_update_desc()


func _update_desc() -> void:
	var c := Q.cfg()
	_desc.text = "Shadows %d px / %d cascades up to %d m  •  buildings %d m  •  trees %d m  •  traffic %d  •  pedestrians %d  •  %s  •  MSAA %s. Shaders (facades, car paint, water, terrain, sky) scale with this level." % [
		c["shadow_size"], c["shadow_splits"], int(c["shadow_dist"]), int(c["bld_dist"]), int(c["tree_dist"]), c["traffic"], c["ped"],
		"bloom on" if c["glow"] else "bloom off", ["off", "2x", "4x", "8x"][int(c["msaa"])]]


func _audio() -> void:
	_body.add_child(Ui.slider_row("MASTER", 0.0, 1.0, G.master_volume, 0.01, func(v: float):
		G.master_volume = v
		G.apply_audio()))
	_body.add_child(Ui.slider_row("MUSIC", 0.0, 1.0, G.music_volume, 0.01, func(v: float): G.music_volume = v))
	_body.add_child(Ui.slider_row("EFFECTS", 0.0, 1.0, G.sfx_volume, 0.01, func(v: float): G.sfx_volume = v))
	_desc.text = "Engine, turbo, tyres, wind, road noise, rain, thunder and city ambience are all mixed live from the car's physics."


func _controls() -> void:
	_body.add_child(Ui.toggle_row("TILT STEERING", G.tilt_steering, func(x: bool): G.tilt_steering = x))
	_body.add_child(Ui.slider_row("STEER SENSITIVITY", 0.4, 2.0, G.steer_sensitivity, 0.05, func(v: float): G.steer_sensitivity = v, "%.2f", 1.0))
	_body.add_child(Ui.slider_row("BUTTON SIZE", 0.5, 1.8, G.touch_scale, 0.05, func(v: float): G.touch_scale = v))
	_body.add_child(Ui.slider_row("BUTTON OPACITY", 0.2, 1.0, G.touch_opacity, 0.05, func(v: float): G.touch_opacity = v))
	_body.add_child(Ui.toggle_row("LEFT-HANDED LAYOUT", G.left_handed, func(x: bool): G.left_handed = x))
	_body.add_child(Ui.toggle_row("VIBRATION", G.haptics, func(x: bool): G.haptics = x))
	_desc.text = "Keyboard: W/S throttle & brake, A/D steer, SPACE handbrake, SHIFT nitro, C camera (wheel / pinch zooms), R reset, H horn, ESC pause."


func _gameplay() -> void:
	_body.add_child(Ui.choice_row("AI DIFFICULTY", ["EASY", "NORMAL", "HARD"], G.ai_difficulty, func(v: int): G.ai_difficulty = v))
	_body.add_child(Ui.slider_row("START TIME OF DAY", 0.0, 24.0, G.start_hour, 0.5, func(v: float): G.start_hour = v, "%.1f h", 1.0))
	_body.add_child(Ui.choice_row("WEATHER", ["CLEAR", "CLOUDY", "STORM"], G.weather_pref, func(v: int): G.weather_pref = v))
	_desc.text = "The day lasts 48 real minutes, like GTA V. Weather changes grip: wet roads give less traction."
