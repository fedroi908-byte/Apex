class_name RoadBuilder
extends Node3D
## Streams road, sidewalk, junction and bridge meshes in 600 m cells around the camera.

const CELL := 600.0
const STYLE := {"dirt": 0, "street": 1, "avenue": 2, "main": 3, "highway": 3, "runway": 4, "track": 5, "pass": 6}
const LIFT := {"dirt": 0.0, "street": 0.0, "avenue": 0.04, "main": 0.05, "highway": 0.07, "runway": 0.0, "track": 0.0, "pass": 0.05}

var road_mat: ShaderMaterial
var side_mat: StandardMaterial3D
var bridge_mat: StandardMaterial3D
var cum_s: Array = []                  # per road: cumulative metres
var cell_runs := {}                    # cell id -> Array of [road, a, b]
var cell_junctions := {}               # cell id -> Array of [x, z, ang, signal]
var built := {}                        # cell id -> Node3D
var radius_cells := 4
var queue: Array = []
var per_frame := 2


func _cell_id(cx: int, cz: int) -> int:
	return cx * 1000 + cz


func _cell_of(x: float, z: float) -> Vector2i:
	return Vector2i(int(floor((x + W.half) / CELL)), int(floor((z + W.half) / CELL)))


func _ready() -> void:
	road_mat = ShaderMaterial.new()
	road_mat.shader = load("res://shaders/road.gdshader")
	var T := "res://assets/textures/"
	road_mat.set_shader_parameter("asph_a", load(T + "asphalt_albedo.png"))
	road_mat.set_shader_parameter("asph_n", load(T + "asphalt_normal.png"))
	road_mat.set_shader_parameter("asph_r", load(T + "asphalt_rough.png"))
	road_mat.set_shader_parameter("sand_a", load(T + "sand_albedo.png"))
	side_mat = StandardMaterial3D.new()
	side_mat.albedo_texture = load(T + "concrete_albedo.png")
	side_mat.normal_enabled = true
	side_mat.normal_texture = load(T + "concrete_normal.png")
	side_mat.uv1_triplanar = true
	side_mat.uv1_world_triplanar = true
	side_mat.uv1_scale = Vector3(0.22, 0.22, 0.22)
	side_mat.roughness = 0.92
	side_mat.albedo_color = Color(0.82, 0.82, 0.80)
	bridge_mat = side_mat.duplicate()
	bridge_mat.albedo_color = Color(0.7, 0.7, 0.72)
	_prepare()


func _prepare() -> void:
	cum_s.clear()
	cell_runs.clear()
	for ri in W.roads.size():
		var r: Dictionary = W.roads[ri]
		var pts: PackedVector3Array = r["pts"]
		var s := PackedFloat32Array()
		s.resize(pts.size())
		var acc := 0.0
		for i in pts.size():
			if i > 0:
				acc += Vector2(pts[i].x - pts[i - 1].x, pts[i].z - pts[i - 1].z).length()
			s[i] = acc
		cum_s.append(s)
		var run_a := 0
		var cur := Vector2i(-99, -99)
		for i in range(pts.size() - 1):
			var mx := (pts[i].x + pts[i + 1].x) * 0.5
			var mz := (pts[i].z + pts[i + 1].z) * 0.5
			var c := _cell_of(mx, mz)
			if c != cur:
				if cur.x != -99:
					_add_run(cur, ri, run_a, i - 1)
				cur = c
				run_a = i
		if cur.x != -99:
			_add_run(cur, ri, run_a, pts.size() - 2)
	var inter := W.intersections
	for k in range(0, inter.size(), 4):
		var c := _cell_of(inter[k], inter[k + 1])
		var id := _cell_id(c.x, c.y)
		if not cell_junctions.has(id):
			cell_junctions[id] = []
		cell_junctions[id].append([inter[k], inter[k + 1], inter[k + 2], inter[k + 3]])


func _add_run(c: Vector2i, ri: int, a: int, b: int) -> void:
	var id := _cell_id(c.x, c.y)
	if not cell_runs.has(id):
		cell_runs[id] = []
	cell_runs[id].append([ri, a, b])


func update_focus(p: Vector3) -> void:
	var c := _cell_of(p.x, p.z)
	var rc := radius_cells
	var want := {}
	for dx in range(-rc, rc + 1):
		for dz in range(-rc, rc + 1):
			var cc := Vector2i(c.x + dx, c.y + dz)
			if cc.x < 0 or cc.y < 0:
				continue
			var id := _cell_id(cc.x, cc.y)
			want[id] = true
			if not built.has(id) and (cell_runs.has(id) or cell_junctions.has(id)) and not queue.has(id):
				queue.append(id)
	# unload far cells
	for id in built.keys():
		if not want.has(id):
			built[id].queue_free()
			built.erase(id)
	queue.sort_custom(func(a, b): return _dist_cell(a, p) < _dist_cell(b, p))
	var n := 0
	while queue.size() > 0 and n < per_frame:
		var id: int = queue.pop_front()
		if want.has(id):
			_build_cell(id)
			n += 1


func build_all_near(p: Vector3, rc: int) -> void:
	var c := _cell_of(p.x, p.z)
	for dx in range(-rc, rc + 1):
		for dz in range(-rc, rc + 1):
			var id := _cell_id(c.x + dx, c.y + dz)
			if not built.has(id) and (cell_runs.has(id) or cell_junctions.has(id)):
				_build_cell(id)


func _dist_cell(id: int, p: Vector3) -> float:
	var cx := id / 1000
	var cz := id % 1000
	return Vector2((cx + 0.5) * CELL - W.half - p.x, (cz + 0.5) * CELL - W.half - p.z).length()


# ---------------------------------------------------------------- mesh building
func _build_cell(id: int) -> void:
	var node := Node3D.new()
	node.name = "road_%d" % id
	var road := MeshUtil.new()
	road.with_tangents = true
	road.with_uv2 = true
	var side := MeshUtil.new()
	var bridge := MeshUtil.new()
	if cell_runs.has(id):
		for run in cell_runs[id]:
			_build_run(road, side, bridge, run[0], run[1], run[2])
	if cell_junctions.has(id):
		_build_junctions(road, id)
	if road.vertex_count() > 0:
		var mi := MeshInstance3D.new()
		mi.mesh = road.build(road_mat)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.visibility_range_end = 3200.0
		node.add_child(mi)
	if side.vertex_count() > 0:
		var ms := MeshInstance3D.new()
		ms.mesh = side.build(side_mat)
		ms.visibility_range_end = 900.0
		node.add_child(ms)
	if bridge.vertex_count() > 0:
		var mb := MeshInstance3D.new()
		mb.mesh = bridge.build(bridge_mat)
		mb.visibility_range_end = 1800.0
		node.add_child(mb)
		_bridge_colliders(node, bridge)
	add_child(node)
	built[id] = node


func _tangent_at(pts: PackedVector3Array, i: int) -> Vector3:
	var a := pts[maxi(i - 1, 0)]
	var b := pts[mini(i + 1, pts.size() - 1)]
	var t := Vector3(b.x - a.x, 0, b.z - a.z)
	if t.length() < 0.001:
		return Vector3.FORWARD
	return t.normalized()


func _build_run(road: MeshUtil, side: MeshUtil, bridge: MeshUtil, ri: int, a: int, b: int) -> void:
	var r: Dictionary = W.roads[ri]
	var pts: PackedVector3Array = r["pts"]
	var br: PackedByteArray = r["bridge"]
	var cls: String = r["cls"]
	var name: String = r["name"]
	var style: int = STYLE.get(cls, 1)
	if name.begins_with("Taxi"):
		style = 7
	if (cls == "main" or cls == "highway") and float(r["width"]) < 12.0 and not name.begins_with("Taxi"):
		style = 3
	var hw := float(r["width"]) * 0.5
	var lift: float = LIFT.get(cls, 0.0)
	var s_arr: PackedFloat32Array = cum_s[ri]
	var total: float = s_arr[s_arr.size() - 1]
	var rnd := fposmod(float(ri) * 0.6180339, 1.0)
	var vcol := Color(style / 10.0, float(r["width"]) / 64.0, rnd, 1.0)
	var is_city := cls == "street" or cls == "avenue"
	var first := -1
	var prev_l := -1
	var prev_r := -1
	var sl0 := -1
	var sr0 := -1
	for i in range(a, b + 2):
		var p := pts[i]
		var t := _tangent_at(pts, i)
		var nrm := Vector3(-t.z, 0, t.x)
		var y := p.y + lift
		var l := Vector3(p.x, y, p.z) - nrm * hw
		var rr := Vector3(p.x, y, p.z) + nrm * hw
		var s := s_arr[i]
		var vl := road.add_vertex(l, Vector3.UP, Vector2(0.0, s), vcol, Vector2(s, total - s))
		var vr := road.add_vertex(rr, Vector3.UP, Vector2(1.0, s), vcol, Vector2(s, total - s))
		if prev_l >= 0:
			road.quad_auto(prev_l, prev_r, vr, vl, Vector3.UP)
		prev_l = vl
		prev_r = vr
		if is_city and br[i] == 0:
			# sidewalks (curb strips) on both sides
			var sw := 1.7
			var h := 0.16
			var lo := l - nrm * sw
			var ro := rr + nrm * sw
			var pl := side.add_vertex(Vector3(l.x, y + h, l.z), Vector3.UP, Vector2(0, s), Color.WHITE)
			var pl2 := side.add_vertex(Vector3(lo.x, y + h, lo.z), Vector3.UP, Vector2(1, s), Color.WHITE)
			var pr := side.add_vertex(Vector3(rr.x, y + h, rr.z), Vector3.UP, Vector2(0, s), Color.WHITE)
			var pr2 := side.add_vertex(Vector3(ro.x, y + h, ro.z), Vector3.UP, Vector2(1, s), Color.WHITE)
			var cl_t := side.add_vertex(Vector3(l.x, y + h, l.z), nrm, Vector2(0, s), Color.WHITE)
			var cl_b := side.add_vertex(Vector3(l.x, y, l.z), nrm, Vector2(1, s), Color.WHITE)
			var cr_t := side.add_vertex(Vector3(rr.x, y + h, rr.z), -nrm, Vector2(0, s), Color.WHITE)
			var cr_b := side.add_vertex(Vector3(rr.x, y, rr.z), -nrm, Vector2(1, s), Color.WHITE)
			if sl0 >= 0:
				side.quad_auto(sl0, sl0 + 1, pl2, pl, Vector3.UP)
				side.quad_auto(sr0, sr0 + 1, pr2, pr, Vector3.UP)
				side.quad_auto(sl0 + 4, sl0 + 5, cl_b, cl_t, nrm)
				side.quad_auto(sr0 + 4, sr0 + 5, cr_b, cr_t, -nrm)
			sl0 = pl
			sr0 = pr
		else:
			sl0 = -1
			sr0 = -1
	# bridges
	var in_bridge := false
	var last_pillar := -9999.0
	for i in range(a, b + 1):
		if br[i] == 0:
			continue
		var p := pts[i]
		var q := pts[i + 1]
		var t := _tangent_at(pts, i)
		var nrm := Vector3(-t.z, 0, t.x)
		var y0 := p.y + lift
		var y1 := q.y + lift
		var tq := _tangent_at(pts, i + 1)
		var nq := Vector3(-tq.z, 0, tq.x)
		# deck sides and underside
		for sgn_v in [-1.0, 1.0]:
			var sgn: float = sgn_v
			var e0 := Vector3(p.x, y0, p.z) + nrm * hw * sgn
			var e1 := Vector3(q.x, y1, q.z) + nq * hw * sgn
			var on: Vector3 = nrm * sgn
			var v0 := bridge.add_vertex(e0, on, Vector2(0, 0), Color.WHITE)
			var v1 := bridge.add_vertex(e1, on, Vector2(1, 0), Color.WHITE)
			var v2 := bridge.add_vertex(e0 - Vector3(0, 1.5, 0), on, Vector2(0, 1), Color.WHITE)
			var v3 := bridge.add_vertex(e1 - Vector3(0, 1.5, 0), on, Vector2(1, 1), Color.WHITE)
			bridge.quad_auto(v0, v1, v3, v2, on)
			# parapet (top face + inner face)
			var h := 1.0
			var inner := -on
			var w0 := e0 + Vector3(0, h, 0)
			var w1 := e1 + Vector3(0, h, 0)
			var k0 := bridge.add_vertex(w0, Vector3.UP, Vector2(0, 0), Color.WHITE)
			var k1 := bridge.add_vertex(w1, Vector3.UP, Vector2(1, 0), Color.WHITE)
			var k2 := bridge.add_vertex(w0 + inner * 0.35, Vector3.UP, Vector2(0, 1), Color.WHITE)
			var k3 := bridge.add_vertex(w1 + inner * 0.35, Vector3.UP, Vector2(1, 1), Color.WHITE)
			bridge.quad_auto(k0, k1, k3, k2, Vector3.UP)
			var f0 := bridge.add_vertex(w0 + inner * 0.35, inner, Vector2(0, 0), Color.WHITE)
			var f1 := bridge.add_vertex(w1 + inner * 0.35, inner, Vector2(1, 0), Color.WHITE)
			var f2 := bridge.add_vertex(e0 + inner * 0.35, inner, Vector2(0, 1), Color.WHITE)
			var f3 := bridge.add_vertex(e1 + inner * 0.35, inner, Vector2(1, 1), Color.WHITE)
			bridge.quad_auto(f0, f1, f3, f2, inner)
		# underside
		var u0 := Vector3(p.x, y0 - 1.5, p.z) - nrm * hw
		var u1 := Vector3(p.x, y0 - 1.5, p.z) + nrm * hw
		var u2 := Vector3(q.x, y1 - 1.5, q.z) - nq * hw
		var u3 := Vector3(q.x, y1 - 1.5, q.z) + nq * hw
		var b0 := bridge.add_vertex(u0, Vector3.DOWN, Vector2(0, 0), Color.WHITE)
		var b1 := bridge.add_vertex(u1, Vector3.DOWN, Vector2(1, 0), Color.WHITE)
		var b2 := bridge.add_vertex(u2, Vector3.DOWN, Vector2(0, 1), Color.WHITE)
		var b3 := bridge.add_vertex(u3, Vector3.DOWN, Vector2(1, 1), Color.WHITE)
		bridge.quad_auto(b0, b1, b3, b2, Vector3.DOWN)
		# pillars every ~28 m
		if s_arr[i] - last_pillar > 28.0:
			last_pillar = s_arr[i]
			var ground := W.terrain_height(p.x, p.z) - 3.0
			var top := y0 - 1.5
			if top - ground > 1.0:
				var ang := atan2(t.x, t.z)
				bridge.box(Vector3(p.x, (top + ground) * 0.5, p.z), Vector3(hw * 1.1, top - ground, 1.8), ang + PI * 0.5, Color.WHITE, 0.3, false, false)


func _bridge_colliders(node: Node3D, bridge: MeshUtil) -> void:
	# bridge decks are driven on through W.ground_height(); only the parapets need collision.
	pass


func _build_junctions(road: MeshUtil, id: int) -> void:
	var runs: Array = cell_runs.get(id, [])
	for j in cell_junctions[id]:
		var x: float = j[0]
		var z: float = j[1]
		var ang: float = j[2]
		var big: bool = j[3] > 0.5
		# find nearest road sample height in this cell
		var best_y := W.terrain_height(x, z) + 0.2
		var bd := 1e9
		for run in runs:
			var pts: PackedVector3Array = W.roads[run[0]]["pts"]
			for i in range(run[1], run[2] + 2, 2):
				var d := (pts[i].x - x) * (pts[i].x - x) + (pts[i].z - z) * (pts[i].z - z)
				if d < bd:
					bd = d
					best_y = pts[i].y
		if bd > 400.0:
			continue
		var half := (8.5 if big else 5.5) + 3.0
		var y := best_y + 0.08
		var cs := cos(ang)
		var sn := sin(ang)
		var vcol := Color(0.8, half * 2.0 / 64.0, 0.5, 1.0)
		var vs := []
		for k in 4:
			var ux := -1.0 if (k == 0 or k == 2) else 1.0
			var uz := -1.0 if (k == 0 or k == 1) else 1.0
			var lx := ux * half
			var lz := uz * half
			var wx := x + lx * cs - lz * sn
			var wz := z + lx * sn + lz * cs
			vs.append(road.add_vertex(Vector3(wx, y, wz), Vector3.UP, Vector2((ux + 1.0) * 0.5, (uz + 1.0) * 0.5), vcol, Vector2(0, 0)))
		road.quad_auto(vs[0], vs[1], vs[3], vs[2], Vector3.UP)
