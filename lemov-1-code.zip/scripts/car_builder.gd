class_name CarBuilder
extends RefCounted
## Procedural cars. The hull is a dense, smoothly shaded loft with real wheel arches; the greenhouse is
## see-through glass over a modelled interior; wheels have lathe tyres, spoked rims, brake discs and calipers;
## lights, grille, vents, mirrors, wings and exhausts are modelled per body type.

# z runs rear(-) -> front(+) as fractions of half length.
# section: [z, y_bottom, y_belt, y_roof, half_w_bottom, half_w_roof]
const BODIES := {
	"sedan": {"len": 4.75, "wid": 1.86, "wb": 2.85, "wr": 0.345, "kind": "sedan",
		"sec": [[-1.0, 0.34, 0.80, 0.84, 0.86, 0.78], [-0.86, 0.30, 0.95, 0.98, 0.95, 0.84], [-0.62, 0.28, 0.98, 1.36, 1.0, 0.80],
				[-0.12, 0.28, 1.00, 1.45, 1.0, 0.78], [0.28, 0.28, 0.98, 1.38, 1.0, 0.82], [0.46, 0.28, 0.94, 1.00, 1.0, 0.9], [0.86, 0.30, 0.80, 0.82, 0.96, 0.9], [1.0, 0.34, 0.64, 0.66, 0.86, 0.82]]},
	"coupe": {"len": 4.5, "wid": 1.9, "wb": 2.68, "wr": 0.35, "kind": "coupe",
		"sec": [[-1.0, 0.30, 0.78, 0.80, 0.88, 0.8], [-0.86, 0.26, 0.93, 0.98, 0.97, 0.86], [-0.5, 0.24, 0.96, 1.28, 1.0, 0.76],
				[-0.05, 0.24, 0.97, 1.34, 1.0, 0.74], [0.30, 0.24, 0.95, 1.12, 1.0, 0.8], [0.45, 0.24, 0.9, 0.93, 1.0, 0.92], [0.88, 0.24, 0.72, 0.74, 0.95, 0.9], [1.0, 0.30, 0.56, 0.58, 0.86, 0.82]]},
	"hyper": {"len": 4.6, "wid": 2.0, "wb": 2.72, "wr": 0.36, "kind": "hyper",
		"sec": [[-1.0, 0.24, 0.74, 0.78, 0.92, 0.86], [-0.84, 0.20, 0.86, 0.98, 1.0, 0.92], [-0.45, 0.18, 0.88, 1.10, 1.0, 0.72],
				[0.05, 0.18, 0.86, 1.14, 1.0, 0.68], [0.34, 0.18, 0.80, 0.90, 1.0, 0.8], [0.52, 0.18, 0.76, 0.80, 1.0, 0.92], [0.90, 0.18, 0.56, 0.58, 0.96, 0.9], [1.0, 0.22, 0.42, 0.44, 0.86, 0.82]]},
	"hatch": {"len": 3.95, "wid": 1.74, "wb": 2.5, "wr": 0.31, "kind": "hatch",
		"sec": [[-1.0, 0.32, 0.84, 1.28, 0.86, 0.78], [-0.82, 0.28, 0.98, 1.46, 0.98, 0.8], [0.02, 0.28, 1.00, 1.50, 1.0, 0.8],
				[0.38, 0.28, 0.98, 1.10, 1.0, 0.9], [0.62, 0.28, 0.92, 0.96, 1.0, 0.92], [0.9, 0.30, 0.78, 0.80, 0.94, 0.9], [1.0, 0.34, 0.64, 0.66, 0.84, 0.8]]},
	"suv": {"len": 4.85, "wid": 1.96, "wb": 2.9, "wr": 0.40, "kind": "suv",
		"sec": [[-1.0, 0.46, 1.00, 1.48, 0.9, 0.84], [-0.9, 0.42, 1.10, 1.80, 1.0, 0.88], [0.08, 0.42, 1.12, 1.82, 1.0, 0.88],
				[0.18, 0.42, 1.12, 1.78, 1.0, 0.88], [0.44, 0.42, 1.08, 1.10, 1.0, 0.94], [0.66, 0.42, 1.04, 1.06, 1.0, 0.96], [0.92, 0.44, 0.96, 0.98, 0.96, 0.92], [1.0, 0.48, 0.84, 0.86, 0.9, 0.86]]},
	"pickup": {"len": 5.4, "wid": 1.96, "wb": 3.3, "wr": 0.42, "kind": "pickup",
		"sec": [[-1.0, 0.46, 1.06, 1.08, 0.96, 0.96], [-0.30, 0.46, 1.07, 1.09, 1.0, 1.0], [-0.27, 0.46, 1.10, 1.80, 1.0, 0.88],
				[0.22, 0.46, 1.12, 1.82, 1.0, 0.88], [0.44, 0.46, 1.10, 1.30, 1.0, 0.94], [0.6, 0.46, 1.08, 1.12, 1.0, 0.96], [0.92, 0.46, 0.98, 1.0, 0.96, 0.94], [1.0, 0.48, 0.86, 0.88, 0.9, 0.88]]},
	"van": {"len": 5.2, "wid": 2.0, "wb": 3.4, "wr": 0.37, "kind": "van",
		"sec": [[-1.0, 0.42, 1.10, 2.25, 0.96, 0.92], [0.40, 0.42, 1.10, 2.28, 1.0, 0.94], [0.72, 0.42, 1.08, 1.62, 1.0, 0.94],
				[0.95, 0.42, 0.92, 0.94, 0.95, 0.93], [1.0, 0.44, 0.80, 0.82, 0.9, 0.88]]},
	"bus": {"len": 11.5, "wid": 2.55, "wb": 6.0, "wr": 0.52, "kind": "bus",
		"sec": [[-1.0, 0.50, 1.05, 3.1, 1.0, 0.96], [0.94, 0.50, 1.05, 3.1, 1.0, 0.96], [1.0, 0.50, 0.9, 2.9, 0.98, 0.94]]},
}

const K_WHEELS := ["wheel_frontLeft*", "wheel_frontRight*", "wheel_backLeft*", "wheel_backRight*"]
## id -> real glTF vehicle. "phys" selects the handling tables in Vehicle, "len" rescales stylised models to real size,
## "flip" turns a -Z-facing model to face +Z (the game's forward axis).
const MODELS := {
	"concept": {"name": "Aurora Concept", "path": "res://assets/cars/concept.glb", "phys": "hyper", "flip": false, "len": 0.0,
		"wheels": ["WheelFrontL", "WheelFrontR", "WheelRearL", "WheelRearR"], "paint": ["Paint 1", "Paint 2"], "glass": ["Glass"], "panel_lines": 0.0, "steer": "InteriorSteeringWheel*"},
	"ferrari": {"name": "Rosso 458", "path": "res://assets/cars/ferrari.glb", "phys": "hyper", "flip": true, "len": 0.0,
		"wheels": ["wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"], "paint": ["Body_Color"], "glass": ["Glass_Gray", "Projector_Glass", "Taillight_Glass"], "panel_lines": 0.0, "steer": "steering"},
	"porsche911": {"name": "Carrera 911 Turbo S", "path": "res://assets/cars/porsche911.glb", "phys": "hyper", "yaw": -90.0, "len": 0.0,
		"wheel_mats": ["tires", "rim_black", "rim_chrome", "Discs", "brakes"], "paint": ["body_main"], "glass": ["windows"],
		"tail_mats": ["red_light_main"], "head_mats": ["lights", "headlights_plastic"], "eye": Vector3(0.36, 1.02, -0.12), "panel_lines": 0.0},
	"sports": {"name": "Sport Sedan", "path": "res://assets/cars/k_sports.glb", "phys": "coupe", "flip": true, "len": 4.7, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"racer": {"name": "Circuit Racer", "path": "res://assets/cars/k_racer.glb", "phys": "hyper", "flip": true, "len": 4.5, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"future": {"name": "Future GT", "path": "res://assets/cars/k_future.glb", "phys": "hyper", "flip": true, "len": 4.6, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"suvlux": {"name": "Luxury SUV", "path": "res://assets/cars/k_suvlux.glb", "phys": "suv", "flip": true, "len": 4.9, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"sedan": {"name": "City Sedan", "path": "res://assets/cars/k_sedan.glb", "phys": "sedan", "flip": true, "len": 4.6, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"taxi": {"name": "Taxi", "path": "res://assets/cars/k_taxi.glb", "phys": "sedan", "flip": true, "len": 4.6, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"police": {"name": "Police", "path": "res://assets/cars/k_police.glb", "phys": "sedan", "flip": true, "len": 4.8, "wheels": K_WHEELS, "paint": ["paintWhite"], "glass": ["window"]},
	"suv": {"name": "Explorer SUV", "path": "res://assets/cars/k_suv.glb", "phys": "suv", "flip": true, "len": 4.8, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"van": {"name": "Cargo Van", "path": "res://assets/cars/k_van.glb", "phys": "van", "flip": true, "len": 5.2, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"ambulance": {"name": "Ambulance", "path": "res://assets/cars/k_ambulance.glb", "phys": "van", "flip": true, "len": 5.6, "wheels": K_WHEELS, "paint": ["paintWhite"], "glass": ["window"]},
	"truck": {"name": "Pickup Truck", "path": "res://assets/cars/k_truck.glb", "phys": "pickup", "flip": true, "len": 5.4, "wheels": K_WHEELS, "paint": ["paint"], "glass": ["window"]},
	"flatbed": {"name": "Flatbed", "path": "res://assets/cars/k_flatbed.glb", "phys": "pickup", "flip": true, "len": 5.6, "wheels": K_WHEELS, "paint": ["paintWhite"], "glass": ["window"]},
	"firetruck": {"name": "Fire Truck", "path": "res://assets/cars/k_firetruck.glb", "phys": "van", "flip": true, "len": 7.5, "wheels": K_WHEELS, "paint": ["paintRed"], "glass": ["window"]},
	"delivery": {"name": "Delivery Truck", "path": "res://assets/cars/k_delivery.glb", "phys": "van", "flip": true, "len": 7.0, "wheels": K_WHEELS, "paint": ["paintWhite"], "glass": ["window"]},
	"garbage": {"name": "Garbage Truck", "path": "res://assets/cars/k_garbage.glb", "phys": "van", "flip": true, "len": 7.5, "wheels": K_WHEELS, "paint": ["paintGreen"], "glass": ["window"]},
}
## Order shown in the garage / used for random traffic.
const CATALOG := ["concept", "ferrari", "porsche911"]   # realistic models only; drop more glTF cars into assets/cars and add them to MODELS + this list
## Stylised (cartoon) kit models kept only as optional background traffic, never offered to the player.
const TRAFFIC_ONLY := ["sedan", "suv", "truck", "van", "taxi", "police", "ambulance", "flatbed", "delivery", "firetruck", "garbage", "sports", "racer", "future", "suvlux"]
static var _m := {}
const RING := 13


static func _mats() -> void:
	if not _m.is_empty():
		return
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.05, 0.07, 0.09, 0.42)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.metallic = 0.0
	glass.roughness = 0.02
	glass.metallic_specular = 1.0
	glass.cull_mode = BaseMaterial3D.CULL_DISABLED
	_m["glass"] = glass
	var tyre := StandardMaterial3D.new()
	tyre.albedo_color = Color(0.035, 0.035, 0.04)
	tyre.roughness = 0.88
	_m["tyre"] = tyre
	var rim := StandardMaterial3D.new()
	rim.albedo_color = Color(0.78, 0.8, 0.84)
	rim.metallic = 1.0
	rim.roughness = 0.2
	_m["rim"] = rim
	var darkmetal := StandardMaterial3D.new()
	darkmetal.albedo_color = Color(0.1, 0.1, 0.11)
	darkmetal.metallic = 0.9
	darkmetal.roughness = 0.45
	_m["dark"] = darkmetal
	var caliper := StandardMaterial3D.new()
	caliper.albedo_color = Color(0.85, 0.05, 0.04)
	caliper.roughness = 0.4
	caliper.metallic = 0.3
	_m["caliper"] = caliper
	var trim := StandardMaterial3D.new()
	trim.albedo_color = Color(0.02, 0.02, 0.025)
	trim.roughness = 0.35
	trim.metallic = 0.2
	_m["trim"] = trim
	var tub := StandardMaterial3D.new()
	tub.albedo_color = Color(0.015, 0.015, 0.017)
	tub.roughness = 1.0
	tub.cull_mode = BaseMaterial3D.CULL_DISABLED
	_m["tub"] = tub
	var lamp := StandardMaterial3D.new()
	lamp.albedo_color = Color(1, 1, 0.96)
	lamp.emission_enabled = true
	lamp.emission = Color(1.0, 0.96, 0.85)
	lamp.emission_energy_multiplier = 0.8
	_m["head"] = lamp
	var drl := StandardMaterial3D.new()
	drl.albedo_color = Color(0.9, 0.95, 1.0)
	drl.emission_enabled = true
	drl.emission = Color(0.8, 0.9, 1.0)
	drl.emission_energy_multiplier = 2.2
	_m["drl"] = drl
	var tail := StandardMaterial3D.new()
	tail.albedo_color = Color(0.5, 0.0, 0.0)
	tail.emission_enabled = true
	tail.emission = Color(1.0, 0.04, 0.02)
	tail.emission_energy_multiplier = 0.8
	_m["tail"] = tail
	var chrome := StandardMaterial3D.new()
	chrome.albedo_color = Color(0.85, 0.86, 0.9)
	chrome.metallic = 1.0
	chrome.roughness = 0.08
	_m["chrome"] = chrome
	var seat := StandardMaterial3D.new()
	seat.albedo_color = Color(0.09, 0.09, 0.1)
	seat.roughness = 0.9
	_m["seat"] = seat
	var plate := StandardMaterial3D.new()
	plate.albedo_color = Color(0.92, 0.92, 0.88)
	plate.roughness = 0.5
	_m["plate"] = plate
	var amber := StandardMaterial3D.new()
	amber.albedo_color = Color(0.8, 0.4, 0.0)
	amber.emission_enabled = true
	amber.emission = Color(1.0, 0.5, 0.0)
	amber.emission_energy_multiplier = 0.3
	_m["amber"] = amber
	var carbon := StandardMaterial3D.new()
	carbon.albedo_color = Color(0.04, 0.04, 0.045)
	carbon.metallic = 0.5
	carbon.roughness = 0.3
	_m["carbon"] = carbon


static func paint_shader(color: Color, accent: Color, spec: Dictionary, stripe: float, pearl: float) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/car_paint.gdshader")
	m.set_shader_parameter("base_color", color)
	m.set_shader_parameter("accent_color", accent)
	m.set_shader_parameter("stripe", stripe)
	m.set_shader_parameter("pearl", pearl)
	m.set_shader_parameter("body_len", float(spec["len"]))
	m.set_shader_parameter("body_wid", float(spec["wid"]))
	m.set_shader_parameter("wheelbase", float(spec["wb"]))
	m.set_shader_parameter("belt_y", float((spec["sec"] as Array)[2][2]))
	return m


# ------------------------------------------------------------------ small geometry helpers
static func _box_t(m: MeshUtil, t: Transform3D, size: Vector3) -> void:
	var h := size * 0.5
	var c := []
	for iy in [-1.0, 1.0]:
		for iz in [-1.0, 1.0]:
			for ix in [-1.0, 1.0]:
				c.append(t * Vector3(ix * h.x, iy * h.y, iz * h.z))
	# corners index = iy*4 + iz*2 + ix  (0/1 after mapping -1->0)
	var faces := [
		[0, 1, 3, 2, Vector3(0, -1, 0)], [4, 6, 7, 5, Vector3(0, 1, 0)],
		[0, 2, 6, 4, Vector3(-1, 0, 0)], [1, 5, 7, 3, Vector3(1, 0, 0)],
		[0, 4, 5, 1, Vector3(0, 0, -1)], [2, 3, 7, 6, Vector3(0, 0, 1)]]
	for f in faces:
		var nrm: Vector3 = (t.basis * (f[4] as Vector3)).normalized()
		var ids := []
		for k in 4:
			ids.append(m.add_vertex(c[f[k]], nrm, Vector2(0, 0), Color.WHITE))
		m.quad_auto(ids[0], ids[1], ids[2], ids[3], nrm)


static func _lathe(m: MeshUtil, prof: Array, seg: int, xf: Transform3D = Transform3D.IDENTITY, smooth: bool = true) -> void:
	# profile of Vector2(radius, y); outward is (dy, -dr)
	var n := prof.size()
	var nrm2 := []
	for i in n:
		var a: Vector2 = prof[maxi(i - 1, 0)]
		var b: Vector2 = prof[mini(i + 1, n - 1)]
		var tng := (b - a)
		if tng.length() < 0.00001:
			tng = Vector2(0, 1)
		nrm2.append(Vector2(tng.y, -tng.x).normalized())
	var rows := []
	for s in seg + 1:
		var ang := TAU * float(s) / float(seg)
		var ca := cos(ang)
		var sa := sin(ang)
		var row := []
		for i in n:
			var p: Vector2 = prof[i]
			var n2: Vector2 = nrm2[i]
			var pos := xf * Vector3(ca * p.x, p.y, sa * p.x)
			var nn := (xf.basis * Vector3(ca * n2.x, n2.y, sa * n2.x)).normalized()
			row.append(m.add_vertex(pos, nn, Vector2(float(s) / seg, float(i) / maxf(n - 1.0, 1.0)), Color.WHITE))
		rows.append(row)
	for s in seg:
		for i in n - 1:
			var a: int = rows[s][i]
			var b: int = rows[s + 1][i]
			var c: int = rows[s + 1][i + 1]
			var d: int = rows[s][i + 1]
			var hint := (m.n[a] + m.n[b] + m.n[c] + m.n[d]).normalized()
			m.quad_auto(a, b, c, d, hint)


## Smooth spline lookup of section parameters at normalised z in [-1,1].
static func _param(sec: Array, z: float) -> Array:
	var k := sec.size()
	var i := 0
	while i < k - 2 and z > float((sec[i + 1] as Array)[0]):
		i += 1
	var z0: float = (sec[i] as Array)[0]
	var z1: float = (sec[i + 1] as Array)[0]
	var t := clampf((z - z0) / maxf(z1 - z0, 0.0001), 0.0, 1.0)
	var out := []
	for q in range(1, 6):
		var p0: float = (sec[maxi(i - 1, 0)] as Array)[q]
		var p1: float = (sec[i] as Array)[q]
		var p2: float = (sec[i + 1] as Array)[q]
		var p3: float = (sec[mini(i + 2, k - 1)] as Array)[q]
		var v := 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t * t + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t * t * t)
		# sections with a step (pickup bed) keep it sharp
		if absf(z1 - z0) < 0.06:
			v = lerpf(p1, p2, t)
		out.append(v)
	return out


# ------------------------------------------------------------------ main entry
static func build(kind: String, color: Color, accent: Color = Color(0.05, 0.05, 0.06)) -> Dictionary:
	_mats()
	if MODELS.has(kind):
		return build_glb(kind, color)
	if not cfg_of(kind).is_empty():
		return build_pro(kind, color, accent)
	var spec: Dictionary = BODIES[kind]
	var L: float = spec["len"]
	var Wd: float = spec["wid"]
	var hl := L * 0.5
	var wr: float = spec["wr"]
	var wb: float = spec["wb"]
	var secs: Array = spec["sec"]
	var body := MeshUtil.new()
	var glass := MeshUtil.new()
	var trim := MeshUtil.new()
	var tubm := MeshUtil.new()
	# ---------------- hull samples
	var nz := int(ceil(L / 0.06))
	var Ra := wr * 1.16 + 0.03
	var grid: Array = []
	var zs: Array = []
	var cab: Array = []
	var cabin_z0 := 1e9
	var cabin_z1 := -1e9
	for si in nz + 1:
		var zn := -1.0 + 2.0 * float(si) / float(nz)
		var z := zn * hl
		var pr := _param(secs, zn)
		var yb: float = pr[0]
		var ybelt: float = pr[1]
		var yt: float = maxf(float(pr[2]), ybelt + 0.02)
		var hwb: float = pr[3]
		hwb *= Wd * 0.5
		var hwr: float = pr[4] * Wd * 0.5
		var hwroof := hwb * 0.97 * (hwr / maxf(hwb, 0.01)) if hwb > 0.01 else hwr
		var c := clampf((yt - ybelt) / 0.22, 0.0, 1.0)
		cab.append(c)
		if c > 0.5:
			cabin_z0 = minf(cabin_z0, z)
			cabin_z1 = maxf(cabin_z1, z)
		var hbelt := hwb * 0.985
		var ysh := yb + (ybelt - yb) * 0.55
		# wheel arch cut
		var arch := 0.0
		for zw in [wb * 0.5, -wb * 0.5]:
			var dz := absf(z - zw)
			if dz < Ra:
				arch = maxf(arch, wr + sqrt(Ra * Ra - dz * dz))
		var yb2 := maxf(yb, arch)
		var ys2 := maxf(ysh, arch + 0.015) if arch > 0.0 else ysh
		ys2 = minf(ys2, ybelt - 0.01)
		var half := [
			Vector3(0.74 * hwb, yb2, z), Vector3(hwb * 0.996, yb2 + 0.04, z), Vector3(hwb, ys2, z), Vector3(hbelt, ybelt, z),
			Vector3(lerpf(hbelt * 0.9, hwroof * 1.04, c), lerpf(ybelt + 0.025, ybelt + (yt - ybelt) * 0.55, c), z),
			Vector3(lerpf(hbelt * 0.62, hwroof * 0.82, c), lerpf(ybelt + 0.04, yt - 0.04, c), z),
			Vector3(0.0, yt + 0.012, z)]
		var ring: Array = []
		for k in half.size():
			ring.append(Vector3(-half[k].x, half[k].y, half[k].z))
		for k in range(half.size() - 2, -1, -1):
			ring.append(half[k])
		grid.append(ring)
		zs.append(z)
	var R: int = RING
	var nacc: Array = []
	for si in grid.size():
		var rowv: Array = []
		for k in R:
			rowv.append(Vector3.ZERO)
		nacc.append(rowv)
	var faces: Array = []
	var flip_sign := 0.0
	for si in grid.size() - 1:
		for k in R:
			var k2 := (k + 1) % R
			var v00: Vector3 = grid[si][k]
			var v01: Vector3 = grid[si][k2]
			var v10: Vector3 = grid[si + 1][k]
			var v11: Vector3 = grid[si + 1][k2]
			var fn := (v01 - v00).cross(v10 - v00)
			if fn.length() < 0.0000001:
				fn = (v11 - v01).cross(v10 - v01)
			fn = fn.normalized()
			if flip_sign == 0.0:
				var probe := (grid[si][2] as Vector3)
				var pn := ((grid[si][3] as Vector3) - probe).cross((grid[si + 1][2] as Vector3) - probe)
				flip_sign = -1.0 if pn.x > 0.0 else 1.0
			fn = fn * flip_sign
			for pr in [[si, k], [si, k2], [si + 1, k], [si + 1, k2]]:
				nacc[pr[0]][pr[1]] += fn
			faces.append([si, k, k2, fn])
	# window intervals along z (side glass) -- pillars stay painted/black
	var cl := maxf(cabin_z1 - cabin_z0, 0.1)
	var wins := []
	if kind == "sedan" or kind == "suv" or kind == "pickup":
		wins = [[cabin_z0 + 0.05 * cl, cabin_z0 + 0.47 * cl], [cabin_z0 + 0.5 * cl, cabin_z1 - 0.1 * cl]]
	elif kind == "van" or kind == "bus":
		wins = [[cabin_z0 + 0.1 * cl, cabin_z1 - 0.1 * cl]]
	else:
		wins = [[cabin_z0 + 0.12 * cl, cabin_z1 - 0.14 * cl]]
	for fc in faces:
		var si: int = fc[0]
		var k: int = fc[1]
		var k2: int = fc[2]
		var fn: Vector3 = fc[3]
		var c: float = (cab[si] + cab[si + 1]) * 0.5
		var zc: float = (zs[si] + zs[si + 1]) * 0.5
		var mu: MeshUtil = body
		var side_win := false
		if c > 0.5 and (k == 3 or k == 4 or k == R - 4 or k == R - 5):
			for w in wins:
				if zc > w[0] and zc < w[1]:
					side_win = true
			mu = glass if side_win else trim
		if k >= 4 and k <= R - 5 and c > 0.03:
			var ya: float = (grid[si][6] as Vector3).y
			var yb2: float = (grid[si + 1][6] as Vector3).y
			var slope := absf(yb2 - ya) / maxf(absf((zs[si + 1] as float) - (zs[si] as float)), 0.001)
			if slope > 0.3:
				mu = glass
		if mu == glass and k >= 4 and k <= R - 5:
			pass
		var ids := []
		for pr in [[si, k], [si + 1, k], [si + 1, k2], [si, k2]]:
			var nn: Vector3 = (nacc[pr[0]][pr[1]] as Vector3).normalized()
			ids.append(mu.add_vertex(grid[pr[0]][pr[1]], nn, Vector2(0, 0), Color.WHITE))
		mu.quad_auto(ids[0], ids[1], ids[2], ids[3], fn)
	# end caps (nose / tail)
	for end in [0, grid.size() - 1]:
		var ring: Array = grid[end]
		var zc: float = (ring[0] as Vector3).z
		var dirn := -1.0 if end == 0 else 1.0
		var ci := body.add_vertex(Vector3(0, 0.5 * ((ring[3] as Vector3).y + (ring[0] as Vector3).y), zc), Vector3(0, 0, dirn), Vector2.ZERO, Color.WHITE)
		var rid := []
		for k in R:
			rid.append(body.add_vertex(ring[k], Vector3(0, 0.05, dirn), Vector2.ZERO, Color.WHITE))
		for k in R:
			body.tri_auto(ci, rid[k], rid[(k + 1) % R], Vector3(0, 0, dirn))
	# underbody plate
	var root := Node3D.new()
	var mi := MeshInstance3D.new()
	var stripe := 1.0 if (kind == "hyper" or kind == "coupe") else 0.0
	mi.mesh = body.build(paint_shader(color, accent, spec, stripe, 0.5))
	root.add_child(mi)
	var paint_mat: Material = mi.mesh.surface_get_material(0)
	root.set_meta("paint", paint_mat)
	var gi := MeshInstance3D.new()
	gi.mesh = glass.build(_m["glass"])
	gi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(gi)
	var ti := MeshInstance3D.new()
	ti.mesh = trim.build(_m["trim"])
	root.add_child(ti)

	# ---------------- details
	var det := MeshUtil.new()          # dark/gloss details (carbon material)
	var chrome := MeshUtil.new()
	var lamps := MeshUtil.new()
	var drls := MeshUtil.new()
	var tails := MeshUtil.new()
	var amber := MeshUtil.new()
	var accent_m := MeshUtil.new()
	var plates := MeshUtil.new()
	var seatm := MeshUtil.new()
	var yb_nose: float = float((secs[secs.size() - 1] as Array)[1])
	var yt_nose: float = float((secs[secs.size() - 1] as Array)[2])
	var yb_tail: float = float((secs[0] as Array)[1])
	var yt_tail: float = float((secs[0] as Array)[2])
	var low_car := kind == "hyper" or kind == "coupe"
	# --- front fascia: lower intake with mesh bars, splitter, headlights, DRLs
	var nose_h := yt_nose - yb_nose
	var inlet_w := Wd * (0.42 if low_car else 0.34)
	_box_t(det, Transform3D(Basis.IDENTITY, Vector3(0, yb_nose + nose_h * 0.38, hl + 0.002)), Vector3(inlet_w, nose_h * 0.52, 0.04))
	for i in 5:
		var yy := yb_nose + nose_h * (0.16 + 0.15 * float(i))
		_box_t(chrome, Transform3D(Basis.IDENTITY, Vector3(0, yy, hl + 0.025)), Vector3(inlet_w * 0.96, 0.012, 0.012))
	# splitter / air dam
	_box_t(accent_m, Transform3D(Basis.IDENTITY, Vector3(0, yb_nose - 0.01, hl - 0.05)), Vector3(Wd * 0.94, 0.035, 0.34 if low_car else 0.22))
	# side intakes (hyper) and brake ducts
	for sx in [-1.0, 1.0]:
		var hx: float = sx * (Wd * 0.5 * 0.9)
		# headlight: slim wedge on the front corner
		var hy := yt_nose - 0.04 if not low_car else yt_nose + 0.1
		var hz := hl - (0.18 if low_car else 0.05)
		var ang := 0.45 if low_car else 0.15
		var bas := Basis(Vector3.UP, -sx * ang) * Basis(Vector3.RIGHT, 0.08 if low_car else 0.0)
		var hlw := Wd * (0.26 if low_car else 0.22)
		_box_t(det, Transform3D(bas, Vector3(hx * 0.62, hy, hz)), Vector3(hlw + 0.1, 0.11 if low_car else 0.17, 0.12))                # housing
		_lamp_unit(lamps, drls, chrome, Vector3(hx * 0.62, hy + 0.005, hz + 0.045), bas, hlw, 0.1 if low_car else 0.13, sx)
		# fog light / lower intake detail
		_box_t(det, Transform3D(Basis.IDENTITY, Vector3(sx * Wd * 0.36, yb_nose + 0.1, hl + 0.002)), Vector3(0.18, 0.07, 0.03))
		# amber indicator
		_box_t(amber, Transform3D(bas, Vector3(hx * 0.9, hy - 0.02, hz - 0.03)), Vector3(0.1, 0.035, 0.03))
	# hood vents / scoop
	if kind == "hyper" or kind == "coupe":
		var hood_y := _hood_y(secs, 0.62) + 0.005
		for i in 5:
			_box_t(det, Transform3D(Basis(Vector3.RIGHT, -0.08), Vector3(0.0, hood_y, hl * (0.52 + 0.04 * float(i)))), Vector3(Wd * 0.2, 0.012, 0.03))
	# --- tail: LED light bar, signature clusters, diffuser, exhausts, plate
	var tail_h := yt_tail - yb_tail
	var tz := -hl - 0.002
	var tail_y := yb_tail + tail_h * (0.72 if low_car else 0.62)
	for sx in [-1.0, 1.0]:
		var tw := Wd * 0.3
		_box_t(det, Transform3D(Basis.IDENTITY, Vector3(sx * Wd * 0.3, tail_y, tz - 0.004)), Vector3(tw + 0.04, 0.1 if low_car else 0.15, 0.04))
		_box_t(tails, Transform3D(Basis.IDENTITY, Vector3(sx * Wd * 0.3, tail_y, tz - 0.026)), Vector3(tw, 0.07 if low_car else 0.12, 0.02))
		for j in 4:
			_box_t(det, Transform3D(Basis.IDENTITY, Vector3(sx * (Wd * 0.3 - tw * 0.5 + tw * (0.18 + 0.2 * float(j))), tail_y, tz - 0.04)), Vector3(0.008, 0.075 if low_car else 0.125, 0.012))
		_box_t(amber, Transform3D(Basis.IDENTITY, Vector3(sx * Wd * 0.18, tail_y - 0.08, tz - 0.022)), Vector3(0.1, 0.03, 0.02))
		# exhaust tips: dual round lathe
		var ex_x: float = sx * Wd * (0.2 if low_car else 0.3)
		var ex_prof := [Vector2(0.036, -0.0), Vector2(0.05, 0.0), Vector2(0.05, -0.16), Vector2(0.042, -0.16), Vector2(0.036, -0.12)]
		_lathe(chrome, ex_prof, 12, Transform3D(Basis(Vector3.RIGHT, PI * 0.5), Vector3(ex_x, yb_tail + 0.07, -hl + 0.02)))
	_box_t(tails, Transform3D(Basis.IDENTITY, Vector3(0, tail_y + 0.01, tz - 0.026)), Vector3(Wd * 0.2, 0.025, 0.02))      # centre brake bar
	_box_t(plates, Transform3D(Basis.IDENTITY, Vector3(0, yb_tail + tail_h * 0.36, tz - 0.012)), Vector3(0.52, 0.12, 0.012))
	_box_t(plates, Transform3D(Basis.IDENTITY, Vector3(0, yb_nose + nose_h * 0.06, hl + 0.01)), Vector3(0.5, 0.11, 0.01))
	if low_car:
		# diffuser fins
		for i in 7:
			_box_t(carbon_t(), Transform3D(Basis.IDENTITY, Vector3((float(i) - 3.0) * 0.16, yb_tail + 0.06, -hl + 0.12)), Vector3(0.012, 0.1, 0.34))
		_box_t(det, Transform3D(Basis.IDENTITY, Vector3(0, yb_tail + 0.03, -hl + 0.13)), Vector3(Wd * 0.78, 0.03, 0.36))
	# --- side details: skirts, mirrors, door handles (shader), fuel flap, side vents
	for sx in [-1.0, 1.0]:
		var sk_y := 0.2 if low_car else (0.3 if kind != "suv" and kind != "pickup" else 0.36)
		_box_t(accent_m, Transform3D(Basis.IDENTITY, Vector3(sx * (Wd * 0.5 - 0.005), sk_y, 0.0)), Vector3(0.05, 0.05, wb * 0.62))
		var by := _belt_y(secs, 0.3)
		var mirror_z := hl * (0.24 if kind != "van" else 0.55)
		var mir_y := by + 0.1
		var mx: float = sx * (Wd * 0.5 + 0.08)
		_box_t(det, Transform3D(Basis(Vector3.UP, sx * 0.15), Vector3(mx, mir_y, mirror_z)), Vector3(0.2, 0.12, 0.09))
		_box_t(accent_m, Transform3D(Basis(Vector3.UP, sx * 0.15), Vector3(mx, mir_y, mirror_z + 0.005)), Vector3(0.18, 0.1, 0.07))
		_box_t(det, Transform3D(Basis(Vector3.UP, 0.0), Vector3(sx * (Wd * 0.5 - 0.02), mir_y - 0.08, mirror_z - 0.02)), Vector3(0.1, 0.03, 0.04))
	if kind == "hyper":
		for sx in [-1.0, 1.0]:
			# side air intakes behind doors
			_box_t(det, Transform3D(Basis(Vector3.UP, 0.0), Vector3(sx * (Wd * 0.5 - 0.01), 0.58, -wb * 0.12)), Vector3(0.04, 0.2, 0.55))
			for i in 4:
				_box_t(carbon_t(), Transform3D(Basis.IDENTITY, Vector3(sx * (Wd * 0.5 + 0.005), 0.58, -wb * 0.12 + (float(i) - 1.5) * 0.12)), Vector3(0.02, 0.19, 0.012))
	# --- spoiler / wing
	if kind == "hyper":
		var deck := _hood_y(secs, -0.78)
		var wy := deck + 0.34
		var wz := -hl + 0.26
		_box_t(accent_m, Transform3D(Basis(Vector3.RIGHT, -0.07), Vector3(0, wy, wz)), Vector3(Wd * 0.96, 0.04, 0.4))
		_box_t(accent_m, Transform3D(Basis(Vector3.RIGHT, -0.3), Vector3(0, wy + 0.05, wz - 0.16)), Vector3(Wd * 0.96, 0.025, 0.16))
		for sx in [-1.0, 1.0]:
			_box_t(accent_m, Transform3D(Basis.IDENTITY, Vector3(sx * Wd * 0.48, wy + 0.03, wz)), Vector3(0.03, 0.26, 0.56))
			_box_t(det, Transform3D(Basis(Vector3.RIGHT, 0.12), Vector3(sx * Wd * 0.17, deck + 0.13, wz + 0.04)), Vector3(0.05, 0.42, 0.12))
	elif kind == "coupe":
		_box_t(accent_m, Transform3D(Basis(Vector3.RIGHT, -0.15), Vector3(0, yt_tail + 0.12, -hl + 0.2)), Vector3(Wd * 0.84, 0.03, 0.26))
		for sx in [-1.0, 1.0]:
			_box_t(carbon_t(), Transform3D(Basis.IDENTITY, Vector3(sx * Wd * 0.34, yt_tail + 0.06, -hl + 0.2)), Vector3(0.04, 0.12, 0.2))
	elif kind == "sedan":
		_box_t(accent_m, Transform3D(Basis(Vector3.RIGHT, -0.12), Vector3(0, yt_tail + 0.03, -hl + 0.12)), Vector3(Wd * 0.7, 0.025, 0.14))
	elif kind == "suv" or kind == "pickup" or kind == "van":
		# roof rails + running boards + bumper guards
		if kind == "suv":
			for sx in [-1.0, 1.0]:
				_box_t(chrome, Transform3D(Basis.IDENTITY, Vector3(sx * Wd * 0.3, float(_param(secs, -0.1)[2]) - 0.03, -hl * 0.1)), Vector3(0.04, 0.05, L * 0.36))
		_box_t(det, Transform3D(Basis.IDENTITY, Vector3(0, yb_nose + 0.06, hl - 0.03)), Vector3(Wd * 0.9, 0.12, 0.12))
		_box_t(det, Transform3D(Basis.IDENTITY, Vector3(0, yb_tail + 0.06, -hl + 0.03)), Vector3(Wd * 0.9, 0.12, 0.12))
	if kind == "pickup":
		# open load bed: tub floor + walls (hull is closed, so the bed is built from boxes above the deck)
		var bz0 := -hl
		var bz1 := -hl * 0.3
		var bl := bz1 - bz0
		var bed_y := float((secs[0] as Array)[2])
		for sx in [-1.0, 1.0]:
			_box_t(body_t(), Transform3D(Basis.IDENTITY, Vector3(sx * (Wd * 0.5 - 0.06), bed_y + 0.18, (bz0 + bz1) * 0.5)), Vector3(0.12, 0.36, bl))
		_box_t(body_t(), Transform3D(Basis.IDENTITY, Vector3(0, bed_y + 0.18, bz1 - 0.05)), Vector3(Wd * 0.9, 0.36, 0.1))
		_box_t(det, Transform3D(Basis.IDENTITY, Vector3(0, bed_y + 0.012, (bz0 + bz1) * 0.5)), Vector3(Wd * 0.78, 0.02, bl - 0.1))
		_box_t(body_t(), Transform3D(Basis.IDENTITY, Vector3(0, bed_y + 0.18, bz0 + 0.03)), Vector3(Wd * 0.9, 0.36, 0.06))
	if kind == "bus":
		for i in 7:
			_box_t(carbon_t(), Transform3D(Basis.IDENTITY, Vector3(0, 1.9, -hl * 0.8 + float(i) * hl * 0.27)), Vector3(Wd + 0.01, 0.9, 0.7))
	# ---------------- interior (visible through glass)
	var cz := (cabin_z0 + cabin_z1) * 0.5
	var floor_y := 0.3
	var roof_y: float = float((secs[3] as Array)[3])
	var belt_y: float = float((secs[3] as Array)[2])
	_box_t(seatm, Transform3D(Basis.IDENTITY, Vector3(0, floor_y + 0.02, cz)), Vector3(Wd * 0.8, 0.04, cl * 0.9))
	var dash_z := cabin_z1 - cl * 0.22
	_box_t(seatm, Transform3D(Basis(Vector3.RIGHT, -0.15), Vector3(0, belt_y - 0.08, dash_z - 0.1)), Vector3(Wd * 0.5, 0.2, 0.3))
	for sx in [-1.0, 1.0]:
		var sxp: float = sx * Wd * 0.2
		var sz2: float = cz + cl * 0.02
		_box_t(seatm, Transform3D(Basis.IDENTITY, Vector3(sxp, floor_y + 0.18, sz2)), Vector3(0.48, 0.14, 0.5))
		_box_t(seatm, Transform3D(Basis(Vector3.RIGHT, 0.22), Vector3(sxp, floor_y + 0.46, sz2 - 0.26)), Vector3(0.48, 0.5, 0.12))
		_box_t(seatm, Transform3D(Basis.IDENTITY, Vector3(sxp, floor_y + 0.76, sz2 - 0.3)), Vector3(0.28, 0.14, 0.08))
		if kind != "hyper":
			_box_t(seatm, Transform3D(Basis.IDENTITY, Vector3(sxp * 1.1, floor_y + 0.18, sz2 - cl * 0.34)), Vector3(0.55, 0.14, 0.5))
			_box_t(seatm, Transform3D(Basis(Vector3.RIGHT, 0.2), Vector3(sxp * 1.1, floor_y + 0.46, sz2 - cl * 0.34 - 0.26)), Vector3(0.55, 0.5, 0.12))
	# steering wheel
	var sw_prof := [Vector2(0.15, -0.015), Vector2(0.17, -0.015), Vector2(0.17, 0.015), Vector2(0.15, 0.015), Vector2(0.15, -0.015)]
	_lathe(seatm, sw_prof, 14, Transform3D(Basis(Vector3.RIGHT, PI * 0.5 - 0.5), Vector3(-Wd * 0.2, belt_y + 0.0, dash_z - 0.28)))
	_box_t(seatm, Transform3D(Basis(Vector3.RIGHT, -0.5), Vector3(-Wd * 0.2, belt_y - 0.02, dash_z - 0.26)), Vector3(0.28, 0.02, 0.025))
	# rear-view mirror
	_box_t(seatm, Transform3D(Basis.IDENTITY, Vector3(0, roof_y - 0.12, dash_z - 0.5)), Vector3(0.2, 0.05, 0.03))
	# ---------------- add detail meshes
	_add_mesh(root, det, _m["carbon"])
	_add_mesh(root, chrome, _m["chrome"])
	_add_mesh(root, lamps, _m["head"])
	_add_mesh(root, drls, _m["drl"])
	_add_mesh(root, tails, _m["tail"])
	_add_mesh(root, amber, _m["amber"])
	_add_mesh(root, accent_m, paint_shader(accent, color, spec, 0.0, 0.0))
	_add_mesh(root, plates, _m["plate"])
	_add_mesh(root, seatm, _m["seat"])
	# wheel tubs
	var wheels: Array = []
	var track := Wd * 0.5 - 0.07
	var wd := 0.27 if not low_car else 0.32
	for i in 4:
		var z := wb * 0.5 if i < 2 else -wb * 0.5
		var x := -track if i % 2 == 0 else track
		var pivot := Node3D.new()
		pivot.position = Vector3(x, wr, z)
		var spin := Node3D.new()
		pivot.add_child(spin)
		var w := _wheel(wr, wd, kind, i >= 2)
		w.rotation = Vector3(0, 0, PI * 0.5) if i % 2 == 0 else Vector3(0, 0, -PI * 0.5)
		spin.add_child(w)
		root.add_child(pivot)
		wheels.append(pivot)
		# half-cylinder wheel house behind the tyre (upper half only)
		var side := -1.0 if i % 2 == 0 else 1.0
		var tub_prof := []
		for a in 13:
			var ang := PI * float(a) / 12.0
			tub_prof.append(Vector3(cos(ang) * (Ra - 0.012), sin(ang) * (Ra - 0.012), 0.0))
		var tm := MeshUtil.new()
		var xin := side * (Wd * 0.5 - 0.5)
		var xout := side * (Wd * 0.5 - 0.01)
		for a in 12:
			var p0: Vector3 = tub_prof[a]
			var p1: Vector3 = tub_prof[a + 1]
			var nrm := Vector3(-(p0 + p1).x, -(p0 + p1).y, 0).normalized()
			var q0 := tm.add_vertex(Vector3(xin, wr + p0.y, z + p0.x), nrm, Vector2.ZERO, Color.WHITE)
			var q1 := tm.add_vertex(Vector3(xout, wr + p0.y, z + p0.x), nrm, Vector2.ZERO, Color.WHITE)
			var q2 := tm.add_vertex(Vector3(xout, wr + p1.y, z + p1.x), nrm, Vector2.ZERO, Color.WHITE)
			var q3 := tm.add_vertex(Vector3(xin, wr + p1.y, z + p1.x), nrm, Vector2.ZERO, Color.WHITE)
			tm.quad_auto(q0, q1, q2, q3, nrm)
		var tmi := MeshInstance3D.new()
		tmi.mesh = tm.build(_m["tub"])
		root.add_child(tmi)
	return {"node": root, "wheels": wheels, "spec": spec, "tail": _m["tail"], "head": _m["head"]}


static var _carbon_cache: MeshUtil
static func carbon_t() -> MeshUtil:
	return _dummy()
static func body_t() -> MeshUtil:
	return _dummy()
static func _dummy() -> MeshUtil:
	# these helpers write into a scratch mesh that is discarded: detail pieces that should follow the
	# body colour are handled by passing the right MeshUtil explicitly (see call sites)
	if _carbon_cache == null:
		_carbon_cache = MeshUtil.new()
	_carbon_cache.v.clear(); _carbon_cache.n.clear(); _carbon_cache.uv.clear(); _carbon_cache.col.clear(); _carbon_cache.idx.clear()
	return _carbon_cache


static func _add_mesh(root: Node3D, mu: MeshUtil, mat: Material) -> void:
	if mu.vertex_count() == 0:
		return
	var mi := MeshInstance3D.new()
	mi.mesh = mu.build(mat)
	root.add_child(mi)


static func _belt_y(secs: Array, zn: float) -> float:
	return float(_param(secs, zn)[1])


static func _hood_y(secs: Array, zn: float) -> float:
	var p := _param(secs, zn)
	return maxf(float(p[1]), float(p[2])) + 0.01


static func _lamp_unit(lamps: MeshUtil, drls: MeshUtil, chrome: MeshUtil, c: Vector3, bas: Basis, w: float, h: float, sx: float) -> void:
	# reflector bowl (chrome ring) + projector lens + LED DRL strip
	var ring := [Vector2(0.0, 0.0), Vector2(h * 0.46, 0.0), Vector2(h * 0.5, 0.01), Vector2(h * 0.46, 0.02), Vector2(h * 0.34, 0.02)]
	var xf := Transform3D(bas * Basis(Vector3.RIGHT, PI * 0.5), c + bas * Vector3(sx * -w * 0.2, 0, 0.006))
	_lathe(chrome, ring, 14, xf)
	var lens := [Vector2(0.0, 0.025), Vector2(h * 0.33, 0.022), Vector2(h * 0.34, 0.0)]
	_lathe(lamps, lens, 12, Transform3D(bas * Basis(Vector3.RIGHT, PI * 0.5), c + bas * Vector3(sx * -w * 0.2, 0, 0.008)))
	_box_t(drls, Transform3D(bas, c + bas * Vector3(sx * w * 0.1, -h * 0.34, 0.012)), Vector3(w * 0.7, 0.012, 0.012))
	_box_t(lamps, Transform3D(bas, c + bas * Vector3(sx * w * 0.36, h * 0.1, 0.01)), Vector3(w * 0.22, h * 0.45, 0.01))


static func _wheel(r: float, wd: float, kind: String, rear: bool) -> Node3D:
	var root := Node3D.new()
	var hw := wd * 0.5
	var ri := r * 0.66               # bead / rim radius
	# ---- tyre (lathe, rounded shoulders, tread grooves)
	var tm := MeshUtil.new()
	var tp := [Vector2(ri, -hw * 0.82), Vector2(ri + (r - ri) * 0.35, -hw * 0.98), Vector2(r - 0.04, -hw * 0.92), Vector2(r - 0.012, -hw * 0.74), Vector2(r, -hw * 0.55)]
	for g in 3:
		var yc := -hw * 0.3 + float(g) * hw * 0.3
		tp.append_array([Vector2(r, yc - 0.012), Vector2(r - 0.012, yc - 0.006), Vector2(r - 0.012, yc + 0.006), Vector2(r, yc + 0.012)])
	tp.append_array([Vector2(r, hw * 0.55), Vector2(r - 0.012, hw * 0.74), Vector2(r - 0.04, hw * 0.92), Vector2(ri + (r - ri) * 0.35, hw * 0.98), Vector2(ri, hw * 0.82)])
	_lathe(tm, tp, 32)
	var tmi := MeshInstance3D.new()
	tmi.mesh = tm.build(_m["tyre"])
	root.add_child(tmi)
	# ---- rim: lip ring + dark barrel + spokes + hub
	var rm := MeshUtil.new()
	var yo := hw * 0.8
	var lip := [Vector2(ri - 0.02, yo - 0.045), Vector2(ri - 0.005, yo - 0.01), Vector2(ri + 0.005, yo + 0.012), Vector2(ri - 0.015, yo + 0.018), Vector2(ri * 0.9, yo - 0.005)]
	_lathe(rm, lip, 32)
	var nspoke := 5 if kind != "hyper" else 10
	var hub_r := 0.07
	for s in nspoke:
		var a := TAU * float(s) / float(nspoke)
		var xf := Transform3D(Basis(Vector3.UP, a), Vector3.ZERO)
		var spoke_len := ri * 0.92 - hub_r
		var width := 0.05 if kind != "hyper" else 0.026
		var taper := 0.0
		_box_t(rm, xf * Transform3D(Basis.IDENTITY, Vector3(hub_r + spoke_len * 0.5, yo - 0.03, 0.0)), Vector3(spoke_len, 0.03, width))
		if kind != "hyper":
			# Y-fork at the rim
			for sg in [-1.0, 1.0]:
				_box_t(rm, xf * Transform3D(Basis(Vector3.UP, sg * 0.35), Vector3(hub_r + spoke_len * 0.9, yo - 0.03, sg * 0.03)), Vector3(spoke_len * 0.3, 0.03, width * 0.7))
	var hub := [Vector2(0.0, yo + 0.005), Vector2(hub_r * 0.5, yo + 0.012), Vector2(hub_r, yo - 0.005), Vector2(hub_r * 1.05, yo - 0.04)]
	_lathe(rm, hub, 16)
	for l in 5:
		var la := TAU * float(l) / 5.0
		_lathe(rm, [Vector2(0.0, 0.012), Vector2(0.011, 0.012), Vector2(0.011, 0.0)], 6, Transform3D(Basis.IDENTITY, Vector3(cos(la) * hub_r * 0.78, yo - 0.003, sin(la) * hub_r * 0.78)))
	var rmi := MeshInstance3D.new()
	rmi.mesh = rm.build(_m["rim"])
	root.add_child(rmi)
	# barrel (dark, seen between spokes)
	var bm := MeshUtil.new()
	var barrel := [Vector2(ri - 0.02, -hw * 0.7), Vector2(ri - 0.02, hw * 0.7), Vector2(0.0, hw * 0.7)]
	_lathe(bm, [Vector2(0.0, yo - 0.05), Vector2(ri - 0.02, yo - 0.05), Vector2(ri - 0.02, -hw * 0.6)], 24)
	var bmi := MeshInstance3D.new()
	bmi.mesh = bm.build(_m["dark"])
	root.add_child(bmi)
	# ---- brake disc + caliper
	var dm := MeshUtil.new()
	var disc_r := ri * 0.88
	_lathe(dm, [Vector2(0.08, yo - 0.14), Vector2(disc_r * 0.55, yo - 0.14), Vector2(disc_r, yo - 0.145), Vector2(disc_r, yo - 0.12), Vector2(disc_r * 0.5, yo - 0.115)], 28)
	for h in 12:
		var ha := TAU * float(h) / 12.0 + 0.1
		_lathe(dm, [Vector2(0.0, 0.0), Vector2(0.014, 0.0)], 6, Transform3D(Basis.IDENTITY, Vector3(cos(ha) * disc_r * 0.78, yo - 0.1175, sin(ha) * disc_r * 0.78)))
	var dmi := MeshInstance3D.new()
	dmi.mesh = dm.build(_m["dark"])
	root.add_child(dmi)
	var cm := MeshUtil.new()
	var ca := -0.4 if rear else 0.4
	_box_t(cm, Transform3D(Basis(Vector3.UP, ca), Vector3(cos(ca) * disc_r * 0.78, yo - 0.095, sin(ca) * disc_r * 0.78)), Vector3(0.09, 0.07, 0.17))
	var cmi := MeshInstance3D.new()
	cmi.mesh = cm.build(_m["caliper"])
	root.add_child(cmi)
	return root


static func _chain_xf(n: Node, stop: Node) -> Transform3D:
	var t := Transform3D.IDENTITY
	var cur := n
	while cur != null and cur != stop:
		if cur is Node3D:
			t = (cur as Node3D).transform * t
		cur = cur.get_parent()
	return t


## Real, hand-modelled car (glTF). Wheels are split out into steerable/spinning pivots, paint surfaces use the
## dent-capable clear-coat paint shader and glass gets a proper transparent, reflective material.
static func build_glb(kind: String, color: Color) -> Dictionary:
	_mats()
	var cfg: Dictionary = MODELS[kind]
	var inst: Node3D = (load(cfg["path"]) as PackedScene).instantiate()
	var root := Node3D.new()
	var holder := Node3D.new()
	root.add_child(holder)
	holder.add_child(inst)
	var flip := Basis(Vector3.UP, PI) if cfg.get("flip", false) else Basis.IDENTITY
	if cfg.has("yaw"):
		flip = Basis(Vector3.UP, deg_to_rad(float(cfg["yaw"])))
	holder.basis = flip
	# ---- overall scale (stylised kits are rescaled to real-world size)
	var all_aabb := _merged_aabb(inst, holder)
	var sc := 1.0
	if float(cfg["len"]) > 0.0:
		sc = float(cfg["len"]) / maxf(all_aabb.size.z, all_aabb.size.x)
		if all_aabb.size.x > all_aabb.size.z:
			sc = float(cfg["len"]) / all_aabb.size.x
		holder.basis = flip * Basis.from_scale(Vector3(sc, sc, sc))
	# ---- find wheels
	var wn: Array = []
	if cfg.has("wheel_mats"):
		wn = _split_wheels(inst, holder, cfg["wheel_mats"])
	for pat in cfg.get("wheels", []):
		var found := inst.find_children(pat, "Node3D", true, false)
		wn.append(found[0] if found.size() > 0 else null)
	var info: Array = []
	var diam := 0.0
	for w in wn:
		var wb := _merged_aabb(w, holder)
		var cen := wb.get_center()
		diam = maxf(diam, maxf(wb.size.y, wb.size.z))
		info.append({"node": w, "centre": cen, "aabb": wb})
	var wr := diam * 0.5
	# ---- centre the axle midpoint on the origin and put tyres on y = 0
	var mean := Vector3.ZERO
	for i in info:
		mean += (i["centre"] as Vector3) * 0.25
	var offs := Vector3(-mean.x, wr - mean.y, -mean.z)
	holder.position = offs
	# ---- slots: 0 FL(x<0) 1 FR 2 RL 3 RR in the vehicle's convention (front = +z)
	var slots := [null, null, null, null]
	for i in info:
		var c: Vector3 = (i["centre"] as Vector3) + offs
		var slot := (0 if c.z > 0.0 else 2) + (0 if c.x < 0.0 else 1)
		i["c"] = c
		slots[slot] = i
	var wheels_out: Array = []
	for slot in 4:
		var d = slots[slot]
		var n3: Node3D = d["node"]
		var pivot := Node3D.new()
		var spin := Node3D.new()
		pivot.add_child(spin)
		var xf := holder.transform * _chain_xf(n3, holder)
		var cen: Vector3 = d["c"]
		n3.get_parent().remove_child(n3)
		spin.add_child(n3)
		n3.transform = Transform3D(xf.basis, xf.origin - cen)
		pivot.position = cen
		root.add_child(pivot)
		wheels_out.append(pivot)
	var c0: Vector3 = (slots[0] as Dictionary)["c"]
	var c2: Vector3 = (slots[2] as Dictionary)["c"]
	var body_aabb := _merged_aabb(inst, holder)
	var spec := {"len": body_aabb.size.z, "wid": minf(body_aabb.size.x, 2.2), "wr": wr, "kind": kind,
		"wb": absf(c0.z - c2.z), "wid_track": absf(c0.x)}
	# ---- materials
	var paint_mats: Dictionary = {}
	var main_paint: ShaderMaterial = null
	var glass_mat := StandardMaterial3D.new()
	glass_mat.albedo_color = Color(0.04, 0.06, 0.08, 0.32)
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass_mat.roughness = 0.04
	glass_mat.metallic = 0.0
	glass_mat.metallic_specular = 1.0
	glass_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	glass_mat.refraction_enabled = false
	var tail_mat: StandardMaterial3D = null
	var head_mat: StandardMaterial3D = null
	for c in inst.find_children("*", "MeshInstance3D", true, false):
		var mi := c as MeshInstance3D
		for sidx in mi.mesh.get_surface_count():
			var m := mi.mesh.surface_get_material(sidx)
			if m == null:
				continue
			var mname := m.resource_name
			var done := false
			for pn in cfg["paint"]:
				if mname.begins_with(pn):
					if not paint_mats.has(mname):
						var pm := ShaderMaterial.new()
						pm.shader = load("res://shaders/car_paint.gdshader")
						var base := color
						if main_paint != null:
							base = (m as BaseMaterial3D).albedo_color if m is BaseMaterial3D else color
						pm.set_shader_parameter("base_color", base)
						pm.set_shader_parameter("accent_color", base.lightened(0.35))
						pm.set_shader_parameter("panel_lines", float(cfg.get("panel_lines", 0.0)))
						pm.set_shader_parameter("flake_amount", 0.14)
						pm.set_shader_parameter("pearl", 0.3)
						paint_mats[mname] = pm
						if main_paint == null:
							main_paint = pm
					mi.set_surface_override_material(sidx, paint_mats[mname])
					done = true
					break
			if done:
				continue
			for gn in cfg["glass"]:
				if mname.begins_with(gn):
					if mname.begins_with("Taillight") or mname.begins_with("Projector"):
						done = false
					else:
						mi.set_surface_override_material(sidx, glass_mat)
						done = true
			if done:
				continue
			var lname := mname.to_lower()
			if m is StandardMaterial3D:
				var sm := (m as StandardMaterial3D).duplicate() as StandardMaterial3D
				sm.roughness = clampf(sm.roughness, 0.25, 0.9)
				if _starts_any(lname, ["brakelight", "lightback", "taillight"] + cfg.get("tail_mats", [])):
					if tail_mat == null:
						tail_mat = sm
						tail_mat.emission_enabled = true
						tail_mat.emission = Color(1.0, 0.03, 0.02)
					mi.set_surface_override_material(sidx, tail_mat)
				elif _starts_any(lname, ["headlight", "lightfront", "projector"] + cfg.get("head_mats", [])):
					sm.emission_enabled = true
					sm.emission = Color(1.0, 0.95, 0.85)
					sm.emission_energy_multiplier = 0.25
					head_mat = sm
					mi.set_surface_override_material(sidx, sm)
				elif lname.find("tire") >= 0 or lname.find("tyre") >= 0:
					sm.roughness = 0.9
					mi.set_surface_override_material(sidx, sm)
				else:
					mi.set_surface_override_material(sidx, sm)
	if main_paint:
		root.set_meta("paint", main_paint)
		root.set_meta("paints", paint_mats.values())
	if cfg.has("eye"):
		root.set_meta("eye", cfg["eye"])
	# ---- steering wheel pivot + driver eye point for the cockpit camera
	if cfg.has("steer"):
		var sn: Array = []
		for f in inst.find_children(cfg["steer"], "Node3D", true, false):
			var skip := false
			for o in sn:
				if (o as Node).is_ancestor_of(f):
					skip = true
			if not skip:
				sn.append(f)
		if sn.size() > 0:
			var sb := AABB()
			var first := true
			for f in sn:
				var bb := _merged_aabb(f, holder)
				bb = AABB(bb.position + offs, bb.size)
				sb = bb if first else sb.merge(bb)
				first = false
			var sc2 := sb.get_center()
			var sp := Node3D.new()
			sp.position = sc2
			root.add_child(sp)
			for f in sn:
				var n3 := f as Node3D
				var xf2 := holder.transform * _chain_xf(n3, holder)
				n3.get_parent().remove_child(n3)
				n3.owner = null
				sp.add_child(n3)
				n3.transform = Transform3D(xf2.basis, xf2.origin - sc2)
			root.set_meta("steer_pivot", sp)
			root.set_meta("eye", sc2 + Vector3(0.0, 0.14, -0.62))
	_merge_static(inst)
	return {"node": root, "wheels": wheels_out, "spec": spec, "tail": tail_mat if tail_mat else _m["tail"], "head": head_mat if head_mat else _m["head"]}


# ------------------------------------------------------------------ pro cars (standardised GLBs from the car pipeline)
## Catalogue entries with a "path" (res://data/cars.json + server cars). The GLB holds Body + SplitWheel0..3 in car space
## (+Z = nose, origin = axle midpoint on the ground); every material is named "<role>_<index>_<original>".
static var _cfgs: Dictionary = {}
static var _cfg_loaded := false


static func cfg_of(kind: String) -> Dictionary:
	if not _cfg_loaded:
		_cfg_loaded = true
		var d: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/cars.json"))
		if d is Dictionary:
			for c in (d as Dictionary).get("cars", []):
				if (c as Dictionary).has("path"):
					_cfgs[String(c["id"])] = c
	return _cfgs.get(kind, {})


static func register_cfg(c: Dictionary) -> void:
	cfg_of("")
	_cfgs[String(c["id"])] = c


static func phys_of(kind: String) -> String:
	if MODELS.has(kind):
		return String(MODELS[kind]["phys"])
	return String(cfg_of(kind).get("phys", kind))


static func _instance_glb(path: String) -> Node3D:
	if path.begins_with("res://"):
		var ps := load(path) as PackedScene
		return ps.instantiate() as Node3D if ps != null else null
	var doc := GLTFDocument.new()        # server-delivered car (user://), imported at run time
	var st := GLTFState.new()
	if doc.append_from_file(path, st) != OK:
		return null
	return doc.generate_scene(st) as Node3D


static func _pro_material(role: String, m: Material, paint: ShaderMaterial, glass: Material, heads: Array, tails: Array) -> Material:
	if role == "paint":
		return paint
	if role == "glass":
		return glass
	if not (m is StandardMaterial3D):
		return m
	var low := m.resource_name.to_lower()
	if role == "misc":
		var m0 := m as StandardMaterial3D
		if m0.albedo_texture == null and (low.contains("brake") or low.contains("disc") or low.contains("rotor")):
			var bd := m0.duplicate() as StandardMaterial3D        # brake discs come out white in some source models
			bd.albedo_color = Color(0.36, 0.36, 0.38)
			bd.metallic = 0.85
			bd.roughness = 0.42
			return bd
		return m
	var sm := (m as StandardMaterial3D).duplicate() as StandardMaterial3D
	match role:
		"lampf":
			sm.emission_enabled = true
			sm.emission = Color(1.0, 0.96, 0.86)
			if sm.albedo_texture != null:
				sm.emission_texture = sm.albedo_texture
			sm.emission_energy_multiplier = 0.25
			heads.append(sm)
		"lampr":
			sm.emission_enabled = true
			sm.emission = Color(1.0, 0.03, 0.02)
			if sm.albedo_texture != null:
				sm.emission_texture = sm.albedo_texture
			sm.emission_energy_multiplier = 0.5
			tails.append(sm)
		"tyre":
			if sm.albedo_texture == null:
				sm.albedo_color = Color(0.03, 0.03, 0.034)       # plain rubber (several models ship white tyre materials)
			sm.roughness = 0.92
			sm.metallic = 0.0
			sm.metallic_specular = 0.25
			sm.cull_mode = BaseMaterial3D.CULL_BACK
		"chrome":
			sm.metallic = 1.0
			sm.roughness = 0.08
		"carbon":
			sm.roughness = clampf(sm.roughness, 0.18, 0.6)
	return sm


static func build_pro(kind: String, color: Color, accent: Color = Color(0.05, 0.05, 0.06)) -> Dictionary:
	_mats()
	var cfg: Dictionary = cfg_of(kind)
	var inst: Node3D = _instance_glb(String(cfg["path"]))
	if inst == null:
		push_warning("car '%s' could not be loaded, using the built-in fallback" % kind)
		return build_glb("ferrari", color)
	var root := Node3D.new()
	root.name = "Car_" + kind
	root.add_child(inst)
	# ---- wheels: SplitWheelN -> pivot (steer + suspension travel) -> spin (rolling), centred on the wheel axle
	var wheels_out: Array = []
	for slot in 4:
		var wn := inst.find_child("SplitWheel%d" % slot, true, false) as Node3D
		var pivot := Node3D.new()
		var spin := Node3D.new()
		pivot.add_child(spin)
		if wn is MeshInstance3D:
			var mid := (wn as MeshInstance3D).get_aabb().get_center()
			var cen := wn.position + mid
			wn.get_parent().remove_child(wn)
			wn.owner = null
			spin.add_child(wn)
			wn.position = -mid
			pivot.position = cen
		root.add_child(pivot)
		wheels_out.append(pivot)
	# ---- materials by role (the role is the first token of the material name)
	var paint := ShaderMaterial.new()
	paint.shader = load("res://shaders/car_paint.gdshader")
	paint.set_shader_parameter("base_color", color)
	paint.set_shader_parameter("accent_color", accent)
	paint.set_shader_parameter("panel_lines", 0.0)
	paint.set_shader_parameter("flake_amount", 0.14)
	paint.set_shader_parameter("pearl", 0.3)
	paint.set_shader_parameter("body_len", float(cfg.get("len", 4.6)))
	paint.set_shader_parameter("body_wid", float(cfg.get("wid", 1.9)))
	paint.set_shader_parameter("wheelbase", float(cfg.get("wb", 2.7)))
	paint.set_shader_parameter("belt_y", float(cfg.get("hgt", 1.2)) * 0.6)
	var glass: Material = _m["glass"]
	var heads: Array = []
	var tails: Array = []
	var cache: Dictionary = {}
	for c in inst.find_children("*", "MeshInstance3D", true, false):
		var mi := c as MeshInstance3D
		if mi.mesh == null:
			continue
		for s in mi.mesh.get_surface_count():
			var m: Material = mi.mesh.surface_get_material(s)
			if m == null:
				continue
			var nm := m.resource_name
			var out: Material = cache.get(nm)
			if out == null:
				out = _pro_material(nm.get_slice("_", 0), m, paint, glass, heads, tails)
				cache[nm] = out
			if out != m:
				mi.set_surface_override_material(s, out)
	root.set_meta("paint", paint)
	root.set_meta("paints", [paint])
	# ---- steering wheel (split out by the car pipeline): pivot at the wheel centre, axis from the manifest
	var sw := inst.find_child("SteerWheel", true, false) as Node3D
	if sw != null and cfg.has("steer"):
		var st: Dictionary = cfg["steer"]
		var sc: Array = st["c"]
		var sa: Array = st["axis"]
		var sp := Node3D.new()
		sp.name = "SteerPivot"
		sp.position = Vector3(float(sc[0]), float(sc[1]), float(sc[2]))
		sw.get_parent().remove_child(sw)
		sw.owner = null
		sp.add_child(sw)
		sw.position = Vector3.ZERO
		root.add_child(sp)
		root.set_meta("steer_pivot", sp)
		root.set_meta("steer_axis", Vector3(float(sa[0]), float(sa[1]), float(sa[2])).normalized())
	var e: Array = cfg.get("eye", [0.36, 1.0, -0.2])
	root.set_meta("eye", Vector3(float(e[0]), float(e[1]), float(e[2])))
	var spec := {"len": float(cfg.get("len", 4.6)), "wid": float(cfg.get("wid", 1.95)), "wr": float(cfg.get("wr", 0.34)), "kind": kind,
		"wb": float(cfg.get("wb", 2.7)), "wid_track": float(cfg.get("track", 0.8))}
	return {"node": root, "wheels": wheels_out, "spec": spec, "tail": tails[0] if tails.size() > 0 else _m["tail"], "tails": tails,
		"head": heads[0] if heads.size() > 0 else _m["head"], "heads": heads}


static func _merged_aabb(n: Node, stop: Node) -> AABB:
	var out := AABB()
	var first := true
	var list: Array = n.find_children("*", "MeshInstance3D", true, false)
	if n is MeshInstance3D:
		list.append(n)
	for c in list:
		var mi := c as MeshInstance3D
		var xf := Transform3D((stop as Node3D).basis, Vector3.ZERO) * _chain_xf(mi, stop)
		var bb := xf * mi.mesh.get_aabb()
		if first:
			out = bb
			first = false
		else:
			out = out.merge(bb)
	return out


## Draw-call optimisation: all meshes that stay rigid with the body (everything except wheels and the steering
## wheel) are merged into one mesh with one surface per material.
static func _merge_static(inst: Node3D) -> void:
	var groups: Dictionary = {}
	var order: Array = []
	var olds: Array = []
	for c in inst.find_children("*", "MeshInstance3D", true, false):
		var mi := c as MeshInstance3D
		if not mi.visible or mi.mesh == null:
			continue
		var xf := _chain_xf(mi, inst)
		for sidx in mi.mesh.get_surface_count():
			var mat: Material = mi.get_surface_override_material(sidx)
			if mat == null:
				mat = mi.mesh.surface_get_material(sidx)
			var key := mat.get_instance_id() if mat else 0
			if not groups.has(key):
				groups[key] = {"mat": mat, "items": []}
				order.append(key)
			(groups[key]["items"] as Array).append([mi.mesh, sidx, xf])
		olds.append(mi)
	if olds.size() < 4:
		return
	var am := ArrayMesh.new()
	for key in order:
		var g: Dictionary = groups[key]
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		for it in g["items"]:
			st.append_from(it[0], it[1], it[2])
		st.set_material(g["mat"])
		st.commit(am)
	for mi in olds:
		(mi as Node).get_parent().remove_child(mi)
		(mi as Node).queue_free()
	var merged := MeshInstance3D.new()
	merged.mesh = am
	merged.name = "BodyMerged"
	inst.add_child(merged)


static func _starts_any(s: String, list: Array) -> bool:
	for x in list:
		if s.begins_with(String(x).to_lower()):
			return true
	return false


## For models where the wheels are baked into the body mesh: cut every triangle that uses a wheel material out of its
## mesh and regroup them into four independent wheel nodes (by quadrant around the axle midpoint).
static func _split_wheels(inst: Node3D, holder: Node3D, mats: Array) -> Array:
	var srcs: Array = []
	for c in inst.find_children("*", "MeshInstance3D", true, false):
		var mi := c as MeshInstance3D
		var xf := _chain_xf(mi, inst)
		for sidx in mi.mesh.get_surface_count():
			var m := mi.mesh.surface_get_material(sidx)
			if m and mats.has(m.resource_name):
				srcs.append([mi, sidx, xf, m])
	if srcs.is_empty():
		return []
	# pass A: the tyre material (first in the list) defines the four wheel centres and the radius
	var tsum := Vector3.ZERO
	var tcnt := 0
	for src in srcs:
		if (src[3] as Material).resource_name != String(mats[0]):
			continue
		for v in (src[0].mesh.surface_get_arrays(src[1])[Mesh.ARRAY_VERTEX] as PackedVector3Array):
			tsum += holder.basis * ((src[2] as Transform3D) * v)
			tcnt += 1
	if tcnt == 0:
		return []
	var mid := tsum / float(tcnt)
	var tb: Array = [AABB(), AABB(), AABB(), AABB()]
	var tf: Array = [true, true, true, true]
	for src in srcs:
		if (src[3] as Material).resource_name != String(mats[0]):
			continue
		for v in (src[0].mesh.surface_get_arrays(src[1])[Mesh.ARRAY_VERTEX] as PackedVector3Array):
			var h: Vector3 = holder.basis * ((src[2] as Transform3D) * v)
			var q := (0 if h.z > mid.z else 2) + (0 if h.x < mid.x else 1)
			if tf[q]:
				tb[q] = AABB(h, Vector3.ZERO)
				tf[q] = false
			else:
				tb[q] = (tb[q] as AABB).expand(h)
	# pass B: every triangle of every wheel material that lies inside a wheel's envelope belongs to that wheel
	var buckets: Array = [{}, {}, {}, {}]
	var rest: Dictionary = {}
	for src in srcs:
		var mi: MeshInstance3D = src[0]
		var xf: Transform3D = src[2]
		var key: Material = src[3]
		var arrs := mi.mesh.surface_get_arrays(src[1])
		var vs: PackedVector3Array = arrs[Mesh.ARRAY_VERTEX]
		var ns: PackedVector3Array = arrs[Mesh.ARRAY_NORMAL] if arrs[Mesh.ARRAY_NORMAL] != null else PackedVector3Array()
		var uvs: PackedVector2Array = arrs[Mesh.ARRAY_TEX_UV] if arrs[Mesh.ARRAY_TEX_UV] != null else PackedVector2Array()
		var idx: PackedInt32Array = arrs[Mesh.ARRAY_INDEX] if arrs[Mesh.ARRAY_INDEX] != null else PackedInt32Array()
		if idx.is_empty():
			for i in vs.size():
				idx.append(i)
		var nb := xf.basis.inverse().transposed()
		for t in range(0, idx.size() - 2, 3):
			var cen: Vector3 = holder.basis * (xf * ((vs[idx[t]] + vs[idx[t + 1]] + vs[idx[t + 2]]) / 3.0))
			var q := (0 if cen.z > mid.z else 2) + (0 if cen.x < mid.x else 1)
			var box: AABB = tb[q]
			var cc := box.get_center()
			var rad := maxf(box.size.y, box.size.z) * 0.5
			var inside := Vector2(cen.y - cc.y, cen.z - cc.z).length() <= rad * 1.06 and absf(cen.x - cc.x) <= box.size.x * 0.5 + 0.1
			var target: Dictionary
			if inside:
				target = buckets[q]
			else:
				target = rest
			if not target.has(key):
				target[key] = {"v": PackedVector3Array(), "n": PackedVector3Array(), "uv": PackedVector2Array()}
			var bk: Dictionary = target[key]
			var av: PackedVector3Array = bk["v"]
			var an: PackedVector3Array = bk["n"]
			var au: PackedVector2Array = bk["uv"]
			for k in 3:
				var vi: int = idx[t + k]
				av.append(xf * vs[vi])
				an.append((nb * ns[vi]).normalized() if ns.size() > vi else Vector3.UP)
				au.append(uvs[vi] if uvs.size() > vi else Vector2.ZERO)
			bk["v"] = av
			bk["n"] = an
			bk["uv"] = au
	var out: Array = []
	for q in 4:
		var bb := AABB()
		var first := true
		for key in buckets[q]:
			for v in (buckets[q][key]["v"] as PackedVector3Array):
				if first:
					bb = AABB(v, Vector3.ZERO)
					first = false
				else:
					bb = bb.expand(v)
		var cont := Node3D.new()
		cont.name = "SplitWheel%d" % q
		cont.position = bb.get_center()
		inst.add_child(cont)
		_emit_surfaces(cont, buckets[q], bb.get_center())
		out.append(cont)
	if not rest.is_empty():
		var rn := Node3D.new()
		rn.name = "WheelRest"
		inst.add_child(rn)
		_emit_surfaces(rn, rest, Vector3.ZERO)
	# strip the wheel surfaces out of the original meshes
	var done: Dictionary = {}
	for src in srcs:
		var mi: MeshInstance3D = src[0]
		if done.has(mi):
			continue
		done[mi] = true
		var nm := ArrayMesh.new()
		for sidx in mi.mesh.get_surface_count():
			var m := mi.mesh.surface_get_material(sidx)
			if m and mats.has(m.resource_name):
				continue
			nm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, mi.mesh.surface_get_arrays(sidx))
			nm.surface_set_material(nm.get_surface_count() - 1, m)
		mi.mesh = nm
	return out


static func _emit_surfaces(parent: Node3D, bks: Dictionary, origin: Vector3) -> void:
	for key in bks:
		var bk: Dictionary = bks[key]
		var vv: PackedVector3Array = bk["v"]
		if vv.is_empty():
			continue
		var nn: PackedVector3Array = bk["n"]
		var uu: PackedVector2Array = bk["uv"]
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		st.set_material(key)
		for i in vv.size():
			st.set_normal(nn[i])
			st.set_uv(uu[i])
			st.add_vertex(vv[i] - origin)
		var mi2 := MeshInstance3D.new()
		mi2.mesh = st.commit()
		parent.add_child(mi2)
