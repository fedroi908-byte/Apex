class_name Atmosphere
extends Node3D
## Sun/moon path, sky, fog, tone mapping, weather, rain and lightning.
## The sun follows a real solar path for the configured latitude so shadows swing across the map
## through the day; sunrise/sunset tint the sky, fog and light colour.

signal night_changed(is_night: bool)

const LATITUDE := 36.0
const DECLINATION := 12.0           # degrees (summer-ish: long evenings)

var time_of_day := 17.5             # hours 0..24
var day_length_minutes := 48.0      # real minutes per in-game day (same pace as GTA V: 2 s = 1 game minute)
var paused := false

var weather_target := 0.0           # 0 clear .. 1 stormy
var weather := 0.0                  # smoothed
var rain := 0.0
var lightning_t := 0.0
var next_flash := 6.0

var env: Environment
var sky_mat: ShaderMaterial
var sun: DirectionalLight3D
var moon: DirectionalLight3D
var rain_fx: GPUParticles3D
var cam_ref: Node3D
var sun_dir := Vector3(0.3, 0.8, 0.3)
var elevation := 0.5
var was_night := false
var _t_s := 0.0
var _acc := 0.0
var wet_cur := 0.0


func _ready() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = load("res://shaders/sky.gdshader")
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_64
	sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_EXPONENTIAL
	env.fog_sky_affect = 0.25
	env.adjustment_enabled = true
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.shadow_normal_bias = 1.2
	sun.shadow_bias = 0.06
	sun.directional_shadow_fade_start = 0.8
	sun.light_angular_distance = 0.5
	add_child(sun)
	moon = DirectionalLight3D.new()
	moon.light_color = Color(0.55, 0.68, 1.0)
	moon.shadow_enabled = false
	add_child(moon)

	rain_fx = GPUParticles3D.new()
	rain_fx.emitting = false
	rain_fx.local_coords = false
	rain_fx.lifetime = 0.8
	rain_fx.visibility_aabb = AABB(Vector3(-40, -30, -40), Vector3(80, 60, 80))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(28, 0.5, 28)
	pm.direction = Vector3(0.12, -1, 0.04)
	pm.spread = 3.0
	pm.initial_velocity_min = 38.0
	pm.initial_velocity_max = 46.0
	pm.gravity = Vector3(0, -12, 0)
	rain_fx.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(0.018, 0.55)
	var rmat := StandardMaterial3D.new()
	rmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.albedo_color = Color(0.75, 0.82, 0.95, 0.35)
	rmat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	rmat.billboard_keep_scale = true
	qm.material = rmat
	rain_fx.draw_pass_1 = qm
	add_child(rain_fx)
	apply_quality()
	_update(0.0, true)


func apply_quality() -> void:
	var c := Q.cfg()
	env.glow_enabled = c["glow"]
	env.glow_intensity = 0.7
	env.glow_bloom = 0.04
	env.glow_hdr_threshold = 1.05
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	sun.directional_shadow_max_distance = c["shadow_dist"]
	match int(c["shadow_splits"]):
		1: sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
		2: sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		_: sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_split_1 = 0.08
	sun.directional_shadow_split_2 = 0.24
	sun.directional_shadow_split_3 = 0.55
	sun.light_angular_distance = 0.15 + 0.6 * float(c["shadow_blur"]) * 0.5
	rain_fx.amount = int(c["rain_particles"])
	RenderingServer.global_shader_parameter_set("quality", float(G.quality))


func set_time(h: float) -> void:
	time_of_day = fposmod(h, 24.0)
	_update(0.0, true)


func set_weather(w: float) -> void:
	weather_target = clampf(w, 0.0, 1.0)


func _process(dt: float) -> void:
	_t_s += dt
	if not paused:
		time_of_day = fposmod(time_of_day + dt * 24.0 / (day_length_minutes * 60.0), 24.0)
	weather = move_toward(weather, weather_target, dt * 0.05)
	sky_mat.set_shader_parameter("time_s", _t_s)
	_acc += dt
	if _acc >= 0.25:
		_update(_acc, false)         # lights/sky/fog drift slowly: 4 Hz is plenty and saves a lot of CPU/GPU
		_acc = 0.0
	if cam_ref and is_instance_valid(cam_ref):
		rain_fx.global_position = cam_ref.global_position + Vector3(0, 14, 0)


func solar_vector(hours: float) -> Vector3:
	var H := deg_to_rad((hours - 12.0) * 15.0)
	var lat := deg_to_rad(LATITUDE)
	var dec := deg_to_rad(DECLINATION)
	var el := asin(sin(lat) * sin(dec) + cos(lat) * cos(dec) * cos(H))
	var east := -cos(dec) * sin(H)
	var north := sin(dec) * cos(lat) - cos(dec) * sin(lat) * cos(H)
	var horiz := Vector3(east, 0.0, -north).normalized()
	return (horiz * cos(el) + Vector3(0, sin(el), 0)).normalized()


func _update(dt: float, force: bool) -> void:
	sun_dir = solar_vector(time_of_day)
	var e := sun_dir.y
	elevation = e
	var day := smoothstep(-0.08, 0.22, e)
	var night := smoothstep(-0.05, -0.32, e)
	var twilight := clampf(1.0 - absf(e + 0.02) * 3.0, 0.0, 1.0)
	var overcast := weather
	# --- sky colours (keyframed on elevation)
	var zen_night := Color(0.008, 0.013, 0.04)
	var zen_twi := Color(0.14, 0.17, 0.36)
	var zen_day := Color(0.15, 0.34, 0.76)
	var hor_night := Color(0.025, 0.035, 0.08)
	var hor_twi := Color(0.98, 0.50, 0.26)
	var hor_day := Color(0.68, 0.80, 0.95)
	var zenith := zen_night.lerp(zen_twi, smoothstep(-0.34, -0.06, e)).lerp(zen_day, smoothstep(0.0, 0.38, e))
	var horizon := hor_night.lerp(hor_twi, smoothstep(-0.3, -0.03, e)).lerp(hor_day, smoothstep(0.04, 0.45, e))
	var grey := Color(0.46, 0.50, 0.56) * (0.25 + 0.75 * day)
	zenith = zenith.lerp(grey * 0.8, overcast * 0.8)
	horizon = horizon.lerp(grey, overcast * 0.85)
	var sun_c := Color(1.0, 0.42, 0.14).lerp(Color(1.0, 0.82, 0.60), smoothstep(0.0, 0.22, e)).lerp(Color(1.0, 0.96, 0.9), smoothstep(0.25, 0.7, e))
	sky_mat.set_shader_parameter("zenith_col", Vector3(zenith.r, zenith.g, zenith.b))
	sky_mat.set_shader_parameter("horizon_col", Vector3(horizon.r, horizon.g, horizon.b))
	var gc := horizon * 0.3
	sky_mat.set_shader_parameter("ground_col", Vector3(gc.r, gc.g, gc.b))
	sky_mat.set_shader_parameter("sun_col", Vector3(sun_c.r, sun_c.g, sun_c.b))
	sky_mat.set_shader_parameter("cloud_cover", lerpf(0.30, 0.95, overcast))
	sky_mat.set_shader_parameter("cloud_dark", overcast)
	sky_mat.set_shader_parameter("time_s", _t_s)

	# --- lights
	var sun_energy := smoothstep(-0.03, 0.22, e) * 1.35 * (1.0 - 0.72 * overcast)
	sun.light_color = sun_c
	sun.light_energy = sun_energy
	sun.visible = sun_energy > 0.01
	sun.global_transform = Transform3D(Basis.looking_at(-sun_dir, Vector3.RIGHT if absf(sun_dir.y) > 0.98 else Vector3.UP), Vector3.ZERO)
	var md := Vector3(-sun_dir.x, absf(sun_dir.y) * 0.8 + 0.25, -sun_dir.z * 0.6 + 0.3).normalized()
	moon.global_transform = Transform3D(Basis.looking_at(-md, Vector3.UP), Vector3.ZERO)
	moon.light_energy = 0.16 * night * (1.0 - 0.6 * overcast)
	moon.visible = moon.light_energy > 0.005

	# --- ambient / fog / exposure
	var amb := Color(0.55, 0.65, 0.85).lerp(Color(0.5, 0.58, 0.8), night)
	env.ambient_light_color = amb
	env.ambient_light_sky_contribution = 1.0
	env.ambient_light_energy = lerpf(0.22, 0.95, day) * lerpf(1.0, 0.8, overcast) + 0.05 * night
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	var fog_col := horizon.lerp(sun_c, twilight * 0.18)
	env.fog_light_color = fog_col
	env.fog_density = lerpf(0.00011, 0.00055, overcast) + 0.00006 * twilight + 0.0003 * minf(rain, 1.0)
	env.fog_sun_scatter = clampf(0.25 + twilight * 0.55, 0.0, 1.0)
	env.tonemap_exposure = lerpf(1.0, 1.45, night) * lerpf(1.0, 1.1, overcast)
	env.tonemap_white = 6.0
	env.adjustment_contrast = lerpf(1.06, 1.0, overcast)
	env.adjustment_saturation = lerpf(1.12, 0.78, overcast) * lerpf(1.0, 0.85, night)

	# --- globals consumed by shaders
	RenderingServer.global_shader_parameter_set("sun_dir", sun_dir)
	RenderingServer.global_shader_parameter_set("night", night)
	RenderingServer.global_shader_parameter_set("tod", time_of_day)
	rain = move_toward(rain, 1.0 if weather > 0.6 else 0.0, dt * 0.15) if not force else (1.0 if weather > 0.6 else 0.0)
	var wet_target := clampf(weather * 1.3, 0.0, 1.0) if weather > 0.35 else 0.0
	wet_cur = move_toward(wet_cur, wet_target, dt * 0.05) if not force else wet_target
	RenderingServer.global_shader_parameter_set("wetness", wet_cur)
	rain_fx.emitting = rain > 0.05
	rain_fx.amount_ratio = clampf(rain, 0.05, 1.0)

	var is_n := night > 0.5
	if is_n != was_night:
		was_night = is_n
		night_changed.emit(is_n)

	# --- lightning
	if weather > 0.8:
		next_flash -= dt
		if next_flash <= 0.0:
			lightning_t = 0.28
			next_flash = randf_range(4.0, 14.0)
	if lightning_t > 0.0:
		lightning_t -= dt
		var f := clampf(lightning_t / 0.28, 0.0, 1.0)
		var flick := 0.6 + 0.4 * sin(lightning_t * 90.0)
		env.ambient_light_energy += 2.2 * f * flick
		env.tonemap_exposure += 0.5 * f * flick
