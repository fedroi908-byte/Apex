class_name CarStrip
extends Control
## Swipeable horizontal car carousel for the garage (touch via emulated mouse, mouse drag, wheel). Cards are drawn directly
## (no child nodes), so 100+ cars cost nothing; a tap selects, a drag scrolls with inertia and never selects by accident.

signal picked(idx: int)

const GAP := 14.0
var card_w := 292.0
var cards: Array = []          # [{idx, name, cls, price, owned, color}]
var selected := -1
var _scroll := 0.0
var _vel := 0.0
var _down := false
var _moved := false
var _px := 0.0
var _lx := 0.0
var _lt := 0
var _font: Font
var _laid_out := false


func _ready() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	_font = ThemeDB.fallback_font
	resized.connect(_on_resized)


func _on_resized() -> void:
	if size.x > 0.0 and not _laid_out:
		_laid_out = true
		scroll_to_selected(false)             # the first layout pass happens after set_cards(): re-centre on the selected card
	queue_redraw()


func set_cards(list: Array, sel: int) -> void:
	cards = list
	selected = sel
	scroll_to_selected(false)
	queue_redraw()


func set_selected(idx: int) -> void:
	selected = idx
	scroll_to_selected(true)
	queue_redraw()


func _max_scroll() -> float:
	return maxf(0.0, cards.size() * (card_w + GAP) - GAP - size.x)


func scroll_to_selected(animate: bool) -> void:
	for i in cards.size():
		if int(cards[i]["idx"]) == selected:
			var target := clampf(i * (card_w + GAP) - (size.x - card_w) * 0.5, 0.0, _max_scroll())
			if animate and is_inside_tree():
				var t := create_tween()
				t.tween_method(func(v: float):
					_scroll = v
					queue_redraw(), _scroll, target, 0.28).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
			else:
				_scroll = target
			return


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton:
		var mb := e as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_down = true
				_moved = false
				_px = mb.position.x
				_lx = mb.position.x
				_lt = Time.get_ticks_msec()
				_vel = 0.0
			else:
				if _down and not _moved:
					_tap(mb.position)
				_down = false
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_scroll = clampf(_scroll + 160.0, 0.0, _max_scroll())
			queue_redraw()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_scroll = clampf(_scroll - 160.0, 0.0, _max_scroll())
			queue_redraw()
	elif e is InputEventMouseMotion and _down:
		var mm := e as InputEventMouseMotion
		if not _moved and absf(mm.position.x - _px) > 18.0:
			_moved = true
		if _moved:
			var now := Time.get_ticks_msec()
			var dt := maxf(0.001, float(now - _lt) / 1000.0)
			var dx := mm.position.x - _lx
			_scroll = clampf(_scroll - dx, -50.0, _max_scroll() + 50.0)
			_vel = lerpf(_vel, -dx / dt, 0.4)
			_lt = now
			queue_redraw()
		_lx = mm.position.x


func _tap(p: Vector2) -> void:
	var i := int(floor((p.x + _scroll) / (card_w + GAP)))
	if i < 0 or i >= cards.size():
		return
	if fmod(p.x + _scroll, card_w + GAP) > card_w:
		return                                   # tapped the gap between two cards
	G.ui("ui_click")
	picked.emit(int(cards[i]["idx"]))


func _process(dt: float) -> void:
	if _down:
		return
	var ms := _max_scroll()
	var changed := false
	if _scroll < 0.0 or _scroll > ms:                         # rubber-band back inside
		_scroll = lerpf(_scroll, clampf(_scroll, 0.0, ms), minf(1.0, dt * 14.0))
		_vel = 0.0
		changed = true
	elif absf(_vel) > 10.0:
		_scroll = clampf(_scroll + _vel * dt, 0.0, ms)
		_vel *= pow(0.004, dt)
		changed = true
	if changed:
		queue_redraw()


func _draw() -> void:
	var h := size.y
	var first := maxi(0, int(floor(_scroll / (card_w + GAP))))
	for i in range(first, cards.size()):
		var x := i * (card_w + GAP) - _scroll
		if x > size.x:
			break
		var c: Dictionary = cards[i]
		var sel: bool = int(c["idx"]) == selected
		var owned: bool = c["owned"]
		var rect := Rect2(x, 0, card_w, h)
		var sb := Ui.box(Color(0.10, 0.17, 0.26, 0.95) if sel else Color(0.05, 0.08, 0.13, 0.86), 12,
			Ui.ACCENT if sel else Color(1, 1, 1, 0.14), 3 if sel else 1)
		draw_style_box(sb, rect)
		var col: Color = c["color"]
		draw_circle(Vector2(x + card_w - 30, 32), 13.0, col)
		draw_arc(Vector2(x + card_w - 30, 32), 13.0, 0.0, TAU, 24, Color(1, 1, 1, 0.5), 2.0, true)
		var nm := String(c["name"])
		var maxw := card_w - 78.0
		while nm.length() > 6 and _font.get_string_size(nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 21).x > maxw:
			nm = nm.substr(0, nm.length() - 2)
		if nm != String(c["name"]):
			nm += "."
		draw_string(_font, Vector2(x + 18, 38), nm, HORIZONTAL_ALIGNMENT_LEFT, -1, 21, Color.WHITE)
		draw_string(_font, Vector2(x + 18, 70), String(c["cls"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Ui.DIM)
		var tag := "OWNED" if owned else "$ %s" % String(c["price_s"])
		var tcol := Ui.GOOD if owned else (Ui.GOLD if bool(c.get("can_buy", false)) else Color(1.0, 0.5, 0.4))
		draw_string(_font, Vector2(x + 18, h - 22), tag, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, tcol)
