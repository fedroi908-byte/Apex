extends SceneTree
func _initialize() -> void:
	var path := "res://assets/cars/porsche911.glb"
	for a in OS.get_cmdline_user_args():
		path = a
	var n: Node3D = (load(path) as PackedScene).instantiate()
	var h := Node3D.new()
	h.add_child(n)
	var bb := CarBuilder._merged_aabb(n, h)
	print("AABB ", bb.position, " ", bb.size)
	for nm in ["tires", "rim_black", "Discs"]:
		for c in n.find_children("*", "MeshInstance3D", true, false):
			var mi := c as MeshInstance3D
			for s in mi.mesh.get_surface_count():
				var m := mi.mesh.surface_get_material(s)
				if m and m.resource_name == nm:
					var xf := CarBuilder._chain_xf(mi, h)
					print(nm, " ", xf * mi.mesh.surface_get_arrays(s)[Mesh.ARRAY_VERTEX][0], " aabb ", xf * mi.mesh.get_aabb())
	quit()
