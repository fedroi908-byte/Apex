class_name BuildingBuilder
extends Node3D
## Streams merged building meshes per 400 m cell. Every building is assembled from a handful of
## prisms (walls with metre-accurate UVs for the facade shader) plus roofs, props and lights.
## Shape codes come from tools/worldgen/city.py.

const CELL := 400.0
const STRIDE := 12
const SH_BOX := 0
const SH_PODIUM := 1
const SH_STEPPED := 2
const SH_L := 3
const SH_U := 4
const SH_TWIN := 5
const SH_CYL := 6
const SH_SLANT := 7
const SH_GABLE := 8
const SH_HIP := 9
const SH_MODERN := 10
const SH_WAREHOUSE := 11
const SH_RETAIL := 12
const SH_BALCONY := 13
const SH_MALL := 20
const SH_HOSPITAL := 21
const SH_CAMPUS := 22
const SH_HOTEL := 23
const SH_SCHOOL := 24
const SH_PARKING := 25
const SH_OFFICEPARK := 26

var mat: ShaderMaterial
var cells := {}                     # Vector2i -> PackedInt32Array (building indices)
var live := {}                      # Vector2i -> Node3D
var collide := true
var radius := 1100.0

# --- per-building state
var _pos := Vector2.ZERO
var _basis := Basis.IDENTITY
var _base := 0.0
var _style := 0
var _rnd := 0.0
var _fh := 3.2
var _rng := RandomNumberGenerator.new()
var _m: MeshUtil
var _boxes: Array = []


func _ready() -> void:
	mat = ShaderMaterial.new()
	mat.shader = load("res://shaders/building.gdshader")
	mat.set_shader_parameter("concrete_a", load("res://assets/textures/concrete_albedo.png"))
	mat.set_shader_parameter("asph_a", load("res://assets/textures/asphalt_albedo.png"))
	mat.set_shader_parameter("grass_a", load("res://assets/textures/grass_albedo.png"))
	var d := W.buildings
	for i in range(d.size() / STRIDE):
		var k := Vector2i(int(floor(d[i * STRIDE] / CELL)), int(floor(d[i * STRIDE + 1] / CELL)))
		if not cells.has(k):
			cells[k] = PackedInt32Array()
		var arr: PackedInt32Array = cells[k]
		arr.append(i)
		cells[k] = arr


func update_focus(p: Vector3) -> void:
	var rc := int(ceil(radius / CELL))
	var c := Vector2i(int(floor(p.x / CELL)), int(floor(p.z / CELL)))
	for k in live.keys():
		if absi(k.x - c.x) > rc + 1 or absi(k.y - c.y) > rc + 1:
			live[k].queue_free()
			live.erase(k)
	for dx in range(-rc, rc + 1):
		for dz in range(-rc, rc + 1):
			var k := Vector2i(c.x + dx, c.y + dz)
			if cells.has(k) and not live.has(k):
				var cc := Vector2((k.x + 0.5) * CELL - p.x, (k.y + 0.5) * CELL - p.z)
				if cc.length() < radius + CELL:
					_build_cell(k)
					return          # one cell per call keeps frames smooth


func build_all_near(p: Vector3, r: float) -> void:
	radius = r
	for k in cells.keys():
		var cc := Vector2((k.x + 0.5) * CELL - p.x, (k.y + 0.5) * CELL - p.z)
		if cc.length() < r + CELL and not live.has(k):
			_build_cell(k)


func _build_cell(k: Vector2i) -> void:
	var m := MeshUtil.new()
	m.with_uv2 = true
	_m = m
	_boxes = []
	for bi in cells[k]:
		_building(bi)
	var root := Node3D.new()
	add_child(root)
	live[k] = root
	if m.vertex_count() == 0:
		return
	var mi := MeshInstance3D.new()
	mi.mesh = m.build(mat)
	mi.visibility_range_end = Q.get_v("bld_dist") + 200.0
	mi.visibility_range_end_margin = 120.0
	mi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	root.add_child(mi)
	if collide and not _boxes.is_empty():
		var body := StaticBody3D.new()
		body.collision_layer = 1
		root.add_child(body)
		for bx in _boxes:
			var cs := CollisionShape3D.new()
			var sh := BoxShape3D.new()
			sh.size = bx[1]
			cs.shape = sh
			cs.transform = Transform3D(Basis(Vector3.UP, bx[2]), bx[0])
			body.add_child(cs)


# ------------------------------------------------------------------ helpers
func _w(l: Vector2, y: float) -> Vector3:
	var v := _basis * Vector3(l.x, 0.0, l.y)
	return Vector3(_pos.x + v.x, _base + y, _pos.y + v.z)


func _rect(cx: float, cz: float, sx: float, sz: float) -> Array:
	var hx := sx * 0.5
	var hz := sz * 0.5
	return [Vector2(cx - hx, cz - hz), Vector2(cx + hx, cz - hz), Vector2(cx + hx, cz + hz), Vector2(cx - hx, cz + hz)]


func _ngon(cx: float, cz: float, r: float, n: int) -> Array:
	var out := []
	for i in n:
		var a := TAU * float(i) / float(n)
		out.append(Vector2(cx + cos(a) * r, cz + sin(a) * r))
	return out


func _col(surf: int, style: int = -1, fh: float = -1.0) -> Color:
	var s := _style if style < 0 else style
	var f := _fh if fh < 0.0 else fh
	return Color(float(s) / 32.0, float(surf) / 10.0, f / 8.0, _rnd)


func _centroid(poly: Array) -> Vector2:
	var c := Vector2.ZERO
	for p in poly:
		c += p
	return c / float(poly.size())


## Vertical walls round a convex footprint. `tops` has one height per corner (or a single float for all).
func _walls(poly: Array, y0: float, tops: Array, surf: int, bay: float, fill: float, style: int = -1, fh: float = -1.0) -> void:
	var cen := _centroid(poly)
	var col := _col(surf, style, fh)
	var n := poly.size()
	var u := 0.0
	for i in n:
		var p0: Vector2 = poly[i]
		var p1: Vector2 = poly[(i + 1) % n]
		var e := p1 - p0
		var len := e.length()
		if len < 0.05:
			continue
		var nl := Vector2(e.y, -e.x).normalized()
		if nl.dot((p0 + p1) * 0.5 - cen) < 0.0:
			nl = -nl
		var nw := _basis * Vector3(nl.x, 0.0, nl.y)
		var t0: float = tops[i % tops.size()]
		var t1: float = tops[(i + 1) % tops.size()]
		var uv2 := Vector2(bay / 8.0, fill)
		var a := _m.add_vertex(_w(p0, y0), nw, Vector2(u, y0), col, uv2)
		var b := _m.add_vertex(_w(p1, y0), nw, Vector2(u + len, y0), col, uv2)
		var c := _m.add_vertex(_w(p1, t1), nw, Vector2(u + len, t1), col, uv2)
		var d := _m.add_vertex(_w(p0, t0), nw, Vector2(u, t0), col, uv2)
		_m.quad_auto(a, b, c, d, nw)
		u += len + 1.7


## Convex cap whose corner heights may differ (slanted roofs).
func _cap(poly: Array, tops: Array, surf: int, style: int = -1) -> void:
	var col := _col(surf, style)
	var cen := _centroid(poly)
	var hsum := 0.0
	for t in tops:
		hsum += t
	var cy := hsum / float(tops.size())
	var n := poly.size()
	var nrm := Vector3.UP
	if n >= 3:
		var a := _w(poly[0], tops[0 % tops.size()])
		var b := _w(poly[1], tops[1 % tops.size()])
		var c := _w(poly[2], tops[2 % tops.size()])
		nrm = (b - a).cross(c - a).normalized()
		if nrm.y < 0.0:
			nrm = -nrm
	var ci := _m.add_vertex(_w(cen, cy), nrm, Vector2(_w(cen, cy).x, _w(cen, cy).z), col, Vector2(1, 0))
	var ids := []
	for i in n:
		var w := _w(poly[i], tops[i % tops.size()])
		ids.append(_m.add_vertex(w, nrm, Vector2(w.x, w.z), col, Vector2(1, 0)))
	for i in n:
		_m.tri_auto(ci, ids[i], ids[(i + 1) % n], nrm)


func _prism(poly: Array, y0: float, tops: Array, surf: int, bay: float, fill: float, roof_surf: int = 1, style: int = -1, fh: float = -1.0) -> void:
	_walls(poly, y0, tops, surf, bay, fill, style, fh)
	if roof_surf >= 0:
		_cap(poly, tops, roof_surf)


func _slab(cx: float, cz: float, sx: float, sz: float, y0: float, y1: float, surf: int, props: bool = true, style: int = -1, fh: float = -1.0, bay: float = -1.0) -> void:
	var b := bay if bay > 0.0 else _bay_for(surf)
	_prism(_rect(cx, cz, sx, sz), y0, [y1], surf, b, 0.0, 1, style, fh)
	if props and y1 > 3.0:
		_roof_props(cx, cz, sx, sz, y1)


func _bay_for(surf: int) -> float:
	if surf == 9:
		return 2.0
	return lerpf(3.0, 4.6, fposmod(_rnd * 7.0, 1.0))


func _roof_props(cx: float, cz: float, sx: float, sz: float, y: float) -> void:
	if minf(sx, sz) < 6.0:
		return
	var rr := _rng
	# parapet
	var pt := 0.7
	_slab(cx, cz - sz * 0.5 + 0.15, sx, 0.3, y, y + pt, 3, false, 16, 3.0)
	_slab(cx, cz + sz * 0.5 - 0.15, sx, 0.3, y, y + pt, 3, false, 16, 3.0)
	_slab(cx - sx * 0.5 + 0.15, cz, 0.3, sz, y, y + pt, 3, false, 16, 3.0)
	_slab(cx + sx * 0.5 - 0.15, cz, 0.3, sz, y, y + pt, 3, false, 16, 3.0)
	var n := rr.randi_range(1, 4)
	for i in n:
		var px := cx + rr.randf_range(-0.35, 0.35) * sx
		var pz := cz + rr.randf_range(-0.35, 0.35) * sz
		var kind := rr.randi() % 4
		if kind == 0:
			_slab(px, pz, 2.4, 1.8, y, y + 1.3, 3, false, 26, 3.0)           # AC unit
		elif kind == 1:
			_prism(_ngon(px, pz, 1.4, 8), y, [y + 3.2], 3, 3.0, 0.0, 1, 22, 3.0)   # water tank
		elif kind == 2:
			_slab(px, pz, 3.2, 3.2, y, y + 2.6, 3, false, 28, 3.0)         # stair/machine house
		else:
			_slab(px, pz, 0.25, 0.25, y, y + rr.randf_range(4.0, 9.0), 3, false, 28, 3.0)   # antenna
	if y > 55.0:
		_slab(cx + sx * 0.3, cz + sz * 0.3, 0.7, 0.7, y + 0.7, y + 1.4, 8, false, 4, 3.0)


func _pitched(cx: float, cz: float, sx: float, sz: float, y: float, rise: float, hip: bool) -> void:
	var rs: int = [17, 20, 28, 27, 22][int(_rnd * 5.0) % 5]
	var col := _col(10, rs)
	var along_x := sx >= sz
	var hx := sx * 0.5
	var hz := sz * 0.5
	var ov := 0.5
	var ry := y + rise
	var pts: Array = []
	var rid0 := Vector2.ZERO
	var rid1 := Vector2.ZERO
	if hip:
		var inset := minf(hx, hz) * 0.9
		if along_x:
			rid0 = Vector2(cx - hx + inset, cz)
			rid1 = Vector2(cx + hx - inset, cz)
		else:
			rid0 = Vector2(cx, cz - hz + inset)
			rid1 = Vector2(cx, cz + hz - inset)
	else:
		if along_x:
			rid0 = Vector2(cx - hx - ov, cz)
			rid1 = Vector2(cx + hx + ov, cz)
		else:
			rid0 = Vector2(cx, cz - hz - ov)
			rid1 = Vector2(cx, cz + hz + ov)
	var c := [Vector2(cx - hx - ov, cz - hz - ov), Vector2(cx + hx + ov, cz - hz - ov), Vector2(cx + hx + ov, cz + hz + ov), Vector2(cx - hx - ov, cz + hz + ov)]
	var faces := []
	if hip:
		if along_x:
			faces = [[c[0], c[1], rid1, rid0], [c[3], c[2], rid1, rid0]]
			_roof_tri(c[0], c[3], rid0, y, ry, col)
			_roof_tri(c[1], c[2], rid1, y, ry, col)
		else:
			faces = [[c[0], c[3], rid1, rid0], [c[1], c[2], rid1, rid0]]
			_roof_tri(c[0], c[1], rid0, y, ry, col)
			_roof_tri(c[3], c[2], rid1, y, ry, col)
	else:
		if along_x:
			faces = [[c[0], c[1], rid1, rid0], [c[3], c[2], rid1, rid0]]
		else:
			faces = [[c[0], c[3], rid1, rid0], [c[1], c[2], rid1, rid0]]
	for f in faces:
		var a := _w(f[0], y - 0.2)
		var b := _w(f[1], y - 0.2)
		var cc := _w(f[2], ry)
		var d := _w(f[3], ry)
		var nrm := (b - a).cross(d - a).normalized()
		if nrm.y < 0.0:
			nrm = -nrm
		var ia := _m.add_vertex(a, nrm, Vector2(a.x, a.z), col, Vector2(1, 0))
		var ib := _m.add_vertex(b, nrm, Vector2(b.x, b.z), col, Vector2(1, 0))
		var ic := _m.add_vertex(cc, nrm, Vector2(cc.x, cc.z), col, Vector2(1, 0))
		var id := _m.add_vertex(d, nrm, Vector2(d.x, d.z), col, Vector2(1, 0))
		_m.quad_auto(ia, ib, ic, id, nrm)
	if not hip:
		# gable end triangles in wall colour
		var wc := _col(0)
		var ends := []
		if along_x:
			ends = [[Vector2(cx - hx, cz - hz), Vector2(cx - hx, cz + hz), Vector2(cx - hx, cz)], [Vector2(cx + hx, cz - hz), Vector2(cx + hx, cz + hz), Vector2(cx + hx, cz)]]
		else:
			ends = [[Vector2(cx - hx, cz - hz), Vector2(cx + hx, cz - hz), Vector2(cx, cz - hz)], [Vector2(cx - hx, cz + hz), Vector2(cx + hx, cz + hz), Vector2(cx, cz + hz)]]
		for e in ends:
			var a := _w(e[0], y)
			var b := _w(e[1], y)
			var t := _w(e[2], ry)
			var nrm := (b - a).cross(t - a).normalized()
			var out := Vector3(a.x - _pos.x, 0, a.z - _pos.y)
			if nrm.dot(out) < 0.0:
				nrm = -nrm
			var u := (b - a).length()
			var ia := _m.add_vertex(a, nrm, Vector2(0, y), wc, Vector2(0.5, 0.0))
			var ib := _m.add_vertex(b, nrm, Vector2(u, y), wc, Vector2(0.5, 0.0))
			var it := _m.add_vertex(t, nrm, Vector2(u * 0.5, ry), wc, Vector2(0.5, 0.0))
			_m.tri_auto(ia, ib, it, nrm)


func _roof_tri(a2: Vector2, b2: Vector2, t2: Vector2, y: float, ry: float, col: Color) -> void:
	var a := _w(a2, y - 0.2)
	var b := _w(b2, y - 0.2)
	var t := _w(t2, ry)
	var nrm := (b - a).cross(t - a).normalized()
	if nrm.y < 0.0:
		nrm = -nrm
	var ia := _m.add_vertex(a, nrm, Vector2(a.x, a.z), col, Vector2(1, 0))
	var ib := _m.add_vertex(b, nrm, Vector2(b.x, b.z), col, Vector2(1, 0))
	var it := _m.add_vertex(t, nrm, Vector2(t.x, t.z), col, Vector2(1, 0))
	_m.tri_auto(ia, ib, it, nrm)


func _ground(cx: float, cz: float, sx: float, sz: float, surf: int) -> void:
	var poly := _rect(cx, cz, sx, sz)
	var col := _col(surf, 16)
	var ids := []
	for p in poly:
		var w := _w(p, 0.12)
		ids.append(_m.add_vertex(w, Vector3.UP, Vector2(w.x, w.z), col, Vector2(1, 0)))
	_m.quad_auto(ids[0], ids[1], ids[2], ids[3], Vector3.UP)


func _sign(cx: float, cz: float, y: float, sx: float, face_z: float) -> void:
	_slab(cx, cz + face_z, sx, 0.4, y, y + 1.6, 4, false, 16, 3.0)


# ------------------------------------------------------------------ one building
func _building(bi: int) -> void:
	var d := W.buildings
	var o := bi * STRIDE
	_pos = Vector2(d[o], d[o + 1])
	_base = d[o + 2]
	var w: float = d[o + 3]
	var dd: float = d[o + 4]
	var h: float = d[o + 5]
	var rot: float = d[o + 6]
	_style = clampi(int(d[o + 7]), 0, 31)
	var kind := int(d[o + 8])
	var shape := int(d[o + 10])
	_rnd = fposmod(d[o + 11], 1.0)
	_basis = Basis(Vector3.UP, rot)
	_rng.seed = int(d[o + 11] * 100000.0) + bi
	var glass_style := _style < 6
	var tall := h > 22.0
	var fh := 4.0 if (glass_style and tall) else (3.6 if tall else 3.2)
	var floors := maxi(1, roundi(h / fh))
	fh = h / float(floors)
	_fh = fh
	var surf := 9 if (glass_style and tall) else 0
	if not glass_style and _style >= 12 and _style < 24 and _rng.randf() < 0.3:
		surf = 5
	var y0 := -3.0
	_boxes.append([Vector3(_pos.x, _base + h * 0.5, _pos.y), Vector3(w, h, dd), -rot])

	match shape:
		SH_PODIUM:
			var ph := minf(maxf(h * 0.16, 7.0), 14.0)
			_slab(0, 0, w, dd, y0, ph, 2, false, -1, 4.0)
			_cap(_rect(0, 0, w, dd), [ph], 1)
			_prism(_rect(0, 0, w * 0.72, dd * 0.72), ph - 0.2, [h], 9 if glass_style or tall else surf, 2.0, 0.0)
			_roof_props(0, 0, w * 0.72, dd * 0.72, h)
		SH_STEPPED:
			var hs := [h * 0.55, h * 0.8, h]
			var ss := [1.0, 0.76, 0.54]
			for i in 3:
				var yb: float = y0 if i == 0 else hs[i - 1] - 0.2
				_slab(0, 0, w * ss[i], dd * ss[i], yb, hs[i], surf, i == 2)
		SH_L:
			_slab(0, -dd * 0.25, w, dd * 0.5, y0, h, surf, true)
			_slab(-w * 0.25, dd * 0.25, w * 0.5, dd * 0.5, y0, h * 0.8, surf, true)
		SH_U:
			_slab(0, -dd * 0.35, w, dd * 0.3, y0, h, surf, true)
			_slab(-w * 0.4, 0.1 * dd, w * 0.2, dd * 0.7, y0, h, surf, true)
			_slab(w * 0.4, 0.1 * dd, w * 0.2, dd * 0.7, y0, h, surf, true)
			_ground(0, dd * 0.15, w * 0.58, dd * 0.5, 7)
		SH_TWIN:
			var ph := minf(h * 0.12, 9.0)
			_slab(0, 0, w, dd, y0, ph, 2, false)
			_cap(_rect(0, 0, w, dd), [ph], 1)
			_slab(-w * 0.24, 0, w * 0.38, dd * 0.6, ph - 0.2, h, 9)
			_slab(w * 0.24, 0, w * 0.38, dd * 0.6, ph - 0.2, h * 0.88, 9)
		SH_CYL:
			var r := minf(w, dd) * 0.5
			_prism(_ngon(0, 0, r, 16), y0, [h], 9, 2.2, 0.0)
			_roof_props(0, 0, r * 1.3, r * 1.3, h)
		SH_SLANT:
			_prism(_rect(0, 0, w, dd), y0, [h, h, h * 0.66, h * 0.66], surf, bay_by(surf), 0.0)
		SH_GABLE, SH_HIP:
			var eave := clampf(h, 3.0, 9.0)
			_prism(_rect(0, 0, w, dd), y0, [eave], 0, bay_by(0), 0.0, -1)
			_pitched(0, 0, w, dd, eave, minf(w, dd) * 0.3, shape == SH_HIP)
		SH_MODERN:
			var hh := clampf(h, 5.0, 10.0)
			_slab(0, 0, w * 0.7, dd * 0.7, y0, hh * 0.55, 3, false, 12, 3.0)
			_prism(_rect(w * 0.12, 0, w * 0.75, dd * 0.55), hh * 0.5, [hh], 9, 2.0, 0.0, 1, 12, 3.2)
			_roof_props(w * 0.12, 0, w * 0.75, dd * 0.55, hh)
		SH_WAREHOUSE:
			var hw := clampf(h, 7.0, 14.0)
			_prism(_rect(0, 0, w, dd), y0, [hw], 0, 6.0, 0.18, 1, 24 + (_style % 4), 4.0)
			_roof_props(0, 0, w, dd, hw)
			_slab(0, -dd * 0.5 - 0.1, minf(w * 0.4, 12.0), 0.3, 0.0, 4.5, 3, false, 28, 3.0)  # loading door
		SH_RETAIL:
			var hr := clampf(h, 4.5, 9.0)
			_prism(_rect(0, 0, w, dd), y0, [hr], 2, 4.0, 0.0)
			_roof_props(0, 0, w, dd, hr)
			_sign(0, -dd * 0.5, hr - 0.2, minf(w * 0.7, 10.0), -0.6)
		SH_BALCONY:
			_prism(_rect(0, 0, w, dd), y0, [h], 5, 3.6, 0.0)
			_roof_props(0, 0, w, dd, h)
		SH_MALL:
			_ground(0, 0, w * 1.5, dd * 1.5, 6)
			_prism(_rect(0, 0, w, dd), y0, [h], 2, 5.0, 0.0, 1, 13 + _style % 6, 5.0)
			_prism(_ngon(0, 0, minf(w, dd) * 0.22, 12), h - 0.3, [h + 6.0], 9, 2.0, 0.0, 1, 4, 3.0)
			_roof_props(-w * 0.3, 0, w * 0.3, dd * 0.6, h)
			_sign(0, -dd * 0.5, h - 4.0, w * 0.4, -0.6)
		SH_HOSPITAL:
			var wh := h * 0.45
			_slab(0, dd * 0.18, w, dd * 0.4, y0, wh, 0, true, 12, 3.6)
			_slab(-w * 0.15, -dd * 0.1, w * 0.4, dd * 0.4, y0, h, 0, true, 12, 3.6)
			_slab(w * 0.25, dd * 0.2, 12.0, 12.0, wh, wh + 0.4, 3, false, 5, 3.0)       # helipad
			_slab(0, -dd * 0.5, 14.0, 0.4, 5.0, 6.2, 4, false, 16, 3.0)
		SH_CAMPUS:
			_ground(0, 0, w * 1.3, dd * 1.3, 7)
			_slab(-w * 0.3, -dd * 0.2, w * 0.35, dd * 0.4, y0, h, 0, true, 7, 3.6)
			_slab(w * 0.3, dd * 0.1, w * 0.35, dd * 0.45, y0, h * 0.75, 0, true, 7, 3.6)
			_slab(0, dd * 0.3, w * 0.4, dd * 0.22, y0, h * 0.55, 0, true, 7, 3.6)
		SH_HOTEL:
			var ph := 8.0
			_slab(0, 0, w, dd, y0, ph, 2, false, -1, 4.0)
			_cap(_rect(0, 0, w, dd), [ph], 1)
			_slab(0, 0, w * 0.5, dd * 0.9, ph - 0.2, h, 5, true, 12 + _style % 4, fh)
			_sign(0, -dd * 0.45, h - 2.0, w * 0.4, -0.2)
		SH_SCHOOL:
			_ground(0, 0, w * 1.4, dd * 1.4, 7)
			_slab(0, -dd * 0.35, w, dd * 0.3, y0, h, 0, true, 7, 3.4)
			_slab(-w * 0.4, 0.05 * dd, w * 0.2, dd * 0.5, y0, h, 0, true, 7, 3.4)
			_slab(w * 0.4, 0.05 * dd, w * 0.2, dd * 0.5, y0, h, 0, true, 7, 3.4)
		SH_PARKING:
			var fl := maxi(2, roundi(h / 3.0))
			for i in fl:
				var yy := float(i) * 3.0
				_slab(0, 0, w, dd, yy, yy + 0.4, 3, false, 28, 3.0)
				_slab(0, -dd * 0.5 + 0.2, w, 0.4, yy + 0.4, yy + 1.2, 3, false, 28, 3.0)
				_slab(0, dd * 0.5 - 0.2, w, 0.4, yy + 0.4, yy + 1.2, 3, false, 28, 3.0)
				_slab(-w * 0.5 + 0.2, 0, 0.4, dd, yy + 0.4, yy + 1.2, 3, false, 28, 3.0)
				_slab(w * 0.5 - 0.2, 0, 0.4, dd, yy + 0.4, yy + 1.2, 3, false, 28, 3.0)
			var px := maxi(2, int(w / 9.0))
			var pz := maxi(2, int(dd / 9.0))
			for ix in px + 1:
				for iz in pz + 1:
					if ix == 0 or ix == px or iz == 0 or iz == pz:
						var cx := -w * 0.5 + 0.5 + (w - 1.0) * float(ix) / float(px)
						var cz := -dd * 0.5 + 0.5 + (dd - 1.0) * float(iz) / float(pz)
						_slab(cx, cz, 0.7, 0.7, y0, float(fl) * 3.0, 3, false, 28, 3.0)
		SH_OFFICEPARK:
			_ground(0, 0, w * 1.5, dd * 1.5, 6)
			_slab(-w * 0.22, -dd * 0.1, w * 0.4, dd * 0.4, y0, h, 9, true, _style % 6, 4.0)
			_slab(w * 0.25, dd * 0.15, w * 0.35, dd * 0.35, y0, h * 0.7, 9, true, (_style + 2) % 6, 4.0)
		_:
			_slab(0, 0, w, dd, y0, h, surf, true)
			if h < 14.0 and kind == 0:
				pass


func bay_by(surf: int) -> float:
	return _bay_for(surf)
