class_name MissionRunner
extends Node
## Runs one mission inside the open world: placement, countdown, checkpoints/score, timer, HUD, result.

signal finished(result: Dictionary)

var gw: GameWorld
var m: Dictionary
var state := "countdown"            # countdown, running, done
var t := 0.0                        # running time
var cd := 3.99
var cps: Array = []                 # Vector3 checkpoints
var cp_i := 0
var score := 0.0
var combo := 1.0
var combo_t := 0.0
var top_kmh := 0.0
var layer: CanvasLayer
var title_l: Label
var info_l: Label
var time_l: Label
var big_l: Label
var arrow: Control
var arrow_ang := 0.0
var dist_to := 0.0
var markers: Array = []
var _last_cd := 4


func setup(world: GameWorld, mission: Dictionary) -> void:
	gw = world
	m = mission
	_place()
	_build_ui()
	_build_markers()
	gw.input_locked = true


func _place() -> void:
	var pos := gw.start_pos
	var yaw := gw.start_yaw
	if m["type"] == "race":
		var pts: Array = m["pts"]
		cps = _resample(pts, 130.0)
		pos = Vector3(pts[0][0], 0.0, pts[0][1])
		yaw = atan2(cps[1].x - pos.x, cps[1].z - pos.z) if cps.size() > 1 else 0.0
	elif m["type"] == "speed" and m["start"] == "coast":
		var r: Dictionary = W.races[0]
		var pts2: Array = r["pts"]
		pos = Vector3(pts2[0][0], 0.0, pts2[0][1])
		yaw = atan2(pts2[4][0] - pts2[0][0], pts2[4][1] - pts2[0][1])
	elif m["type"] == "courier":
		cps = _courier_points(int(m["count"]), gw.start_pos)
	pos.y = W.ground_height(pos.x, pos.z, pos.y + 4.0) + 0.4
	gw.player.reset_to(pos, yaw)
	gw.cam_yaw = yaw
	gw.cam_pos = pos
	gw.hud.visible = true


func _resample(pts: Array, step: float) -> Array:
	var out: Array = []
	var acc := 0.0
	var prev := Vector3(pts[0][0], 0, pts[0][1])
	for i in range(1, pts.size()):
		var p := Vector3(pts[i][0], 0, pts[i][1])
		acc += prev.distance_to(p)
		prev = p
		if acc >= step:
			acc = 0.0
			out.append(p)
	var last := Vector3(pts[pts.size() - 1][0], 0, pts[pts.size() - 1][1])
	if out.is_empty() or (out[out.size() - 1] as Vector3).distance_to(last) > 30.0:
		out.append(last)
	else:
		out[out.size() - 1] = last
	for i in out.size():
		var q: Vector3 = out[i]
		q.y = W.ground_height(q.x, q.z, 60.0)
		out[i] = q
	return out


func _courier_points(n: int, around: Vector3) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var out: Array = []
	var cur := around
	var cnt := W.intersections.size() / 4
	var tries := 0
	while out.size() < n and tries < 4000 and cnt > 0:
		tries += 1
		var k := rng.randi() % cnt
		var p := Vector3(W.intersections[k * 4], 0, W.intersections[k * 4 + 1])
		var d := cur.distance_to(p)
		if d > 260.0 and d < 700.0:
			p.y = W.ground_height(p.x, p.z, 60.0)
			out.append(p)
			cur = p
	return out


func _build_ui() -> void:
	layer = CanvasLayer.new()
	layer.layer = 12
	add_child(layer)
	var pn := Ui.panel(Color(0.03, 0.05, 0.09, 0.78), 14)
	pn.position = Vector2(18, 90)
	layer.add_child(pn)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	pn.add_child(v)
	title_l = Ui.label(String(m["name"]), 26, Missions.TYPE_COLORS[m["type"]], true)
	v.add_child(title_l)
	info_l = Ui.label("", 20, Color.WHITE)
	v.add_child(info_l)
	time_l = Ui.label("0:00.0", 38, Color.WHITE, true)
	v.add_child(time_l)
	big_l = Ui.label("", 160, Color.WHITE, true)
	big_l.set_anchors_preset(Control.PRESET_CENTER)
	big_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_l.size = Vector2(600, 200)
	big_l.position = Vector2(-300, -260)
	big_l.add_theme_constant_override("outline_size", 14)
	layer.add_child(big_l)
	big_l.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	big_l.position.y -= 150
	arrow = Control.new()
	arrow.set_anchors_preset(Control.PRESET_CENTER_TOP)
	arrow.position = Vector2(0, 150)
	arrow.draw.connect(_draw_arrow)
	arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(arrow)


func _build_markers() -> void:
	for i in 2:
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 11.0
		cm.bottom_radius = 11.0
		cm.height = 90.0
		cm.radial_segments = 24
		cm.rings = 1
		mi.mesh = cm
		var mat := StandardMaterial3D.new()
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		mat.albedo_color = Color(0.1, 0.8, 1.0, 0.28) if i == 0 else Color(1.0, 0.7, 0.2, 0.12)
		mi.material_override = mat
		mi.visible = false
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		gw.add_child(mi)
		markers.append(mi)


func _exit_tree() -> void:
	for mk in markers:
		if is_instance_valid(mk):
			mk.queue_free()


func _target() -> Vector3:
	if m["type"] in ["race", "courier"] and cp_i < cps.size():
		return cps[cp_i]
	return Vector3.ZERO


func _process(dt: float) -> void:
	if state == "done":
		return
	var p := gw.player
	var kmh := p.kmh()
	top_kmh = maxf(top_kmh, kmh)
	if state == "countdown":
		cd -= dt
		var n := int(ceil(cd))
		if n != _last_cd:
			_last_cd = n
			if n > 0:
				big_l.text = str(n)
				G.ui("countdown", -4.0)
			else:
				big_l.text = "GO!"
				G.ui("go", -2.0)
		big_l.pivot_offset = big_l.size * 0.5
		big_l.scale = Vector2.ONE * (1.0 + fmod(cd, 1.0) * 0.4)
		if cd <= 0.0:
			state = "running"
			gw.input_locked = false
			var tw := create_tween()
			tw.tween_property(big_l, "modulate:a", 0.0, 0.8)
		_update_markers()
		return
	t += dt
	var limit: float = m["limit"]
	match String(m["type"]):
		"race":
			_run_cp(dt, true)
		"courier":
			_run_cp(dt, true)
		"speed":
			info_l.text = "TARGET %d km/h   NOW %d" % [int(m["target"]), int(kmh)]
			if kmh >= float(m["target"]):
				_finish(true, t)
		"drift":
			if p.drifting and absf(p.speed) > 8.0:
				combo_t = 2.0
				combo = minf(combo + dt * 0.5, 8.0)
				score += dt * absf(p.speed) * 2.2 * combo
			else:
				combo_t -= dt
				if combo_t <= 0.0:
					combo = 1.0
			info_l.text = "SCORE %d / %d   COMBO x%.1f" % [int(score), int(m["target"]), combo]
			if score >= float(m["target"]):
				_finish(true, score)
	time_l.text = _fmt(maxf(limit - t, 0.0)) if m["type"] != "race" else _fmt(t)
	time_l.add_theme_color_override("font_color", Color(1, 0.3, 0.25) if limit - t < 10.0 else Color.WHITE)
	if t >= limit:
		_finish(false, score if m["type"] == "drift" else t)
	_update_markers()


func _run_cp(_dt: float, _timed: bool) -> void:
	if cp_i >= cps.size():
		return
	var p := gw.player.global_position
	var tgt: Vector3 = cps[cp_i]
	dist_to = Vector2(p.x - tgt.x, p.z - tgt.z).length()
	info_l.text = "CHECKPOINT %d / %d   %d m" % [cp_i + 1, cps.size(), int(dist_to)]
	if dist_to < 20.0:
		cp_i += 1
		G.ui("checkpoint", -3.0)
		if cp_i >= cps.size():
			_finish(true, t)


func _update_markers() -> void:
	if not (m["type"] in ["race", "courier"]):
		for mk in markers:
			(mk as Node3D).visible = false
		arrow.visible = false
		return
	for k in 2:
		var idx := cp_i + k
		var mk: MeshInstance3D = markers[k]
		if idx < cps.size() and state != "done":
			var q: Vector3 = cps[idx]
			mk.global_position = q + Vector3(0, 40.0, 0)
			mk.visible = true
		else:
			mk.visible = false
	if cp_i < cps.size():
		var cam := gw.cam
		var d := (cps[cp_i] as Vector3) - cam.global_position
		var l := cam.global_transform.basis.inverse() * d
		arrow_ang = atan2(l.x, -l.z)
		arrow.visible = true
		arrow.queue_redraw()
	else:
		arrow.visible = false


func _draw_arrow() -> void:
	var a := arrow_ang
	var c := Vector2.ZERO
	var pts := PackedVector2Array([
		c + Vector2(sin(a), -cos(a)) * 40.0,
		c + Vector2(sin(a + 2.5), -cos(a + 2.5)) * 30.0,
		c + Vector2(sin(a + PI), -cos(a + PI)) * 12.0,
		c + Vector2(sin(a - 2.5), -cos(a - 2.5)) * 30.0,
	])
	arrow.draw_colored_polygon(pts, Color(0.1, 0.85, 1.0, 0.92))
	arrow.draw_polyline(pts + PackedVector2Array([pts[0]]), Color(1, 1, 1, 0.9), 2.5)


func _fmt(x: float) -> String:
	return "%d:%04.1f" % [int(x / 60.0), fmod(x, 60.0)]


func _finish(success: bool, value: float) -> void:
	if state == "done":
		return
	state = "done"
	gw.input_locked = true
	for mk in markers:
		(mk as Node3D).visible = false
	arrow.visible = false
	var stars := Missions.stars_for(m, value, success)
	var reward := Missions.reward_for(m, stars)
	var res := {"success": success, "value": value, "stars": stars, "reward": reward, "mission": m, "top": top_kmh}
	G.ui("win" if success else "crash", -2.0)
	if success:
		var prev: int = int(G.mission_stars.get(m["id"], 0))
		if stars > prev:
			G.mission_stars[m["id"]] = stars
		var best: float = float(G.mission_best.get(m["id"], 0.0))
		var better := value > best if m["type"] == "drift" else (best <= 0.0 or value < best)
		if better:
			G.mission_best[m["id"]] = value
		G.credits += reward
		if m["type"] == "race":
			G.races_won += 1
	G.save_game()
	finished.emit(res)
