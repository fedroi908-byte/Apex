class_name PauseMenu
extends CanvasLayer
## In-game pause overlay (game tree is paused while it is open).

signal resume
signal restart
signal exit_menu

var has_mission := false


func _ready() -> void:
	layer = 40
	process_mode = Node.PROCESS_MODE_ALWAYS
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.7)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(c)
	var t := Ui.label("PAUSED", 90, Color.WHITE, true)
	t.position = Vector2(100, 90)
	c.add_child(t)
	var items: Array = [["RESUME", func(): resume.emit(), Ui.ACCENT]]
	if has_mission:
		items.append(["RESTART MISSION", func(): restart.emit(), Ui.HOT])
	items.append(["SETTINGS", func(): _settings(), Ui.GOOD])
	items.append(["EXIT TO MENU", func(): exit_menu.emit(), Color(0.9, 0.3, 0.3)])
	var y := 280.0
	var i := 0
	for it in items:
		var b := Ui.button(it[0], it[1], it[2], 28, Vector2(440, 68))
		b.process_mode = Node.PROCESS_MODE_ALWAYS
		b.position = Vector2(100, y)
		c.add_child(b)
		Ui.fade_in(b, 0.07 * i)
		y += 82.0
		i += 1


func _settings() -> void:
	var s := SettingsScreen.new()
	add_child(s)
