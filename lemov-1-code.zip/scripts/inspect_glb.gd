extends SceneTree
func _initialize() -> void:
	var path := "res://assets/cars/ferrari.glb"
	for a in OS.get_cmdline_user_args():
		path = a
	var n: Node3D = (load(path) as PackedScene).instantiate()
	_tree(n, 0)
	var seen := {}
	for c in n.find_children("*", "MeshInstance3D", true, false):
		var mi := c as MeshInstance3D
		for s in mi.mesh.get_surface_count():
			var m := mi.mesh.surface_get_material(s)
			seen[m.resource_name if m else "none"] = String(mi.name)
	print("MATS ", seen)
	quit()

func _tree(n: Node, d: int) -> void:
	if d > 4:
		return
	var extra := ""
	if n is MeshInstance3D:
		extra = str((n as MeshInstance3D).mesh.get_aabb())
	print("  ".repeat(d), n.name, " ", (n as Node3D).position if n is Node3D else "", " ", extra)
	for c in n.get_children():
		_tree(c, d + 1)
