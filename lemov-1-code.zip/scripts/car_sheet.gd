extends Node3D
## QA harness: renders every car given as user arg from outside and from the driver's seat -> /tmp/sheet/<id>_ext.png, <id>_cab.png
var ids: Array = []
var i := 0
var f := 0
var cam: Camera3D
var car: Node3D
var eye := Vector3(0.36, 1.0, -0.2)

func _ready() -> void:
	ids = Array(OS.get_cmdline_user_args())
	DirAccess.make_dir_recursive_absolute("/tmp/sheet")
	var at := Atmosphere.new()
	add_child(at)
	at.paused = true
	at.set_time(14.0)
	var floor_m := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(60, 60)
	floor_m.mesh = pm
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.32, 0.32, 0.34)
	fm.roughness = 0.5
	floor_m.material_override = fm
	add_child(floor_m)
	cam = Camera3D.new()
	add_child(cam)
	_spawn()

func _spawn() -> void:
	if car != null:
		car.queue_free()
		car = null
	if i >= ids.size():
		print("SHEET_DONE")
		get_tree().quit()
		return
	var kind := String(ids[i])
	var col := Color(0.8, 0.1, 0.1)
	for c in G.cars:
		if c["id"] == kind:
			col = c["color"]
	var r := CarBuilder.build(String(kind), col, Color(0.05, 0.05, 0.06))
	car = r["node"]
	add_child(car)
	eye = car.get_meta("eye") if car.has_meta("eye") else Vector3(0.36, 1.0, -0.2)
	if car.has_meta("paints"):
		for pmat in car.get_meta("paints"):
			(pmat as ShaderMaterial).set_shader_parameter("car_to_world", Transform3D.IDENTITY)
	var sd := OS.get_environment("STEER_DEG")
	if sd != "" and car.has_meta("steer_pivot"):
		(car.get_meta("steer_pivot") as Node3D).basis = Basis(car.get_meta("steer_axis"), deg_to_rad(float(sd)))
	f = 0

func _process(_d: float) -> void:
	if car == null:
		return
	f += 1
	var kind := String(ids[i])
	if f == 1:
		cam.fov = 38
		cam.near = 0.1
		cam.position = Vector3(5.2, 1.5, 6.0)
		cam.look_at(Vector3(0, 0.7, 0))
	elif f == 5:
		get_viewport().get_texture().get_image().save_png("/tmp/sheet/%s_ext.png" % kind)
		cam.fov = 78
		cam.near = 0.03
		cam.global_transform = Transform3D(Basis(Vector3.UP, PI), eye)
	elif f == 9:
		get_viewport().get_texture().get_image().save_png("/tmp/sheet/%s_cab.png" % kind)
		i += 1
		_spawn()
