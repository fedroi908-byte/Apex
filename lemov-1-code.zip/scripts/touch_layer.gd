class_name TouchLayer
extends Control
## True multi-touch on-screen controls. Godot's Button only sees ONE finger (emulated mouse), so gas + steering at the same time
## was impossible. This layer reads raw touch events: every finger is tracked on its own, fingers can slide between pads,
## and each pad reports held/released into `state` ({key: bool}).  Pads are drawn here (cheap, no theme/layout cost).
## Keyboard / mouse still work on desktop because the project emulates touch from the mouse.

signal pad_pressed(key: String)

const PAD_DEFS := [
	# key, label, anchor ("bl" bottom-left / "br" bottom-right), centre offset from that corner (px at scale 1), radius, colour
	["left", "<", "bl", Vector2(150, 150), 84.0, Color(0.10, 0.45, 0.85)],
	["right", ">", "bl", Vector2(350, 150), 84.0, Color(0.10, 0.45, 0.85)],
	["gas", "GAS", "br", Vector2(150, 190), 100.0, Color(0.12, 0.75, 0.32)],
	["brake", "BRAKE", "br", Vector2(355, 140), 80.0, Color(0.90, 0.15, 0.15)],
	["nitro", "N2O", "br", Vector2(120, 400), 70.0, Color(0.25, 0.45, 1.0)],
	["drift", "DRIFT", "br", Vector2(300, 330), 66.0, Color(1.0, 0.65, 0.12)],
]

var state: Dictionary = {}
var scale_f := 1.0
var opacity := 0.6
var swap_sides := false                  # left-handed layout
var _pads: Array = []                    # [{key,label,c:Vector2,r:float,col:Color}]
var _fingers: Dictionary = {}            # finger index -> pad key
var _font: Font


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_font = ThemeDB.fallback_font
	for d in PAD_DEFS:
		state[d[0]] = false
	scale_f = G.touch_scale
	opacity = G.touch_opacity
	get_viewport().size_changed.connect(_layout)
	resized.connect(_layout)
	_layout()


func _layout() -> void:
	var sz := get_viewport_rect().size
	var ins := Ui.safe_insets(get_viewport())
	_pads.clear()
	for d in PAD_DEFS:
		var off: Vector2 = d[3] * scale_f
		var corner := String(d[2])
		if swap_sides:
			corner = "br" if corner == "bl" else "bl"
		var c := Vector2(ins.x + off.x, sz.y - ins.w - off.y) if corner == "bl" else Vector2(sz.x - ins.z - off.x, sz.y - ins.w - off.y)
		_pads.append({"key": d[0], "label": d[1], "c": c, "r": float(d[4]) * scale_f, "col": d[5]})
	queue_redraw()


func apply_settings() -> void:
	scale_f = G.touch_scale
	opacity = G.touch_opacity
	_layout()


func _hit(p: Vector2) -> String:
	var best := ""
	var bd := 1e9
	for pd in _pads:
		var d := p.distance_to(pd["c"] as Vector2)
		var reach: float = float(pd["r"]) * 1.25            # generous hit area: thumbs are bigger than the drawing
		if d <= reach and d < bd:
			bd = d
			best = String(pd["key"])
	return best


func _set_finger(idx: int, key: String) -> void:
	var old: String = _fingers.get(idx, "")
	if old == key:
		return
	if key == "":
		_fingers.erase(idx)
	else:
		_fingers[idx] = key
	_recount()
	if key != "" and G.haptics:
		Input.vibrate_handheld(12)
	if key != "":
		pad_pressed.emit(key)


func _recount() -> void:
	for k in state:
		state[k] = false
	for idx in _fingers:
		state[_fingers[idx]] = true
	queue_redraw()


func _input(e: InputEvent) -> void:
	if e is InputEventScreenTouch:
		var t := e as InputEventScreenTouch
		if t.pressed:
			var k := _hit(t.position)
			if k != "":
				_set_finger(t.index, k)
				get_viewport().set_input_as_handled()
		elif _fingers.has(t.index):
			_set_finger(t.index, "")
			get_viewport().set_input_as_handled()
	elif e is InputEventScreenDrag:
		var d := e as InputEventScreenDrag
		if _fingers.has(d.index):
			var k := _hit(d.position)
			_set_finger(d.index, k)                          # sliding to another pad (or off every pad) switches / releases
			get_viewport().set_input_as_handled()


func release_all() -> void:
	_fingers.clear()
	_recount()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT or what == NOTIFICATION_VISIBILITY_CHANGED:
		release_all()


func _draw() -> void:
	for pd in _pads:
		var c: Vector2 = pd["c"]
		var r: float = pd["r"]
		var col: Color = pd["col"]
		var down: bool = state.get(pd["key"], false)
		var a := opacity * (1.5 if down else 1.0)
		draw_circle(c, r, Color(col.r * 0.25, col.g * 0.25, col.b * 0.25, minf(a, 0.9) * (0.55 if not down else 0.85)))
		draw_arc(c, r - 2.0, 0.0, TAU, 48, Color(col.r, col.g, col.b, minf(a + 0.2, 1.0)), 4.0 if down else 3.0, true)
		if down:
			draw_circle(c, r * 0.86, Color(col.r, col.g, col.b, 0.32))
		var fs := int(r * (0.42 if String(pd["label"]).length() <= 1 else 0.3))
		var txt: String = pd["label"]
		var tw := _font.get_string_size(txt, HORIZONTAL_ALIGNMENT_CENTER, -1, fs).x
		draw_string(_font, c + Vector2(-tw * 0.5, fs * 0.34), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, minf(a + 0.35, 1.0)))
