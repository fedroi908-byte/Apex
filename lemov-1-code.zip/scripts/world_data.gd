extends Node
## Autoload "W": loads the generated open-world data and answers spatial queries
## (terrain height, bridge decks, nearest road, GPS route).

signal progress(frac: float, msg: String)

const DATA := "res://data/"

var loaded := false
var n := 2048
var size := 10000.0
var half := 5000.0
var px := 10000.0 / 2048.0
var hmin := 0.0
var hmax := 1.0
var hscale := 1.0

var hm_bytes: PackedByteArray
var hm_image: Image
var splat_image: Image
var splat_n := 1024

var roads: Array = []                      # {name, cls, width, pts: PackedVector3Array, bridge: PackedByteArray}
var buildings := PackedFloat32Array()      # 10 floats each: x z base w d h rot style kind roof
var trees := PackedFloat32Array()          # 5 floats each: x z y scale type
var intersections := PackedFloat32Array()  # 4 floats each: x z angle signal
var landmarks: Array = []
var water: Dictionary = {}
var races: Array = []
var parks: Array = []
var meta: Dictionary = {}

var _bridge_hash := {}                     # cell -> PackedInt32Array of indices into _bridge_pts
var _bridge_pts: Array = []                # [x, z, y, halfwidth]
var astar := AStar3D.new()
var _gps_hash := {}
const GPS_CELL := 40.0


# ------------------------------------------------------------------ loading
func _read_bytes(name: String) -> PackedByteArray:
	var f := FileAccess.open(DATA + name, FileAccess.READ)
	if f == null:
		push_error("missing data file " + name)
		return PackedByteArray()
	var b := f.get_buffer(f.get_length())
	f.close()
	return b


func _read_json(name: String) -> Variant:
	var f := FileAccess.open(DATA + name, FileAccess.READ)
	if f == null:
		push_error("missing data file " + name)
		return null
	var t := f.get_as_text()
	f.close()
	return JSON.parse_string(t)


func ensure_races() -> void:
	if races.is_empty():
		var rj: Dictionary = _read_json("races.json")
		races = rj["races"]


func load_all() -> void:
	if loaded:
		return
	meta = _read_json("world.json")
	n = int(meta["n"])
	size = float(meta["size"])
	half = size * 0.5
	px = size / float(n)
	hmin = float(meta["hmin"])
	hmax = float(meta["hmax"])
	hscale = (hmax - hmin) / 65535.0
	splat_n = int(meta["splat_n"])
	progress.emit(0.05, "Terrain")
	hm_bytes = _read_bytes("heightmap.bin")
	hm_image = Image.create_from_data(n, n, false, Image.FORMAT_RG8, hm_bytes)
	splat_image = Image.create_from_data(splat_n, splat_n, false, Image.FORMAT_RGBA8, _read_bytes("splat.bin"))
	progress.emit(0.2, "Roads")
	_load_roads()
	progress.emit(0.5, "Buildings")
	buildings = _read_bytes("buildings.bin").to_float32_array()
	trees = _read_bytes("trees.bin").to_float32_array()
	intersections = _read_bytes("intersections.bin").to_float32_array()
	progress.emit(0.6, "Landmarks")
	landmarks = _read_json("landmarks.json")
	water = _read_json("water.json")
	var rj: Dictionary = _read_json("races.json")
	races = rj["races"]
	parks = rj["parks"]
	progress.emit(0.7, "Navigation")
	_build_gps()
	loaded = true
	progress.emit(1.0, "Ready")


func _load_roads() -> void:
	var arr: Array = _read_json("roads.json")
	roads.clear()
	_bridge_hash.clear()
	_bridge_pts.clear()
	for r in arr:
		var xs: Array = r["x"]
		var zs: Array = r["z"]
		var ys: Array = r["y"]
		var br: Array = r["bridge"]
		var cnt := xs.size()
		var pts := PackedVector3Array()
		pts.resize(cnt)
		var bflags := PackedByteArray()
		bflags.resize(cnt)
		for i in cnt:
			pts[i] = Vector3(xs[i], ys[i], zs[i])
			bflags[i] = int(br[i])
		var rd := {"name": r["name"], "cls": r["cls"], "width": float(r["width"]), "pts": pts, "bridge": bflags}
		roads.append(rd)
		var hw := float(r["width"]) * 0.5
		for i in cnt:
			if bflags[i] != 0:
				var id := _bridge_pts.size()
				_bridge_pts.append([pts[i].x, pts[i].z, pts[i].y, hw + 1.0])
				var key := _cell(pts[i].x, pts[i].z, 24.0)
				if not _bridge_hash.has(key):
					_bridge_hash[key] = PackedInt32Array()
				_bridge_hash[key].append(id)


func _cell(x: float, z: float, s: float) -> int:
	return (int(floor(x / s)) + 4096) * 8192 + (int(floor(z / s)) + 4096)


# ------------------------------------------------------------------ terrain
func _tex(ix: int, iz: int) -> float:
	ix = clampi(ix, 0, n - 1)
	iz = clampi(iz, 0, n - 1)
	return hmin + float(hm_bytes.decode_u16((iz * n + ix) * 2)) * hscale


func terrain_height(x: float, z: float) -> float:
	var u := (x + half) / px - 0.5
	var v := (z + half) / px - 0.5
	var ix := int(floor(u))
	var iz := int(floor(v))
	var fx := u - ix
	var fz := v - iz
	var a := lerpf(_tex(ix, iz), _tex(ix + 1, iz), fx)
	var b := lerpf(_tex(ix, iz + 1), _tex(ix + 1, iz + 1), fx)
	return lerpf(a, b, fz)


## Height of the drivable surface (terrain, or a bridge deck above it)
func ground_height(x: float, z: float, ref_y: float = 1e9) -> float:
	var th := terrain_height(x, z)
	var key := _cell(x, z, 24.0)
	var best := th
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			var k2 := key + dx * 8192 + dz
			if _bridge_hash.has(k2):
				for id in _bridge_hash[k2]:
					var bp: Array = _bridge_pts[id]
					var d2: float = (bp[0] - x) * (bp[0] - x) + (bp[1] - z) * (bp[1] - z)
					if d2 < bp[3] * bp[3] and bp[2] > best and bp[2] < ref_y + 1.5:
						best = bp[2]
	return best


func terrain_normal(x: float, z: float) -> Vector3:
	var e := 2.0
	var hx := terrain_height(x + e, z) - terrain_height(x - e, z)
	var hz := terrain_height(x, z + e) - terrain_height(x, z - e)
	return Vector3(-hx, 2.0 * e, -hz).normalized()


func is_water(x: float, z: float) -> bool:
	return terrain_height(x, z) < -0.2


func clamp_to_world(x: float, z: float) -> Vector2:
	return Vector2(clampf(x, -half + 40.0, half - 40.0), clampf(z, -half + 40.0, half - 40.0))


# ------------------------------------------------------------------ roads / GPS
func _build_gps() -> void:
	astar.clear()
	_gps_hash.clear()
	var id := 0
	var prev_ids: Array = []
	for r in roads:
		if r["cls"] == "runway":
			prev_ids.append(-1)
			continue
		var pts: PackedVector3Array = r["pts"]
		var last := -1
		var step := 4
		var first := true
		for i in range(0, pts.size(), step):
			astar.add_point(id, pts[i])
			var key := _cell(pts[i].x, pts[i].z, GPS_CELL)
			if not _gps_hash.has(key):
				_gps_hash[key] = PackedInt32Array()
			_gps_hash[key].append(id)
			if last >= 0:
				astar.connect_points(last, id, true)
			last = id
			id += 1
	# join crossing roads
	var ids := astar.get_point_ids()
	for pid in ids:
		var p: Vector3 = astar.get_point_position(pid)
		var key := _cell(p.x, p.z, GPS_CELL)
		for dx in range(-1, 2):
			for dz in range(-1, 2):
				var k2 := key + dx * 8192 + dz
				if not _gps_hash.has(k2):
					continue
				for q in _gps_hash[k2]:
					if q <= pid:
						continue
					var qp: Vector3 = astar.get_point_position(q)
					if absf(qp.y - p.y) < 6.0 and Vector2(p.x - qp.x, p.z - qp.z).length() < 15.0 and not astar.are_points_connected(pid, q):
						astar.connect_points(pid, q, true)


func nearest_road_point(pos: Vector3) -> int:
	var key := _cell(pos.x, pos.z, GPS_CELL)
	var best := -1
	var bd := 1e18
	for ring in range(1, 8):
		for dx in range(-ring, ring + 1):
			for dz in range(-ring, ring + 1):
				if maxi(absi(dx), absi(dz)) != ring:
					continue
				var k2 := key + dx * 8192 + dz
				if _gps_hash.has(k2):
					for q in _gps_hash[k2]:
						var qp: Vector3 = astar.get_point_position(q)
						var d := (qp.x - pos.x) * (qp.x - pos.x) + (qp.z - pos.z) * (qp.z - pos.z)
						if d < bd:
							bd = d
							best = q
		if best >= 0:
			break
	return best


func gps_route(from: Vector3, to: Vector3) -> PackedVector3Array:
	var a := nearest_road_point(from)
	var b := nearest_road_point(to)
	if a < 0 or b < 0:
		return PackedVector3Array()
	return astar.get_point_path(a, b)


## 1 on a paved road, 0 well off it (used for tyre grip).
func road_blend(x: float, z: float) -> float:
	var key := _cell(x, z, GPS_CELL)
	var bd := 1e18
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			var k2 := key + dx * 8192 + dz
			if _gps_hash.has(k2):
				for q in _gps_hash[k2]:
					var qp: Vector3 = astar.get_point_position(q)
					var d := (qp.x - x) * (qp.x - x) + (qp.z - z) * (qp.z - z)
					if d < bd:
						bd = d
	return 1.0 - smoothstep(14.0, 26.0, sqrt(bd)) if bd < 1e17 else 0.0
