extends Node
var gw: GameWorld
var f := 0
func _ready() -> void:
	G.start_hour = 11.0
	var a := OS.get_cmdline_user_args()
	if a.size() > 0:
		G.selected_car = int(a[0])
	gw = GameWorld.new()
	add_child(gw)
	gw.cam_mode = 2
	print("EYE ", gw.player.model.get_meta("eye"), " spec ", gw.player.spec)
func _process(_d: float) -> void:
	f += 1
	gw.touch["left"] = f > 6
	if f == 14:
		get_viewport().get_texture().get_image().save_png("/tmp/cockpit.png")
		get_tree().quit()
