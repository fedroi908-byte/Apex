class_name TerrainClipmap
extends Node3D
## Geometry clip-map: concentric rings of a fixed grid that follow the camera; heights come
## from the heightmap texture in the vertex shader (no per-vertex work on the CPU).

const GRID := 96                 # cells per side for every level
const LEVELS := 7
const BASE_CELL := 3.0

var material: ShaderMaterial
var level_nodes: Array[MeshInstance3D] = []
var cells: Array[float] = []


func _ready() -> void:
	material = ShaderMaterial.new()
	material.shader = load("res://shaders/terrain.gdshader")
	material.set_shader_parameter("heightmap", ImageTexture.create_from_image(W.hm_image))
	material.set_shader_parameter("splat", ImageTexture.create_from_image(W.splat_image))
	material.set_shader_parameter("world_size", W.size)
	material.set_shader_parameter("hn", float(W.n))
	material.set_shader_parameter("hmin", W.hmin)
	material.set_shader_parameter("hrange", W.hmax - W.hmin)
	var T := "res://assets/textures/"
	material.set_shader_parameter("grass_a", load(T + "grass_albedo.png"))
	material.set_shader_parameter("grass_n", load(T + "grass_normal.png"))
	material.set_shader_parameter("rock_a", load(T + "rock_albedo.png"))
	material.set_shader_parameter("rock_n", load(T + "rock_normal.png"))
	material.set_shader_parameter("sand_a", load(T + "sand_albedo.png"))
	material.set_shader_parameter("sand_n", load(T + "sand_normal.png"))
	material.set_shader_parameter("pave_a", load(T + "pavement_albedo.png"))
	material.set_shader_parameter("pave_n", load(T + "pavement_normal.png"))
	for k in LEVELS:
		var c := BASE_CELL * pow(2.0, k)
		cells.append(c)
		var mi := MeshInstance3D.new()
		mi.mesh = _build_level(c, k > 0)
		var mat := material.duplicate() as ShaderMaterial
		mat.set_shader_parameter("cell", c)
		mi.material_override = mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.gi_mode = GeometryInstance3D.GI_MODE_DISABLED
		add_child(mi)
		level_nodes.append(mi)


func _build_level(c: float, hole: bool) -> ArrayMesh:
	var n1 := GRID + 1
	var verts := PackedVector3Array()
	var cols := PackedColorArray()
	verts.resize(n1 * n1)
	cols.resize(n1 * n1)
	var half := GRID * 0.5
	for j in n1:
		for i in n1:
			verts[j * n1 + i] = Vector3((i - half) * c, 0.0, (j - half) * c)
			cols[j * n1 + i] = Color(0, 0, 0, 1)
	var idx := PackedInt32Array()
	var h0 := GRID / 4
	var h1 := GRID - GRID / 4
	var skirt_edges: Array = []                 # pairs of vertex indices (boundary edges)
	for j in GRID:
		for i in GRID:
			var inner := hole and i >= h0 and i < h1 and j >= h0 and j < h1
			if inner:
				continue
			var a := j * n1 + i
			var b := a + 1
			var d := a + n1
			var e := d + 1
			idx.append_array([a, d, b, b, d, e])
			# boundary edges (outer border or touching the hole)
			if i == 0:
				skirt_edges.append([a, d])
			if i == GRID - 1:
				skirt_edges.append([b, e])
			if j == 0:
				skirt_edges.append([a, b])
			if j == GRID - 1:
				skirt_edges.append([d, e])
			if hole:
				if i == h0 - 1 and j >= h0 and j < h1:
					skirt_edges.append([b, e])
				if i == h1 and j >= h0 and j < h1:
					skirt_edges.append([a, d])
				if j == h0 - 1 and i >= h0 and i < h1:
					skirt_edges.append([d, e])
				if j == h1 and i >= h0 and i < h1:
					skirt_edges.append([a, b])
	# skirts: duplicate border vertices, dropped in the shader through COLOR.r
	var remap := {}
	for ed in skirt_edges:
		for v in ed:
			if not remap.has(v):
				remap[v] = verts.size()
				verts.append(verts[v])
				cols.append(Color(1, 0, 0, 1))
		idx.append_array([ed[0], remap[ed[0]], ed[1], ed[1], remap[ed[0]], remap[ed[1]]])
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.custom_aabb = AABB(Vector3(-6000, -150, -6000), Vector3(12000, 1400, 12000))
	return mesh


func follow(p: Vector3) -> void:
	for k in LEVELS:
		var snap := cells[k] * 2.0
		level_nodes[k].position = Vector3(floor(p.x / snap) * snap, 0.0, floor(p.z / snap) * snap)
