extends Node
var main: Node
var f := 0
func _ready() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
func _physics_process(_d: float) -> void:
	f += 1
	if f == 30:
		G.mode = "mission"
		G.mission_id = "race_coast"
		main.start_world()
	if f > 60 and main.current is GameWorld:
		var gw: GameWorld = main.current
		gw.touch["gas"] = true
		if f % 120 == 0:
			var r := gw.runner
			print("F ", f, " kmh ", int(gw.player.kmh()), " runner ", r.state if r else "none", " cp ", r.cp_i if r else -1, "/", r.cps.size() if r else -1)
	if f == 900:
		get_tree().quit()
