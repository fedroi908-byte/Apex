class_name MainMenu
extends Node3D
## Animated 3D showroom + UI: main menu, missions, garage, settings.

signal play(mode: String, id: String)
signal quit_game

var atmo: Atmosphere
var cam: Camera3D
var stage: Node3D                   # turntable
var car_node: Node3D
var car_data: Dictionary = {}
var ui: CanvasLayer
var screen: Control
var music: AudioStreamPlayer
var cam_ang := 0.7
var cam_rad := 8.6
var cam_h := 1.55
var cam_look := 0.55
var cam_hoff := -2.1
var turn := 0.0
var drag := 0.0
var _dragging := false
var _t := 0.0
var _streaks: Array = []
var garage_idx := 0
var _gfilter := "ALL"
var _strip: CarStrip
var sel_mission := ""
var _mode := "main"
var _credit_lbl: Label


func _ready() -> void:
	atmo = Atmosphere.new()
	add_child(atmo)
	atmo.paused = true
	atmo.set_time(19.4)
	_build_stage()
	cam = Camera3D.new()
	cam.fov = 38.0
	cam.far = 600.0
	add_child(cam)
	cam.current = true
	atmo.cam_ref = cam
	garage_idx = G.selected_car
	_show_car(G.selected_car)
	ui = CanvasLayer.new()
	ui.layer = 5
	add_child(ui)
	var st := load("res://assets/audio/music_menu.wav") as AudioStreamWAV
	if st:
		st = st.duplicate()
		st.loop_mode = AudioStreamWAV.LOOP_FORWARD
		st.loop_begin = 0
		st.loop_end = int(st.get_length() * st.mix_rate)
		music = AudioStreamPlayer.new()
		music.stream = st
		music.volume_db = linear_to_db(maxf(G.music_volume, 0.001)) - 6.0
		add_child(music)
		music.play()
	_go_main()


# ------------------------------------------------------------------ 3D stage
func _build_stage() -> void:
	var floor_m := MeshInstance3D.new()
	var pl := PlaneMesh.new()
	pl.size = Vector2(500, 500)
	floor_m.mesh = pl
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.06, 0.07, 0.1)
	fm.metallic = 0.85
	fm.roughness = 0.22
	floor_m.material_override = fm
	add_child(floor_m)
	stage = Node3D.new()
	add_child(stage)
	var plat := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 3.4
	cyl.bottom_radius = 3.5
	cyl.height = 0.14
	cyl.radial_segments = 64
	plat.mesh = cyl
	plat.position.y = 0.07
	var pm := StandardMaterial3D.new()
	pm.albedo_color = Color(0.05, 0.055, 0.07)
	pm.metallic = 0.9
	pm.roughness = 0.18
	plat.material_override = pm
	stage.add_child(plat)
	for r in [3.4, 2.6]:
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = r - 0.05
		tm.outer_radius = r + 0.05
		tm.rings = 64
		tm.ring_segments = 8
		ring.mesh = tm
		ring.position.y = 0.15
		var rm := StandardMaterial3D.new()
		rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		rm.albedo_color = Color(0.1, 0.8, 1.0) if r > 3.0 else Color(1.0, 0.45, 0.1)
		ring.material_override = rm
		stage.add_child(ring)
	# skyline
	var sky_mat := ShaderMaterial.new()
	sky_mat.shader = load("res://shaders/menu_skyline.gdshader")
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for i in 110:
		var a := rng.randf() * TAU
		var r := rng.randf_range(110.0, 260.0)
		var bm := MeshInstance3D.new()
		var bx := BoxMesh.new()
		var hgt := rng.randf_range(40.0, 220.0)
		bx.size = Vector3(rng.randf_range(14.0, 34.0), hgt, rng.randf_range(14.0, 34.0))
		bm.mesh = bx
		bm.material_override = sky_mat
		bm.position = Vector3(cos(a) * r, hgt * 0.5, sin(a) * r)
		bm.rotation.y = rng.randf() * PI
		add_child(bm)
	# orbiting light streaks (traffic on a ring road)
	for i in 26:
		var piv := Node3D.new()
		add_child(piv)
		piv.rotation.y = rng.randf() * TAU
		var mi := MeshInstance3D.new()
		var q := BoxMesh.new()
		q.size = Vector3(rng.randf_range(2.0, 6.0), 0.06, 0.12)
		mi.mesh = q
		var mm := StandardMaterial3D.new()
		mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		var warm := rng.randf() < 0.5
		mm.albedo_color = Color(1.0, 0.25, 0.1) if warm else Color(1.0, 0.95, 0.85)
		mi.material_override = mm
		var rad := rng.randf_range(16.0, 30.0) + (0.0 if warm else 2.2)
		mi.position = Vector3(rad, rng.randf_range(0.2, 1.4), 0)
		piv.add_child(mi)
		_streaks.append({"n": piv, "s": rng.randf_range(0.25, 0.7) * (1.0 if warm else -1.0)})
	# key lights
	var cols := [Color(0.1, 0.8, 1.0), Color(1.0, 0.5, 0.15), Color(1.0, 0.95, 0.9)]
	var pos := [Vector3(-6, 5, 4), Vector3(6, 4, -5), Vector3(0, 8, 0)]
	for i in 3:
		var sl := SpotLight3D.new()
		sl.light_color = cols[i]
		sl.light_energy = 16.0 if i < 2 else 9.0
		sl.spot_range = 22.0
		sl.spot_angle = 38.0
		sl.shadow_enabled = i == 2
		sl.position = pos[i]
		add_child(sl)
		sl.look_at(Vector3(0, 0.6, 0), Vector3.UP)


func _show_car(idx: int) -> void:
	if car_node and is_instance_valid(car_node):
		car_node.queue_free()
	var c: Dictionary = G.cars[idx]
	var res := CarBuilder.build(String(c["model"]), G.car_color(idx))
	car_node = res["node"]
	car_node.position.y = 0.16
	stage.add_child(car_node)
	car_data = c
	garage_idx = idx
	if not G.owns(idx):
		for mi in car_node.find_children("*", "MeshInstance3D", true, false):
			pass


func _repaint(pi: int) -> void:
	G.set_car_paint(garage_idx, pi)
	if car_node and car_node.has_meta("paint"):
		var sp: ShaderMaterial = car_node.get_meta("paint")
		var col: Color = G.PAINTS[pi]
		sp.set_shader_parameter("base_color", col)
		sp.set_shader_parameter("accent_color", col.lightened(0.35))


func _process(dt: float) -> void:
	_t += dt
	turn += dt * 0.28 + drag
	drag = lerpf(drag, 0.0, clampf(dt * 4.0, 0.0, 1.0))
	if car_node:
		stage.rotation.y = turn
		if car_node.has_meta("paints"):
			for pm in car_node.get_meta("paints"):
				(pm as ShaderMaterial).set_shader_parameter("car_to_world", car_node.global_transform)
	for s in _streaks:
		(s["n"] as Node3D).rotation.y += dt * float(s["s"])
	var mp := get_viewport().get_mouse_position() / Vector2(get_viewport().get_visible_rect().size) - Vector2(0.5, 0.5)
	var a := cam_ang + sin(_t * 0.17) * 0.08 + mp.x * 0.12
	cam.position = Vector3(sin(a) * cam_rad, cam_h + mp.y * -0.3, cos(a) * cam_rad)
	cam.look_at(Vector3(0, cam_look, 0), Vector3.UP)
	cam.h_offset = cam_hoff
	if _credit_lbl:
		_credit_lbl.text = "$ " + _fmt_num(G.credits)


func _input(e: InputEvent) -> void:
	if _mode != "main" and _mode != "garage":
		return
	var vp := get_viewport().get_visible_rect().size
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		_dragging = e.pressed and e.position.x > vp.x * 0.4 and not (_mode == "garage" and e.position.y > vp.y - 260.0)
	elif e is InputEventMouseMotion and _dragging:
		turn += e.relative.x * 0.006
		drag = e.relative.x * 0.0004


func _move_cam(ang: float, rad: float, h: float, look: float, hoff: float) -> void:
	var t := create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	t.tween_property(self, "cam_ang", ang, 0.9)
	t.tween_property(self, "cam_rad", rad, 0.9)
	t.tween_property(self, "cam_h", h, 0.9)
	t.tween_property(self, "cam_look", look, 0.9)
	t.tween_property(self, "cam_hoff", hoff, 0.9)


func _fmt_num(n: int) -> String:
	var s := str(n)
	var out := ""
	for i in s.length():
		if i > 0 and (s.length() - i) % 3 == 0:
			out += ","
		out += s[i]
	return out


# ------------------------------------------------------------------ screens
func _set_screen(c: Control) -> void:
	if screen and is_instance_valid(screen):
		var old := screen
		var t := old.create_tween()
		t.tween_property(old, "modulate:a", 0.0, 0.15)
		t.tween_callback(old.queue_free)
	screen = c
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(c)
	_credit_lbl = null
	_add_top_bar(c)


func _add_top_bar(c: Control) -> void:
	var pn := Ui.panel(Color(0.03, 0.05, 0.09, 0.78), 30)
	pn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	c.add_child(pn)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 26)
	pn.add_child(h)
	_credit_lbl = Ui.label("$ 0", 28, Ui.GOLD, true)
	h.add_child(_credit_lbl)
	var total := 0
	for k in G.mission_stars:
		total += int(G.mission_stars[k])
	h.add_child(Ui.label("★ %d / %d" % [total, Missions.list().size() * 3], 24, Ui.ACCENT))
	pn.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 24)


func _go_main() -> void:
	_mode = "main"
	_move_cam(0.75, 8.6, 1.55, 0.55, -2.2)
	var c := Control.new()
	_set_screen(c)
	var logo := VBoxContainer.new()
	logo.position = Vector2(80, 60)
	logo.add_theme_constant_override("separation", 0)
	c.add_child(logo)
	logo.add_child(Ui.logo(150))
	var tag := Ui.label("OPEN WORLD  •  REAL PHYSICS  •  DAY & NIGHT", 20, Ui.DIM)
	tag.position = Vector2(86, 372)
	c.add_child(tag)
	var items := [
		["DRIVE  —  FREE ROAM", func(): _launch("free", ""), Ui.ACCENT],
		["MISSIONS", func(): _go_missions(), Ui.HOT],
		["GARAGE", func(): _go_garage(), Ui.GOOD],
		["SETTINGS", func(): _open_settings(), Ui.DIM],
		["QUIT", func(): quit_game.emit(), Color(0.9, 0.25, 0.25)],
	]
	var y := 430.0
	var i := 0
	for it in items:
		var b := Ui.button(it[0], it[1], it[2], 28, Vector2(430, 66))
		b.position = Vector2(80, y)
		c.add_child(b)
		Ui.fade_in(b, 0.1 * i)
		y += 80.0
		i += 1
	Ui.fade_in(logo, 0.0, -80.0)
	var cn := Ui.label("%s  •  drag to rotate" % car_data.get("name", ""), 20, Ui.DIM)
	cn.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	c.add_child(cn)
	cn.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 26)


func _launch(mode: String, id: String) -> void:
	G.selected_car = garage_idx if G.owns(garage_idx) else G.selected_car
	G.save_game()
	play.emit(mode, id)


func _open_settings() -> void:
	var s := SettingsScreen.new()
	ui.add_child(s)
	s.closed.connect(func(): music.volume_db = linear_to_db(maxf(G.music_volume, 0.001)) - 6.0)


# ---------- missions
func _go_missions() -> void:
	_mode = "missions"
	_move_cam(1.25, 11.5, 2.4, 0.7, -3.4)
	var c := Control.new()
	_set_screen(c)
	var back := Ui.button("◀  BACK", func(): _go_main(), Ui.DIM, 24, Vector2(200, 56))
	back.position = Vector2(60, 40)
	c.add_child(back)
	var title := Ui.label("MISSIONS", 54, Color.WHITE, true)
	title.position = Vector2(280, 34)
	c.add_child(title)
	var list_p := Ui.panel(Color(0.03, 0.05, 0.09, 0.82), 18)
	list_p.position = Vector2(60, 120)
	list_p.custom_minimum_size = Vector2(620, 560)
	c.add_child(list_p)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(590, 540)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	list_p.add_child(sc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	sc.add_child(vb)
	var detail := Control.new()
	detail.position = Vector2(720, 120)
	c.add_child(detail)
	var ms := Missions.list()
	if sel_mission == "":
		sel_mission = ms[0]["id"]
	for m in ms:
		vb.add_child(_mission_card(m, detail))
	_mission_detail(detail, Missions.by_id(sel_mission))
	Ui.fade_in(list_p, 0.0)


func _mission_card(m: Dictionary, detail: Control) -> Button:
	var col: Color = Missions.TYPE_COLORS[m["type"]]
	var b := Ui.button("", func():
		sel_mission = m["id"]
		_mission_detail(detail, m), col, 20, Vector2(570, 78))
	var h := HBoxContainer.new()
	h.set_anchors_preset(Control.PRESET_FULL_RECT)
	h.offset_left = 26
	h.offset_right = -14
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_theme_constant_override("separation", 12)
	b.add_child(h)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var n := Ui.label(String(m["name"]), 24, Color.WHITE)
	n.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var s := Ui.label("%s  •  %s" % [Missions.TYPE_NAMES[m["type"]], m["diff_name"]], 16, col)
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(n)
	v.add_child(s)
	h.add_child(v)
	var st := Ui.stars(int(G.mission_stars.get(m["id"], 0)), 26)
	st.mouse_filter = Control.MOUSE_FILTER_IGNORE
	st.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(st)
	return b


func _mission_detail(d: Control, m: Dictionary) -> void:
	for ch in d.get_children():
		ch.queue_free()
	var col: Color = Missions.TYPE_COLORS[m["type"]]
	var p := Ui.panel(Color(0.03, 0.05, 0.09, 0.82), 18)
	p.custom_minimum_size = Vector2(560, 560)
	d.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	p.add_child(v)
	v.add_child(Ui.label(Missions.TYPE_NAMES[m["type"]], 20, col))
	v.add_child(Ui.label(String(m["name"]), 44, Color.WHITE, true))
	var ds := Ui.label(String(m["desc"]), 21, Ui.DIM)
	ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ds.custom_minimum_size = Vector2(500, 0)
	v.add_child(ds)
	v.add_child(Ui.stat_row("DIFFICULTY", [0.33, 0.66, 1.0][int(m["difficulty"])], col))
	var lines: Array = []
	match String(m["type"]):
		"race":
			lines.append("Distance: %.1f km" % (float(m["length"]) / 1000.0))
			lines.append("★★★ under %s   ★★ under %s" % [_tm(m["gold"]), _tm(m["silver"])])
			lines.append("Time limit: %s" % _tm(m["limit"]))
		"speed":
			lines.append("Reach %d km/h within %d s" % [int(m["target"]), int(m["limit"])])
			lines.append("★★★ under %d s   ★★ under %d s" % [int(m["gold"]), int(m["silver"])])
		"drift":
			lines.append("Target: %d points in %d s" % [int(m["target"]), int(m["limit"])])
			lines.append("★★★ %d   ★★ %d" % [int(m["gold"]), int(m["silver"])])
		"courier":
			lines.append("%d delivery points in %s" % [int(m["count"]), _tm(m["limit"])])
			lines.append("★★★ under %s   ★★ under %s" % [_tm(m["gold"]), _tm(m["silver"])])
	for ln in lines:
		v.add_child(Ui.label(ln, 20, Color(0.88, 0.93, 1.0)))
	v.add_child(Ui.label("Reward: $ %s" % _fmt_num(int(m["reward"])), 26, Ui.GOLD))
	var best: float = float(G.mission_best.get(m["id"], 0.0))
	if best > 0.0:
		v.add_child(Ui.label("Best: " + (str(int(best)) + " pts" if m["type"] == "drift" else _tm(best)), 22, Ui.GOOD))
	v.add_child(Ui.stars(int(G.mission_stars.get(m["id"], 0)), 40))
	var go := Ui.button("START MISSION", func(): _launch("mission", String(m["id"])), col, 28, Vector2(500, 70))
	go.alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(go)
	Ui.fade_in(p, 0.0, 40.0)


func _tm(x: float) -> String:
	return "%d:%02d" % [int(x / 60.0), int(x) % 60]


# ---------- garage
func _go_garage() -> void:
	_mode = "garage"
	_move_cam(0.45, 6.4, 1.15, 0.6, 0.0)
	var c := Control.new()
	_set_screen(c)
	var back := Ui.button("◀  BACK", func(): _go_main(), Ui.DIM, 24, Vector2(200, 56))
	back.position = Vector2(60, 40)
	c.add_child(back)
	var title := Ui.label("GARAGE", 54, Color.WHITE, true)
	title.position = Vector2(280, 34)
	c.add_child(title)
	_build_garage_strip(c)
	_garage_info(c)


func _car_in_filter(i: int) -> bool:
	var car: Dictionary = G.cars[i]
	if _gfilter == "ALL":
		return true
	if _gfilter == "OWNED":
		return G.owns(i)
	return String(car.get("cls", "")) == _gfilter


func _garage_cards() -> Array:
	var out: Array = []
	for i in G.cars.size():
		if not _car_in_filter(i):
			continue
		var car: Dictionary = G.cars[i]
		var price := int(car["price"])
		out.append({"idx": i, "name": String(car["name"]), "cls": String(car.get("cls", "")), "price": price, "price_s": _fmt_num(price),
			"owned": G.owns(i), "color": G.car_color(i), "can_buy": G.credits >= price})
	return out


func _build_garage_strip(c: Control) -> void:
	var box := VBoxContainer.new()
	box.set_meta("strip", true)
	box.add_theme_constant_override("separation", 10)
	box.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	c.add_child(box)
	box.offset_left = 40
	box.offset_right = -40
	box.offset_bottom = -22
	box.offset_top = -250
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 8)
	box.add_child(chips)
	var classes := ["ALL", "OWNED"]
	for k in ["SUPER", "HYPER", "SPORT", "MUSCLE", "SUV", "RALLY", "CLASSIC", "CONCEPT"]:
		for car in G.cars:
			if String(car.get("cls", "")) == k:
				classes.append(k)
				break
	for k in classes:
		var b := Button.new()
		b.text = k
		b.toggle_mode = true
		b.button_pressed = k == _gfilter
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(118, 54)
		b.add_theme_font_size_override("font_size", 20)
		b.add_theme_stylebox_override("normal", Ui.box(Color(0.07, 0.1, 0.16, 0.9), 8, Color(1, 1, 1, 0.14), 1))
		b.add_theme_stylebox_override("hover", Ui.box(Color(0.12, 0.2, 0.3, 0.95), 8, Ui.ACCENT, 1))
		b.add_theme_stylebox_override("pressed", Ui.box(Ui.ACCENT.darkened(0.45), 8, Ui.ACCENT, 2))
		var kk: String = k
		b.pressed.connect(func():
			_gfilter = kk
			G.ui("ui_click")
			_refresh_strip(c)
			for ch in chips.get_children():
				(ch as Button).button_pressed = (ch as Button).text == kk)
		chips.add_child(b)
	_strip = CarStrip.new()
	_strip.custom_minimum_size = Vector2(0, 150)
	_strip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(_strip)
	_strip.picked.connect(func(idx: int):
		garage_idx = idx
		_show_car(idx)
		_strip.set_selected(idx)
		_garage_info(c))
	_refresh_strip(c)


func _refresh_strip(c: Control) -> void:
	var list := _garage_cards()
	if list.is_empty():
		_gfilter = "ALL"
		list = _garage_cards()
	var found := false
	for e in list:
		if int(e["idx"]) == garage_idx:
			found = true
	if not found and not list.is_empty():
		garage_idx = int(list[0]["idx"])
		_show_car(garage_idx)
		_garage_info(c)
	_strip.set_cards(list, garage_idx)


func _garage_info(c: Control) -> void:
	for ch in c.get_children():
		if ch.has_meta("garage"):
			ch.queue_free()
	var car: Dictionary = G.cars[garage_idx]
	var info := Ui.panel(Color(0.03, 0.05, 0.09, 0.82), 18)
	info.set_meta("garage", true)
	info.position = Vector2(60, 130)
	c.add_child(info)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	info.add_child(v)
	v.add_child(Ui.label(String(car["name"]), 40, Color.WHITE, true))
	v.add_child(Ui.label(String(car["tagline"]), 20, Ui.DIM))
	v.add_child(Ui.stat_row("TOP SPEED", float(car["top_speed"]), Ui.HOT))
	v.add_child(Ui.stat_row("ACCELERATION", float(car["accel"]), Ui.ACCENT))
	v.add_child(Ui.stat_row("HANDLING", float(car["handling"]), Ui.GOOD))
	v.add_child(Ui.stat_row("NITRO", float(car["nitro"]), Color(0.7, 0.5, 1.0)))
	var owned := G.owns(garage_idx)
	var selected := G.selected_car == garage_idx
	var txt := "SELECTED" if selected else ("SELECT" if owned else "BUY  $ %s" % _fmt_num(int(car["price"])))
	var act := Ui.button(txt, func():
		if owned:
			G.selected_car = garage_idx
			G.save_game()
		elif G.buy_car(garage_idx):
			G.selected_car = garage_idx
			G.ui("win", -8.0)
			G.save_game()
		else:
			G.ui("ui_back")
		_refresh_strip(c)
		_garage_info(c), Ui.GOOD if owned else Ui.GOLD, 26, Vector2(420, 66))
	act.disabled = selected
	act.alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(act)
	if not owned and G.credits < int(car["price"]):
		v.add_child(Ui.label("Earn %s more credits from missions" % _fmt_num(int(car["price"]) - G.credits), 18, Color(1, 0.5, 0.4)))
	# paints
	var pp := Ui.panel(Color(0.03, 0.05, 0.09, 0.82), 18)
	pp.set_meta("garage", true)
	c.add_child(pp)
	var pv := VBoxContainer.new()
	pp.add_child(pv)
	pv.add_child(Ui.label("PAINT", 20, Ui.DIM))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	pv.add_child(row)
	for i in G.PAINTS.size():
		var sw := Button.new()
		sw.custom_minimum_size = Vector2(60, 60)
		sw.focus_mode = Control.FOCUS_NONE
		var cur := G.car_color(garage_idx).is_equal_approx(G.PAINTS[i])
		var sb := Ui.box(G.PAINTS[i], 30, Color.WHITE if cur else Color(1, 1, 1, 0.25), 4 if cur else 1)
		sw.add_theme_stylebox_override("normal", sb)
		sw.add_theme_stylebox_override("hover", Ui.box(G.PAINTS[i], 30, Color.WHITE, 3))
		sw.add_theme_stylebox_override("pressed", sb)
		sw.tooltip_text = G.PAINT_NAMES[i]
		var idx := i
		sw.pressed.connect(func():
			G.ui("ui_click")
			_repaint(idx)
			G.save_game()
			_garage_info(c))
		row.add_child(sw)
	pp.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 270)
	pp.set_meta("garage", true)
	# arrows
	var l := Ui.button("◀", func(): _cycle(-1, c), Ui.ACCENT, 34, Vector2(80, 80))
	l.alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.set_meta("garage", true)
	l.position = Vector2(560, 330)
	c.add_child(l)
	var r := Ui.button("▶", func(): _cycle(1, c), Ui.ACCENT, 34, Vector2(80, 80))
	r.alignment = HORIZONTAL_ALIGNMENT_CENTER
	r.set_meta("garage", true)
	r.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	c.add_child(r)
	r.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT, Control.PRESET_MODE_MINSIZE, 50)


func _cycle(d: int, c: Control) -> void:
	var list := _garage_cards()
	if list.is_empty():
		return
	var pos := 0
	for i in list.size():
		if int(list[i]["idx"]) == garage_idx:
			pos = i
	garage_idx = int(list[(pos + d + list.size()) % list.size()]["idx"])
	_show_car(garage_idx)
	if _strip:
		_strip.set_selected(garage_idx)
	_garage_info(c)
