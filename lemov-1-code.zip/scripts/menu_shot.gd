extends Node
var m: MainMenu
var f := 0
func _ready() -> void:
	m = MainMenu.new()
	add_child(m)
func _process(_d: float) -> void:
	f += 1
	if f == 40:
		get_viewport().get_texture().get_image().save_png("/tmp/m_main.png")
		m._go_missions()
	if f == 90:
		get_viewport().get_texture().get_image().save_png("/tmp/m_missions.png")
		m._go_garage()
	if f == 140:
		get_viewport().get_texture().get_image().save_png("/tmp/m_garage.png")
		m._open_settings()
	if f == 170:
		get_viewport().get_texture().get_image().save_png("/tmp/m_settings.png")
		get_tree().quit()
