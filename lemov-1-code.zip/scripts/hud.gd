class_name Hud
extends CanvasLayer
## In-game HUD: speedometer with RPM arc, nitro bar, clock, touch controls, top buttons.

signal menu_pressed
signal camera_pressed
signal reset_pressed

var touch: Dictionary = {}
var touch_layer: TouchLayer
var root: Control
var gauge: Control
var speed := 0.0
var rpm := 0.0
var gear := 1
var nitro := 1.0
var clock_text := "12:00"
var fps_label: Label
var clock_label: Label
var boosting := false
var street_label: Label
var _font: Font


func _ready() -> void:
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	_font = ThemeDB.fallback_font
	gauge = Control.new()
	gauge.set_anchors_preset(Control.PRESET_FULL_RECT)
	gauge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gauge.draw.connect(_draw_gauge)
	root.add_child(gauge)
	clock_label = _label("12:00", 30, Vector2(0, 14), true)
	clock_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	clock_label.position = Vector2(-60, 12)
	fps_label = _label("", 18, Vector2(14, 12), false)
	var ins := Ui.safe_insets(get_viewport())
	fps_label.position = Vector2(14.0 + ins.x, 12.0 + ins.y)
	_btn("II", Vector2(-84 - ins.z, 14 + ins.y), Control.PRESET_TOP_RIGHT, Vector2(66, 66), func(): menu_pressed.emit())
	_btn("CAM", Vector2(-160 - ins.z, 14 + ins.y), Control.PRESET_TOP_RIGHT, Vector2(66, 66), func(): camera_pressed.emit())
	_btn("R", Vector2(-236 - ins.z, 14 + ins.y), Control.PRESET_TOP_RIGHT, Vector2(66, 66), func(): reset_pressed.emit())
	# multi-touch controls (raw touch events; always created, harmless with a keyboard)
	touch_layer = TouchLayer.new()
	touch_layer.state = touch
	touch_layer.swap_sides = G.left_handed
	root.add_child(touch_layer)


func _label(t: String, size: int, pos: Vector2, bold: bool) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color(1, 1, 1, 0.95))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	l.add_theme_constant_override("outline_size", 6)
	l.position = pos
	root.add_child(l)
	return l


func _style(c: Color, r: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(r)
	s.border_color = Color(1, 1, 1, 0.35)
	s.set_border_width_all(2)
	return s


func _btn(t: String, pos: Vector2, preset: int, size: Vector2, cb: Callable) -> Button:
	var b := Button.new()
	b.text = t
	b.set_anchors_preset(preset)
	b.size = size
	b.position = pos
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", _style(Color(0.05, 0.08, 0.14, 0.55), 14))
	b.add_theme_stylebox_override("pressed", _style(Color(0.1, 0.5, 0.9, 0.75), 14))
	b.add_theme_stylebox_override("hover", _style(Color(0.1, 0.2, 0.3, 0.65), 14))
	b.add_theme_font_size_override("font_size", 20)
	b.pressed.connect(cb)
	root.add_child(b)
	return b


func update_state(v: Vehicle, a: Atmosphere, _t: float) -> void:
	speed = v.kmh()
	rpm = v.rpm
	gear = v.gear
	nitro = v.nitro
	boosting = v.in_nitro and v.nitro > 0.02 and v.in_gas > 0.1
	var h := int(a.time_of_day)
	var m := int((a.time_of_day - h) * 60.0)
	clock_label.text = "%02d:%02d" % [h, m]
	gauge.queue_redraw()


func set_fps(f: float) -> void:
	fps_label.text = "%d FPS" % int(f)


func _draw_gauge() -> void:
	var vp := gauge.get_viewport_rect().size
	var c := Vector2(vp.x * 0.5, vp.y - 110.0)
	var r := 92.0
	# arc background + rpm
	gauge.draw_arc(c, r, deg_to_rad(150), deg_to_rad(390), 48, Color(0, 0, 0, 0.45), 16.0, true)
	var a1 := deg_to_rad(150.0 + 240.0 * clampf(rpm, 0.0, 1.0))
	var col := Color(0.2, 0.8, 1.0).lerp(Color(1, 0.2, 0.15), smoothstep(0.75, 1.0, rpm))
	gauge.draw_arc(c, r, deg_to_rad(150), a1, 48, col, 10.0, true)
	gauge.draw_arc(c, r - 18.0, deg_to_rad(150), deg_to_rad(390), 48, Color(1, 1, 1, 0.15), 2.0, true)
	var s := str(int(speed))
	var fs := 64
	var sz := _font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	gauge.draw_string_outline(_font, c + Vector2(-sz.x * 0.5, 14.0), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 6, Color(0, 0, 0, 0.8))
	gauge.draw_string(_font, c + Vector2(-sz.x * 0.5, 14.0), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.WHITE)
	gauge.draw_string(_font, c + Vector2(-24, 40), "KM/H", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 1, 1, 0.8))
	gauge.draw_string(_font, c + Vector2(-8, -48), str(gear), HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(1, 0.85, 0.2))
	# nitro bar
	var bw := 220.0
	var bx := c.x - bw * 0.5
	var by := c.y + 58.0
	gauge.draw_rect(Rect2(bx, by, bw, 10), Color(0, 0, 0, 0.5))
	var nc := Color(0.3, 0.6, 1.0) if not boosting else Color(0.7, 0.9, 1.0)
	gauge.draw_rect(Rect2(bx, by, bw * nitro, 10), nc)
	gauge.draw_rect(Rect2(bx, by, bw, 10), Color(1, 1, 1, 0.4), false, 1.5)
