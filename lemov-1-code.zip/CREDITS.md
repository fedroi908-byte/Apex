# Credits
- Concept car (assets/cars/concept.glb): Khronos glTF-Sample-Assets "CarConcept", CC-BY 4.0 (Mike Bertram, Khronos Group).
- Ferrari 458 Italia (assets/cars/ferrari.glb): three.js examples, model by vicent091036, CC-BY 4.0 (Draco-decompressed).
- Stylised vehicles (assets/cars/k_*.glb): Kenney / creativetrio via pmndrs market-assets, CC0 (background traffic only).
- Porsche 911 Turbo S (assets/cars/porsche911.glb): "Porsche 911 with interior" by n.brizitskaya, CC BY 4.0 (Sketchfab), textures downsized.
